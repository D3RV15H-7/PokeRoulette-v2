# PokeRoulette v242 — shared daily prices

The app reads `data/prices-v1.json` from the same website as `index.html`. GitHub Actions builds and deploys that file; no collection information is uploaded to the pricing service. Dex and Sets values remain separate, with one displayed base-card estimate per collected card, matching the existing total rules. Variant badges do not multiply the estimate.

## Activation

1. Add these files to the default branch of your existing repository, preserving the `.github`, `scripts`, `tests` and `data` folders. The download includes the existing icons, manifest and CNAME from your repository. Keep any other assets you have added. On a Mac, press Command + Shift + . in Finder to reveal the hidden `.github` folder before uploading. The updated `index.html` replaces the previous app file.
2. In **Settings → Pages → Build and deployment → Source**, select **GitHub Actions**. Keep your existing custom domain. This setup publishes the same app and assets to that Pages site.
3. In **Actions**, select **Update prices and publish PokeRoulette**, then **Run workflow** on the default branch. If GitHub asks you to enable Actions, enable them for this repository.
4. Wait for both **build** and **deploy** to finish. The first build checks the full English card catalogue and can take substantially longer than subsequent checks. Profile shows the shared snapshot date and pricing coverage after deployment. A downloaded HTML opened directly from a phone is not enough: it needs the price file on the website.

Daily runs are scheduled for **01:17 UTC** (01:17 GMT / 02:17 BST). GitHub may delay scheduled runs; the time is not an exact-time guarantee. Opening the app does not start thousands of provider requests. It uses the deployed price catalogue and retains it offline where browser storage is available.

## Data and failure handling

- Source: TCGdex's English card responses, including their Cardmarket and TCGplayer prices.
- Order: Cardmarket Trend, TCGplayer Market, then Cardmarket 30-day / 7-day / average / 1-day figures.
- Prices remain estimates. The app retains each quote's original provider update date; building a new price file never relabels an old quote as newly updated.
- When an update fails or a response omits pricing, the previous valid quote is retained and flagged. A card that has never had a supported price remains N/A and is excluded from totals.
- Matching uses exact provider IDs, set IDs, collector numbers and names. Ambiguous aliases are rejected. Stamped promos are never assigned the price of an unstamped parent card.
- The two totals show coverage. Where an old saved printing cannot be matched, the app says some cards are unmatched rather than presenting a guessed complete count.
- No API keys or hand-entered price lists are required for this implementation.
- The initial `data/prices-v1.json` is an empty, explicitly pending bootstrap file. It is not a completed price catalogue or a demo valuation. The first successful workflow creates real data.

## Publishing and repository history

The daily workflow deploys a Pages artifact directly. It does **not** add a daily commit to your repository. The last catalogue and a resumable checkpoint are kept in Actions cache. If cache is unavailable, the generator also tries the currently published price file. An empty or wholly failed update does not replace the live website. Partially failed updates keep existing quotes and clearly report partial coverage.

Your existing logos, icons, manifest and CNAME are copied into the published site. Development scripts, tests and Git metadata are excluded. To publish app edits later, update `index.html` on the default branch; the workflow publishes the updated app with its price file.

## Checks

Run `node --test tests/prices.test.mjs` locally. The workflow runs the same checks before building prices. No external packages are required; Node.js 22 or newer is sufficient.

## Troubleshooting

- **Deploy says Pages is not configured / incompatible build type:** select GitHub Actions as the Pages source, then rerun the workflow.
- **Some prices stay unavailable:** inspect the build's summary for failed, retained or unpriced entries. A shared catalogue improves delivery and consistency; it cannot supply prices absent from the upstream provider.
- **Shared snapshot not available yet:** wait for the first successful build and deploy. Existing local estimates are shown until then.
- **First build reaches its time budget:** successful checks are checkpointed; rerun the workflow to continue. Already checked cards are reused that UK calendar day.

References:
- https://tcgdex.dev/markets-prices
- https://tcgdex.dev/faq
- https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages


## Updating the iPhone ZIP installation to v242

Upload `PokeRoulette_v242_shared_daily_prices_setup.zip` beside the previous ZIP in your repository. Replace `.github/workflows/daily-prices.yml` with the complete text from `IPHONE_WORKFLOW.yml` included in this download. Commit the change to main. Keep the Pages source set to GitHub Actions. The new workflow uses the new ZIP and retains the existing daily schedule and compatible price cache.

The update fixes eight confirmed cases involving reverse-only cards, explicit marketplace product IDs and stamped championship reprints. Previously cached N/A records are rechecked once under the new model, even when checked earlier the same day. Valid same-day quotes can be reused.

New diagnostics: each failed card request records its ID, name, timestamp, HTTP status where available, attempt count and exact final error message. After a run, download the `price-diagnostics-v242` artifact from the workflow run page. The report also lists unpriced cards and their source-coverage reason. Every 500 requests, the job prints a progress summary. Diagnostic files are excluded from the published website and contain public card information only.
