import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {selectQuote,normalNumber,baseFinish} from '../scripts/price-model.mjs';
import {buildSnapshot,priceRecord} from '../scripts/update-prices.mjs';
const card=(id='test-1',pricing={cardmarket:{trend:10,updated:'2026-10-27'}})=>({id,name:'Pikachu',localId:id.split('-').pop(),set:{id:'test',name:'Test'},variants:{normal:true},pricing});
const response=data=>new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
test('Cardmarket Trend first, TCGplayer Market fallback; averages stay unavailable',()=>{
 assert.equal(selectQuote(card()).amount,10);
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9},tcgplayer:{normal:{marketPrice:8}}})).source,'TCGplayer market');
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9}})),null);
 assert.equal(selectQuote(card('test-1',{cardmarket:{low:1},tcgplayer:{normal:{lowPrice:1,midPrice:2}}})),null);
 assert.equal(normalNumber('GG003'),'gg3');
});
test('base finish and foil pricing use the same marketplace-product rules',()=>{
 const c=card('test-2',{cardmarket:{trend:5,'trend-holo':20}});c.variants={holo:true};
 assert.equal(baseFinish(c),'holo');assert.equal(selectQuote(c).amount,20);
 c.pricing.cardmarket.idProduct=12;assert.equal(selectQuote(c).amount,5);
});
test('missing pricing preserves the last valid quote and its real date',()=>{
 const old={quote:{amount:8,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-20'},checkedAt:'2026-10-21T00:00:00Z'};
 const record=priceRecord(card('test-1',{}),old,'2026-10-28T00:00:00Z');
 assert.equal(record.quote.amount,8);assert.equal(record.quote.updated,'2026-10-20');assert.equal(record.checkedAt,old.checkedAt);assert.equal(record.retained,true);
});
test('catalogue failures cannot publish an empty replacement',async()=>{
 await assert.rejects(buildSnapshot({fetchImpl:async()=>response([])}),/Invalid or empty/);
});
test('generator refreshes prices, retains failures, and checks N/A without inventing zero',async()=>{
 const previous={schemaVersion:1,sets:{},cards:{'test-2':{name:'Pikachu',number:'2',setId:'test',quote:{amount:4,currency:'EUR',source:'Cardmarket trend'},checkedAt:'2026-10-20T00:00:00Z'}}};
 const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'test',name:'Test'}]);
  if(url.endsWith('/cards'))return response([1,2,3].map(n=>({id:'test-'+n,name:'Pikachu'})));
  if(url.endsWith('/cards/test-1'))return response(card('test-1'));
  if(url.endsWith('/cards/test-3'))return response(card('test-3',{}));
  return new Response('',{status:404});
 };
 const data=await buildSnapshot({previous,fetchImpl,now:'2026-10-28T04:00:00Z'});
 assert.equal(data.cards['test-1'].quote.amount,10);assert.equal(data.cards['test-2'].quote.amount,4);assert.equal(data.cards['test-2'].retained,true);assert.equal(data.cards['test-3'].quote,null);assert.equal(data.summary.failed,1);assert.equal(data.status,'partial');
 assert.equal(data.diagnostics.failedRequests[0].cardId,'test-2');assert.equal(data.diagnostics.failedRequests[0].httpStatus,404);assert.equal(data.diagnostics.failedRequests[0].attempts,1);assert.match(data.diagnostics.failedRequests[0].message,/HTTP 404/);assert.equal(data.diagnostics.unpriced[0].cardId,'test-3');
});
async function client(){
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const source=html.slice(html.indexOf('// v238: values'),html.indexOf('\nfunction calculateProfileStats(sets)'));
 const storage=new Map();let requests=0;
 const c={getExclusiveExpansionPromoPrinting:()=>null,Map,Set,Intl,Date,Promise,URL,console,setTimeout,clearTimeout,USD_TO_GBP:.8,EUR_TO_GBP:.85,TCG_PRICING_VERSION:225,
  activeUid:'a',profileStatsRequestId:1,memCardCol:new Set(),memSetCardCol:new Set(),memSetCardVariants:new Set(),memoryTcgCache:new Map(),currentCardsList:[],
  window:{addEventListener(){}},document:{baseURI:'https://example.test/app/index.html',addEventListener(){},getElementById(){return null;}},
  localStorage:{get length(){return storage.size},key:i=>[...storage.keys()][i],getItem:key=>storage.get(key)||null,setItem:(k,v)=>storage.set(k,v)},
  AUDITED_ARTWORK_SET_ALIASES:{old:'test'},
  promoOwnershipSetNames:()=>({svp:['SV Promos','SVP Black Star Promos']}),
  getCardFingerprint:card=>'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase(),
  getCardOwnershipKeys:card=>[card.id,'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase()],
  getNumericPrice:v=>Number.isFinite(parseFloat(v))&&parseFloat(v)>0?parseFloat(v):null,
  normalizePokemonCardName:s=>s.toLowerCase(),convertTcgQuote:q=>q.amount*(q.currency==='EUR'?.85:.8),
  calculateProfileStats:()=>({ownedCardKeys:new Set([...c.memSetCardCol,...[...c.memSetCardVariants].map(k=>k.slice(0,k.lastIndexOf('__')))])}),
  paintVisibleCardDetails(){},fetchJsonWithRetry:async url=>{assert.equal(url,'https://example.test/app/data/prices-v1.json');requests++;return c.fixture;}
 };
 c.isCardCollected=card=>c.getCardOwnershipKeys(card).some(k=>c.memCardCol.has(k));c.isSetCardCollected=card=>c.calculateProfileStats().ownedCardKeys.has(c.getCardFingerprint(card));
 vm.createContext(c);vm.runInContext(source,c);
 c.fixture={schemaVersion:1,generatedAt:'2026-10-28T04:00:00Z',status:'ready',sets:{test:{name:'Test',aliases:['test','old'],names:['Test']}},cards:{'test-001':{name:'Pikachu',number:'001',setId:'test',quote:{amount:10,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-27'},checkedAt:'2026-10-28T04:00:00Z'}}};
 return {c,requests:()=>requests};
}
test('one shared request prices unseen cards in separate Dex and Sets totals',async()=>{
 const {c,requests}=await client();c.memCardCol.add('old-1');c.memCardCol.add('fp_test_1');c.memSetCardVariants.add('fp_test_001__standard');c.memSetCardVariants.add('fp_test_001__reverseHolo');
 await Promise.all([c.runCollectionValueRefresh(),c.runCollectionValueRefresh()]);
 assert.equal(requests(),1);const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(c.fixture,stats),values=c.calculateProfileValues(cards,stats);
 assert.equal(cards.length,1);assert.equal(values.dex.pence,850);assert.equal(values.sets.pence,850);assert.equal(values.dex.missing.size,0);assert.equal(values.sets.missing.size,0);
 c.activeUid='b';c.memCardCol.clear();c.memSetCardVariants.clear();const empty=c.calculateProfileValues(c.sharedProfileValueCards(c.fixture,c.calculateProfileStats()),c.calculateProfileStats());assert.equal(empty.dex.pence,0);assert.equal(empty.sets.pence,0);
});
test('ambiguous aliases and wrong printing names are rejected',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Different Pikachu',setName:'Test',number:'1',priceGBP:'2'};
 assert.equal(c.sharedPriceRecordForCard(local,c.fixture),null);
 c.memCardCol.add('old-1');c.currentCardsList=[local];const cards=c.sharedProfileValueCards(c.fixture,c.calculateProfileStats());assert.equal(cards.length,1);assert.equal(cards[0].name,'Different Pikachu');assert.equal(cards[0].priceGBP,'2');
 const duplicate=structuredClone(c.fixture);duplicate.cards['test-1']={...duplicate.cards['test-001'],name:'Other'};
 assert.equal(c.sharedPriceLookup(duplicate).get('fp_test_1'),null);
});
test('bootstrap or broken shared file does not erase local estimates',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Pikachu',setName:'Test',number:'1',priceGBP:'2',_priceQuote:{amount:2,currency:'EUR',updated:'2026-10-27'}};
 const patch=c.sharedPricePatch(local,{quote:null,checkedAt:'2026-10-28T04:00:00Z'},'test-001');assert.equal(patch._priceQuote.amount,2);assert.equal(patch._sharedPriceRetained,true);
 assert.equal(c.validSharedPriceDocument({schemaVersion:1,cards:{},sets:{},generatedAt:null}),false);
});
test('a broken or older deployed price file cannot overwrite the last good snapshot',async()=>{
 const {c}=await client();const good=await c.loadSharedPrices();assert.equal(good.generatedAt,c.fixture.generatedAt);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({schemaVersion:1,cards:{},sets:{},generatedAt:null});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);assert.equal(c.sharedPriceFetchError,true);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({...c.fixture,generatedAt:'2026-10-20T00:00:00Z'});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);
});

const regressions=JSON.parse(await readFile(new URL('./finish-regressions.json',import.meta.url),'utf8'));
test('all eight audited finish regressions recover their exact marketplace quote',()=>{
 assert.equal(Object.keys(regressions).length,8);
 for(const [id,card] of Object.entries(regressions)){
  const quote=selectQuote(card);assert.ok(quote,id+' must be priced');assert.equal(quote.source,'TCGplayer market');
  const source=Object.values(card.pricing.tcgplayer).find(v=>v&&typeof v==='object'&&v.marketPrice===quote.amount);
  assert.ok(source,id+' must use a market quote from the same source card');
 }
});
test('no normal-to-reverse price substitution when both printings exist',()=>{
 const c=structuredClone(regressions['np-3']);c.variants.normal=true;c.variants_detailed.push({type:'normal',variantId:'actual-normal',pricing:null});
 assert.equal(baseFinish(c),'normal');assert.equal(selectQuote(c),null);
});
test('a mismatched nested product is not borrowed for the selected base finish',()=>{
 const c=structuredClone(regressions['np-35']);const normal=c.variants_detailed.find(v=>v.type==='normal');normal.thirdParty.tcgplayer='different-product';
 assert.equal(selectQuote(c),null);
});
test('an ordinary holo is preferred over a stamped championship normal reprint',()=>{
 assert.equal(baseFinish(regressions['ex16-101']),'holo');assert.equal(baseFinish(regressions['ex8-105']),'holo');
});
test('model upgrade rechecks cached N/A while reusing same-day valid quotes',async()=>{
 const now='2026-10-28T04:00:00Z',previous={schemaVersion:1,sets:{},cards:{
  'test-1':{name:'Pikachu',number:'1',setId:'test',quote:null,checkedAt:now,lastAttemptAt:now},
  'test-2':{name:'Pikachu',number:'2',setId:'test',quote:{amount:5,currency:'EUR'},checkedAt:now,lastAttemptAt:now}
 }};
 const calls=[];const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'test',name:'Test'}]);
  if(url.endsWith('/cards'))return response([1,2].map(n=>({id:'test-'+n,name:'Pikachu'})));
  if(url.includes('/cards/')){calls.push(url);return response(card(url.split('/').pop()));}
  return new Response('',{status:404});
 };
 const data=await buildSnapshot({previous,fetchImpl,now});assert.equal(calls.length,1);assert.match(calls[0],/test-1$/);assert.equal(data.cards['test-1'].quote.amount,10);assert.equal(data.summary.reused,1);
});

test('physical-card coverage includes unmatched cards and deduplicates saved aliases',async()=>{
 const {c}=await client();
 c.memCardCol=new Set(['old-1','fp_test_1','not-in-feed']);
 const a={id:'old-1',name:'Pikachu',setName:'Test',number:'1',priceGBP:'2',_priceCheckedAt:1};
 const b={...a,id:'test-001',_valueOwnershipKeys:['old-1','fp_test_1'],priceGBP:'3',_priceCheckedAt:2};
 const value=c.calculateProfileValues([a,b],{ownedCardKeys:new Set()}).dex;
 assert.equal(value.total,2);assert.equal(value.priced,1);assert.equal(value.unpriced,1);assert.equal(value.pence,300);
 assert.equal(value.unpricedCards[0].reason,'unmatched_card');
});
test('twenty individual cards remain twenty regardless of the unique-Pokemon counter',async()=>{
 const {c}=await client();c.memCol=new Set(Array.from({length:19},(_,i)=>i+1));
 const cards=Array.from({length:20},(_,i)=>({id:'t-'+i,name:'Pikachu',setName:'Test',number:String(i),priceGBP:'1'}));
 c.memCardCol=new Set(cards.map(card=>card.id));const total=c.calculateProfileValues(cards,{ownedCardKeys:new Set()}).dex;
 assert.equal(total.total,20);assert.equal(total.priced,20);assert.equal(total.pence,2000);
});
test('missing-price examples distinguish absent quotes from unmatched collection entries',async()=>{
 const {c}=await client();c.fixture.cards['test-001'].quote=null;c.fixture.cards['test-001'].noPriceReason='source_pricing_empty';
 c.memCardCol.add('old-1');c.memCardCol.add('unknown-printing');
 const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(c.fixture,stats),value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,2);assert.equal(value.priced,0);assert.equal(value.unpriced,2);
 assert.equal(value.unpricedCards.filter(c=>c.reason==='source_pricing_empty').length,1);
 assert.equal(value.unpricedCards.filter(c=>c.reason==='unmatched_card').length,1);
});
test('actual collection fingerprints match three Classic Collection reprints',async()=>{
 const {c}=await client();const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.resolveSetName=s=>s?.name||'';c.normalizeCardNumber=n=>String(n).replace(/^0+/,'');
 vm.runInContext(html.slice(html.indexOf('const CLASSIC_COLLECTION_CARDS ='),html.indexOf('// v150: exact')),c);
 for(const name of ['getClassicCollectionIdentity','get30thClassicCollectionKey','getCardFingerprint','getPromoOwnershipKeys','promoOwnershipSetNames','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const data={schemaVersion:1,generatedAt:'2026-10-28T04:00:00Z',sets:{cel25cc:{name:'Celebrations Classic Collection',aliases:['cel25cc','cel25c'],names:['Celebrations Classic Collection']}},cards:{}};
 for(const [number,name] of [['CC001','Blastoise'],['CC002','Charizard'],['CC003','Venusaur']]){
  const id='cel25cc-'+number;data.cards[id]={name,number,setId:'cel25cc',quote:{amount:10,currency:'EUR'}};
  c.memSetCardVariants.add('fp_celebrationsclassiccollection_'+name.toLowerCase()+'__holo');
 }
 const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(data,stats),value=c.calculateProfileValues(cards,stats).sets;
 assert.equal(value.total,3);assert.equal(value.priced,3);assert.equal(value.pence,2550);assert.equal(value.missing.size,0);
 // A different named reprint with the same printed number must remain distinct.
 data.sets['30th-c']={name:'30th Classic Collection',aliases:['30th-c'],names:['30th Classic Collection']};
 data.cards['30th-c-001']={name:'Charizard',number:'001',setId:'30th-c',quote:null};c.sharedPriceIndex=null;
 assert.equal(c.sharedPriceLookup(data).get('fp_30thcelebrationclassiccollection_charizard'),'30th-c-001');
});

test('Dex total and coverage use only its nineteen checked cards, excluding Sets-only and cached cards',async()=>{
 const {c}=await client();
 const cards=Array.from({length:22},(_,i)=>({id:'t-'+i,name:'Pikachu',setName:'Test',number:String(i),priceGBP:i<19?'1':'100'}));
 c.memCardCol=new Set(cards.slice(0,19).flatMap(card=>c.getCardOwnershipKeys(card)));
 const stats={ownedCardKeys:new Set(cards.slice(19,21).map(c.getCardFingerprint))};
 const totals=c.calculateProfileValues(cards,stats);
 assert.equal(totals.dex.total,19);assert.equal(totals.dex.priced,19);assert.equal(totals.dex.pence,1900);
 assert.equal(totals.dex.selectedCards.length,19);assert.equal(totals.sets.total,2);assert.equal(totals.sets.pence,20000);
 c.memCardCol.clear();assert.equal(c.calculateProfileValues(cards,stats).dex.pence,0);
});
test('SV Promos aliases resolve the screenshot warnings once and unchecking removes every saved reference',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.get30thClassicCollectionKey=()=>'';c.getClassicCollectionIdentity=()=>null;
 for(const name of ['getPromoOwnershipKeys','promoOwnershipSetNames','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8'));
 const data={schemaVersion:1,generatedAt:'2026-10-28T19:00:00Z',sets:{svp:{name:'SVP Black Star Promos',aliases:['svp'],names:['SVP Black Star Promos']}},cards:{}};
 for(const id of ['svp-074','svp-075'])data.cards[id]=priceRecord(fixture[id],null,data.generatedAt);
 c.memCardCol=new Set(['svp-74','fp_svpromos_74','svp-75','fp_svpromos_75']);
 let stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(data,stats),value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,2);assert.equal(value.priced,2);assert.equal(value.missing.size,0);
 assert.equal(new Set(value.selectedCards.map(c=>c.name)).size,2);
 const visible={id:'svp-075',name:'Mimikyu',setName:'SVP Black Star Promos',number:'075'};
 assert.equal(c.isCardCollected(visible),true);
 for(const key of c.getCardOwnershipKeys(visible))c.memCardCol.delete(key);
 assert.equal(c.isCardCollected(visible),false);
 stats=c.calculateProfileStats();cards=c.sharedProfileValueCards(data,stats);value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,1);assert.equal(value.priced,1);assert.equal(value.selectedCards[0].name,'Charizard ex');
});
test('30th Celebration cards remain N/A when the actual response has no marketplace quotes',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8'));
 for(const id of ['30th-001','30th-002','30th-003']){
  const record=priceRecord(fixture[id],null,'2026-10-28T19:00:00Z');
  assert.equal(record.quote,null);assert.equal(record.noPriceReason,'source_pricing_empty');
 }
});

const {indexCardmarket,directCardmarketQuote,preferDirectQuote}=await import('../scripts/cardmarket-source.mjs');
const extractFixture=()=>{
 const names=['Exeggcute [Hypnosis]','Alolan Exeggutor [Scale Up | Mega Drain]','Volbeat [Luring Glow | Bug Buzz]'];
 const products={products:names.map((name,i)=>({idProduct:907607+i,idCategory:51,idExpansion:6601,name}))};
 const prices={version:1,createdAt:'2026-10-28T02:45:21+0100',priceGuides:names.map((_,i)=>({idProduct:907607+i,idCategory:51,trend:[.05,.06,.05][i]}))};
 return {products,prices};
};
test('three real 30th Celebration responses recover direct Cardmarket prices and the extract date',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{products,prices}=extractFixture(),data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 for(const [i,id] of ['30th-001','30th-002','30th-003'].entries()){
  const record=priceRecord(fixture[id],null,'2026-10-28T20:00:00Z',data);
  assert.equal(record.quote.amount,[.05,.06,.05][i]);assert.equal(record.quote.productId,907607+i);assert.equal(record.quote.via,'Cardmarket daily extract');assert.equal(record.quote.updated,prices.createdAt);
 }
});
test('direct release matching rejects ambiguity, wrong attacks and a different release',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{products,prices}=extractFixture();
 products.products.push({...products.products[2],idProduct:999});
 const data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 assert.equal(directCardmarketQuote({...fixture['30th-003'],id:'30th-004',localId:'004',_cardmarketNameUnique:true},data),null);
 assert.equal(directCardmarketQuote({...fixture['30th-002'],attacks:[{name:'Wrong move'}]},data),null);
 assert.equal(directCardmarketQuote({...fixture['30th-003'],set:{id:'30th-c',name:'30th Classic Collection'}},data),null);
});
test('direct downloads retain the source order and do not replace newer source days',()=>{
 const market={amount:8,currency:'USD',source:'TCGplayer market',priority:1,updated:'2026-10-28'};
 assert.equal(preferDirectQuote(market,{amount:6,priority:2}),market);
 assert.equal(preferDirectQuote(market,{amount:6,priority:0}).amount,6);
 const latest={amount:9,priority:0,updated:'2026-10-29'};assert.equal(preferDirectQuote(latest,{amount:6,priority:0,updated:'2026-10-28'}),latest);
 const {prices,products}=extractFixture();assert.throws(()=>indexCardmarket({...prices,version:99},products),/Invalid/);assert.throws(()=>indexCardmarket(prices,products,Date.parse('2026-12-01')),/stale/);
});
test('explicit products require the exact card name and preserve the holo field distinction',()=>{
 const {prices,products}=extractFixture();products.products.push({idProduct:123,idCategory:51,idExpansion:123,name:'Pikachu [Tackle]'});prices.priceGuides.push({idProduct:123,idCategory:51,trend:2,'trend-holo':20});
 const data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 const c={name:'Pikachu',variants:{normal:true,holo:true},pricing:{cardmarket:{idProduct:123}},variants_detailed:[{type:'holo',variantId:'h'}]};
 assert.equal(directCardmarketQuote(c,data).amount,20);
 assert.equal(directCardmarketQuote({...c,name:'Charizard'},data),null);
});
test('a newly available direct extract rechecks same-day cached N/A entries',async()=>{
 const fixtures=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{prices,products}=extractFixture(),now='2026-10-28T20:00:00Z',directData=indexCardmarket(prices,products,Date.parse(now));
 const previous={schemaVersion:1,sets:{},cards:{'30th-001':{name:'Exeggcute',number:'001',setId:'30th',quote:null,pricingModelVersion:245,lastAttemptAt:now,cardmarketExtractChecked:null}}};
 const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'30th',name:'30th Celebration'}]);
  if(url.endsWith('/cards'))return response([{id:'30th-001',name:'Exeggcute'}]);
  if(url.endsWith('/cards/30th-001'))return response(fixtures['30th-001']);
  return response([]);
 };
 const result=await buildSnapshot({previous,directData,fetchImpl,now});
 assert.equal(result.summary.requested,1);assert.equal(result.summary.priced,1);assert.equal(result.cards['30th-001'].quote.amount,.05);assert.equal(result.cards['30th-001'].cardmarketExtractChecked,prices.createdAt);
});

test('collected cards sort before higher-art, rarer and more valuable uncollected cards',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const start=html.indexOf('function sortCardsList(cards)');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 c.getPokemonCardArtPriority=card=>card.art;
 const owned={id:'svp-75',name:'Mimikyu',setName:'SV Promos',number:'75',art:2,rarityScore:1,priceGBP:'9.43'};
 const special={id:'me2pt5-238',name:"Team Rocket’s Mimikyu",setName:'Ascended Heroes',number:'238',art:4,rarityScore:99,priceGBP:'11.46'};
 const costly={id:'sm8-226',name:'Mimikyu-GX',setName:'Lost Thunder',number:'226',art:2,rarityScore:98,priceGBP:'145.93'};
 c.memCardCol.add('svp-75');const cards=[special,costly,owned];c.sortCardsList(cards);
 assert.equal(cards[0].id,'svp-75');assert.equal(cards[1].id,special.id);
 c.memCardCol.add(costly.id);c.sortCardsList(cards);assert.deepEqual(cards.slice(0,2).map(c=>c.id).sort(),[owned.id,costly.id].sort());
 c.memCardCol.delete(owned.id);c.sortCardsList(cards);assert.equal(cards[0].id,costly.id);assert.equal(cards[1].id,special.id);
});

test('screenshot regression: twenty saved entries with Tropius outside Owned Dex value nineteen cards',async()=>{
 const {c}=await client();
 const names=['Ambipom','Centiskorch V','Charizard ex','Comfey','Dachsbun ex','Dhelmise','Drapion','Larvitar','Lunatone','Mega Audino ex','Mimikyu','Musharna','Nymble','Oricorio ex','Pinsir','Reuniclus','Skarmory','Sliggoo','Toxtricity','Tropius'];
 const ids=[424,851,6,764,927,781,452,246,337,531,778,518,919,741,127,579,227,705,849,357];
 c.dir=names.map((name,i)=>({id:ids[i],name:name.replace(/^Mega /,'').replace(/ (ex|V)$/,''),cleanName:name.replace(/^Mega /,'').replace(/ (ex|V)$/,'')}));c.memCol=new Set(ids.slice(0,19));
 const cards=names.map((name,i)=>({id:'s-'+i,name,setName:'Test',number:String(i),priceGBP:i===19?'.02':'1'}));
 c.memCardCol=new Set(cards.flatMap(card=>c.getCardOwnershipKeys(card)));
 const stats={ownedCardKeys:new Set([c.getCardFingerprint(cards[19])])},result=c.calculateProfileValues(cards,stats);
 assert.equal(result.dex.total,19);assert.equal(result.dex.priced,19);assert.equal(result.dex.pence,1900);assert.equal(result.dex.selectedCards.some(c=>c.name==='Tropius'),false);
 assert.equal(result.sets.total,1);assert.equal(result.sets.pence,2);assert.equal(c.memCardCol.has('s-19'),true,'legacy saved references are not destructively deleted');
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('function isCardCollected(card)');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 assert.equal(c.isCardCollected(cards[19]),false);assert.equal(c.isCardCollected(cards[0]),true);
 // A deliberate tick reactivates Tropius through the same normal handler.
 c.initAudio=()=>{};c.playTick=()=>{};c.requireCollectionSignIn=()=>true;c.curId=null;c.activeDexModalPoke=null;c.curPoke=null;c.currentCardsList=[cards[19]];c.saveLocalState=()=>{};c.sortCardsList=()=>{};c.writeFullCollectionToCloud=()=>{};
 const toggle=html.indexOf('function toggleCardCollection(');vm.runInContext(html.slice(toggle,html.indexOf('\n}',toggle)+2),c);
 c.toggleCardCollection(cards[19].id,357);assert.equal(c.memCol.has(357),true);assert.equal(c.isCardCollected(cards[19]),true);assert.equal(c.calculateProfileValues(cards,stats).dex.total,20);
 c.toggleCardCollection(cards[19].id,357);assert.equal(c.memCol.has(357),false);assert.equal(c.calculateProfileValues(cards,stats).dex.total,19);assert.equal(result.sets.pence,2);
});
test('removing a visible card preserves its Pokemon when another checked card is cached outside the current list',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.memCol=new Set([227]);c.dir=[{id:227,name:'Skarmory'}];
 const a={id:'s-1',name:'Skarmory',setName:'Test',number:'1',priceGBP:'1'},b={...a,id:'s-2',number:'2'};
 c.memCardCol=new Set([...c.getCardOwnershipKeys(a),...c.getCardOwnershipKeys(b)]);c.currentCardsList=[a];c.memoryTcgCache.set('other',{data:[b]});
 c.initAudio=()=>{};c.playTick=()=>{};c.requireCollectionSignIn=()=>true;c.curId=null;c.activeDexModalPoke=null;c.curPoke=null;c.saveLocalState=()=>{};c.sortCardsList=()=>{};c.writeFullCollectionToCloud=()=>{};
 for(const name of ['isCardCollected','toggleCardCollection']){const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);}
 c.toggleCardCollection(a.id,227);assert.equal(c.memCol.has(227),true);assert.equal(c.isCardCollected(a),false);assert.equal(c.isCardCollected(b),true);
});

test('missing-price summary shows the total and limits each section to three examples',async()=>{
 const {c}=await client();const node=()=>({children:[],textContent:'',appendChild(x){this.children.push(x)},replaceChildren(){this.children=[]}});
 const nodes={profileUnpricedDetails:node(),profileUnpricedSummary:node(),profileUnpricedExamples:node()};
 c.document.getElementById=id=>nodes[id]||null;c.document.createElement=()=>node();
 const card=i=>({name:'Card '+i,setName:'Test',number:String(i),reason:'source_pricing_empty'});
 c.paintProfileUnpricedExamples({dex:{unpriced:2,unpricedCards:[card(1),card(2)]},sets:{unpriced:5,unpricedCards:[1,2,3,4,5].map(card)}});
 assert.equal(nodes.profileUnpricedSummary.textContent,'Cards without prices (7)');
 assert.equal(nodes.profileUnpricedExamples.children[1].children.length,2);
 assert.equal(nodes.profileUnpricedExamples.children[3].children.length,3);
 assert.match(nodes.profileUnpricedExamples.children[3].children[0].textContent,/exact card printing/);
});

const exactFixture=JSON.parse(await readFile(new URL('./exact-identity-regressions.json',import.meta.url),'utf8'));
const {hydrateCardmarketIdentity}=await import('../scripts/cardmarket-source.mjs');
const gapFixture=JSON.parse(await readFile(new URL('./catalogue-gap-regressions.json',import.meta.url),'utf8'));
function gapData(){const d=indexCardmarket(gapFixture.prices,gapFixture.products,Date.parse('2026-10-29T08:00:00Z'));d.identities=structuredClone(gapFixture.identities);return d;}
test('published promos omitted by the API catalogue get exact quotes without individual API calls',async()=>{
 const data=gapData(),calls=[];
 const fetchImpl=async url=>{calls.push(url);
  if(url.endsWith('/sets'))return response([{id:'mep',name:'MEP Black Star Promos'},{id:'30th',name:'30th Celebration'}]);
  if(url.endsWith('/cards'))return response([{id:'test-1',name:'Pikachu'}]);
  if(url.endsWith('/cards/test-1'))return response(card());
  return new Response('',{status:404});
 };
 const result=await buildSnapshot({directData:data,fetchImpl,now:'2026-10-29T08:00:00Z'});
 for(const [id,amount,sku] of [['mep-094',.43,895609],['mep-096',.26,895606]]){
  assert.equal(result.cards[id].quote.amount,amount);assert.equal(result.cards[id].quote.productId,sku);
  assert.equal(result.cards[id].baseFinish,'holo');assert.equal(result.cards[id].quote.updated,gapFixture.prices.createdAt);
 }
 assert.equal(result.summary.sourceOnlyCards,26);assert.equal(result.summary.sourceOnlyPriced,16);
 assert.equal(result.cards['mep-102'].quote,null,'a real source identity without a usable quote remains N/A');
 assert.equal(result.summary.failed,0);assert.equal(result.summary.requested,1);
 assert.equal(calls.some(url=>/cards\/mep-/.test(url)),false);
});
test('a source-only promo with a wrong product expansion is excluded rather than borrowed',async()=>{
 const data=gapData();data.identities.cards['mep-094'].expansionId=6601;
 const fetchImpl=async url=>url.endsWith('/sets')?response([{id:'mep',name:'MEP Black Star Promos'}]):url.endsWith('/cards')?response([{id:'test-1',name:'Pikachu'}]):url.endsWith('/cards/test-1')?response(card()):response([]);
 const result=await buildSnapshot({directData:data,fetchImpl,now:'2026-10-29T08:00:00Z'});
 assert.equal(result.cards['mep-094'],undefined);assert.ok(result.cards['mep-096'].quote);
});
test('Palkia LV.X is an exact printing alias, never a general Palkia substitution',()=>{
 const data=gapData(),source={id:'30th-c-022',name:'Palkia',localId:'022',set:{id:'30th-c'},variants:{normal:true},variants_detailed:[{variantId:'generated',type:'normal'}]};
 const r=priceRecord(source,null,'2026-10-29T08:00:00Z',data);
 assert.equal(r.quote.productId,907950);assert.equal(r.quote.amount,12.7);assert.equal(r.baseFinish,'holo');
 assert.deepEqual(r.nameAliases,['Palkia LV.X']);assert.equal(r.printedNumber,'106');
 for(const c of [{...source,id:'30th-020',localId:'020',set:{id:'30th'}},{...source,localId:'106'},{...source,name:'Dialga'}]){
  assert.equal(priceRecord(c,null,'2026-10-29T08:00:00Z',data).quote,null);
 }
 data.catalogue.set(907950,{...data.catalogue.get(907950),idExpansion:999});
 assert.equal(priceRecord(source,null,'2026-10-29T08:00:00Z',data).quote,null);
});
test('the saved LV.X reprint fingerprint matches once, with a strict alias name check',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.getClassicCollectionIdentity=()=>null;c.normalizeCardNumber=n=>String(n).replace(/^0+/,'');
 for(const name of ['normalizePokemonCardName','get30thClassicCollectionKey','getCardFingerprint','getPromoOwnershipKeys','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const data=gapData(),record=priceRecord({id:'30th-c-022',name:'Palkia',localId:'022',set:{id:'30th-c'},variants:{}},null,'2026-10-29T08:00:00Z',data);
 const doc={schemaVersion:1,generatedAt:'2026-10-29T08:00:00Z',sets:{'30th-c':{name:'30th Classic Collection',aliases:['30th-c']}},cards:{'30th-c-022':record}};
 const saved={id:'old-palkia-106',name:'Palkia LV.X',number:'106',setName:'30th Celebration: Classic Collection'};
 c.memSetCardVariants.add(c.getCardFingerprint(saved)+'__holo');c.currentCardsList=[saved];
 assert.equal(c.sharedPriceRecordForCard(saved,doc).id,'30th-c-022');
 assert.equal(c.sharedPriceRecordForCard({...saved,name:'Palkia ex'},doc),null);
 const stats=c.calculateProfileStats(),value=c.calculateProfileValues(c.sharedProfileValueCards(doc,stats),stats).sets;
 assert.equal(value.total,1);assert.equal(value.priced,1);assert.equal(value.unpriced,0);
});
test('seven new promos and Palkia price from saved collection keys with no card-opening cache',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.getClassicCollectionIdentity=()=>null;c.normalizeCardNumber=n=>String(n).replace(/^0+/,'');
 for(const name of ['normalizePokemonCardName','get30thClassicCollectionKey','getCardFingerprint','getPromoOwnershipKeys','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const data=gapData(),doc={schemaVersion:1,generatedAt:'2026-10-29T08:00:00Z',sets:{mep:{name:'MEP Black Star Promos',aliases:['mep']},'30th-c':{name:'30th Classic Collection',aliases:['30th-c']}},cards:{}};
 for(const id of ['30th-c-022',...Array.from({length:7},(_,i)=>'mep-'+String(94+i).padStart(3,'0'))]){
  const e=data.identities.cards[id];doc.cards[id]=priceRecord({id,name:e.name,localId:e.number,set:{id:e.setId},variants:{}},null,doc.generatedAt,data);
 }
 c.memSetCardVariants.add('fp_30thcelebrationclassiccollection_palkialvx__holo');
 for(let n=94;n<=100;n++)c.memSetCardVariants.add('fp_megaevolutionpromos_'+n+'__holo');
 const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(doc,stats),value=c.calculateProfileValues(cards,stats).sets;
 assert.equal(c.currentCardsList.length,0);assert.equal(value.total,8);assert.equal(value.priced,8);assert.equal(value.unpriced,0);
 assert.equal(new Set(value.selectedCards.map(c=>c.cardId)).size,8);
});
function exactData(){const d=indexCardmarket(exactFixture.prices,exactFixture.products,Date.parse('2026-10-28T23:00:00Z'));d.identities=structuredClone(exactFixture.identities);return d;}
test('published source IDs resolve the three reported failures without description or price guesses',()=>{
 const data=exactData();
 for(const [id,amount,sku] of [['30th-010',.06,907736],['30th-011',.13,907617],['30th-015',.42,907621]]){
  const r=priceRecord(exactFixture.cards[id],null,'2026-10-28T23:00:00Z',data);
  assert.equal(r.quote.amount,amount);assert.equal(r.quote.productId,sku);assert.equal(r.identitySourceApplied,true);
 }
});
test('Moltres and Fuecoco illustration printings use separate exact product IDs',()=>{
 const data=exactData();
 for(const [id,expected,sku] of [['30th-130',4.89,907738],['30th-147',13.61,907754]]){
  const e=data.identities.cards[id],c={id,name:e.name,localId:e.number,set:{id:e.setId},variants:{normal:true},variants_detailed:[{type:'normal',variantId:'generated'}]};
  const record=priceRecord(c,null,'2026-10-28T23:00:00Z',data);
  assert.equal(record.quote.amount,expected);assert.equal(record.quote.productId,sku);
 }
});
test('identity hydration rejects mismatched number, name and expansion',()=>{
 const data=exactData(),c=exactFixture.cards['30th-011'];
 assert.equal(hydrateCardmarketIdentity({...c,localId:'130'},data)._identityMapRejected,true);
 assert.equal(hydrateCardmarketIdentity({...c,name:'Articuno'},data)._identityMapRejected,true);
 data.identities.cards[c.id].expansionId=999;
 assert.equal(hydrateCardmarketIdentity(c,data)._identityMapRejected,true);
 assert.equal(priceRecord(c,null,'2026-10-28T23:00:00Z',data).quote,null);
});
test('conflicting explicit detailed IDs are preserved for review and excluded from prices',()=>{
 const data=exactData(),c=structuredClone(exactFixture.cards['30th-011']);
 c.variants_detailed=[{variantId:'live',type:'normal',thirdParty:{cardmarket:907738}}];
 assert.equal(hydrateCardmarketIdentity(c,data)._identityMapRejected,true);
 assert.equal(hydrateCardmarketIdentity(c,data).variants_detailed,c.variants_detailed);
 assert.equal(priceRecord(c,null,'2026-10-29T12:00:00Z',data).quote,null);
});
test('an identity-map revision invalidates a same-day cached unpriced entry',async()=>{
 const data=exactData(),now='2026-10-28T23:00:00Z',previous={schemaVersion:1,sets:{},cards:{'30th-011':{name:'Moltres',number:'011',setId:'30th',quote:null,pricingModelVersion:249,lastAttemptAt:now,cardmarketExtractChecked:data.updated,identityMapVersion:'old-map'}}};
 const fetchImpl=async url=>url.endsWith('/sets')?response([{id:'30th',name:'30th Celebration'}]):url.endsWith('/cards')?response([{id:'30th-011',name:'Moltres'}]):url.endsWith('/cards/30th-011')?response(exactFixture.cards['30th-011']):response([]);
 const snapshot=await buildSnapshot({previous,directData:data,fetchImpl,now});
 assert.equal(snapshot.summary.requested,1);assert.equal(snapshot.cards['30th-011'].quote.productId,907617);
});

const mappingFixture=JSON.parse(await readFile(new URL('./pikachu-mapping-regression.json',import.meta.url),'utf8'));
const {auditIdentities}=await import('../scripts/identity-policy.mjs');
function mappingData(){const d=indexCardmarket(mappingFixture.prices,mappingFixture.products,Date.parse('2026-10-29T12:00:00Z'));d.identities=structuredClone(mappingFixture.identities);return d;}
test('RC29 uses its corrected exact product, not the same-name Generations 26 product or foil bucket',()=>{
 const data=mappingData(),r=priceRecord(mappingFixture.card,{quote:{amount:3.9,currency:'EUR',updated:'2099-01-01'}},'2026-10-29T12:00:00Z',data);
 assert.equal(r.quote.productId,288538);assert.equal(r.quote.amount,147.46);assert.equal(r.quote.fieldSuffix,'');assert.equal(r.baseFinish,'holo');assert.equal(r.rejectCachedQuote,true);
 const ordinary={...mappingFixture.card,id:'g1-26',localId:'26'};const p=priceRecord(ordinary,null,'2026-10-29T12:00:00Z',data);
 assert.notEqual(p.quote?.productId,288538);assert.equal(p.identityStatus,undefined);
 assert.equal(priceRecord({...mappingFixture.card,name:'Raichu'},null,'2026-10-29T12:00:00Z',data).quote,null);
 assert.equal(priceRecord(mappingFixture.card,{quote:{amount:3.9}},'2026-10-29T12:00:00Z',null).quote,null);
});
test('duplicate IDs across different card numbers are reviewed and never retained as old prices',()=>{
 const data=mappingData();data.identities.cards['g1-99']={...data.identities.cards['g1-26'],number:'99'};
 const report=auditIdentities(data);assert.equal(report.conflicts.length,1);
 const c={...mappingFixture.card,id:'g1-99',localId:'99'};const r=priceRecord(c,{quote:{amount:200}},'2026-10-29T12:00:00Z',data);
 assert.equal(r.quote,null);assert.equal(r.noPriceReason,'identity_conflict');assert.equal(r.retained,false);assert.equal(r.rejectCachedQuote,true);
});
test('network failure after policy invalidation cannot resurrect an incorrect previous quote',async()=>{
 const data=mappingData(),now='2026-10-29T12:00:00Z';
 const previous={schemaVersion:1,sets:{},cards:{'g1-RC29':{name:'Pikachu',setId:'g1',number:'RC29',quote:{amount:3.9,currency:'EUR'}}}};
 const fetchImpl=async url=>url.endsWith('/sets')?response([{id:'g1',name:'Generations'}]):url.endsWith('/cards')?response([{id:'g1-RC29',name:'Pikachu'},{id:'test-1',name:'Pikachu'}]):url.endsWith('/cards/test-1')?response(card()):new Response('',{status:404});
 const result=await buildSnapshot({previous,directData:data,fetchImpl,now});assert.equal(result.summary.failed,1);assert.equal(result.cards['g1-RC29'].quote.productId,288538);
});
test('audited snapshot wins over a newer bad phone cache, clears numeric fallbacks, and survives live refresh',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const local={id:'g1-RC29',name:'Pikachu',number:'RC29',setName:'Generations',priceGBP:'3.27',_priceQuote:{amount:3.9,currency:'EUR',updated:'2099-01-01'}};
 const record=priceRecord(mappingFixture.card,null,'2026-10-29T12:00:00Z',mappingData());
 assert.equal(c.sharedPricePatch(local,record,local.id)._priceQuote.amount,147.46);
 const blocked={...record,quote:null,noPriceReason:'identity_conflict'};const patch=c.sharedPricePatch(local,blocked,local.id);assert.equal(patch.priceGBP,null);assert.equal(patch._priceQuote,null);
 c.fixture={schemaVersion:1,generatedAt:'2026-10-29T12:00:00Z',sets:{g1:{name:'Generations',aliases:['g1']}},cards:{'g1-RC29':record}};
 vm.runInContext('sharedPriceDocument=fixture',c);
 const start=html.indexOf('function updateTcgCardPriceFromDetail(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 c.getTcgDexBasePriceGBP=()=>{throw new Error('known bad live quote must not be consulted')};
 c.updateTcgCardPriceFromDetail(local,mappingFixture.card);assert.equal(local._priceQuote.productId,288538);
 c.fixture.cards['g1-RC29']=blocked;c.updateTcgCardPriceFromDetail(local,mappingFixture.card);assert.equal(local.priceGBP,null);
});

const printingFixture=JSON.parse(await readFile(new URL('./printing-price-regression.json',import.meta.url),'utf8'));
function printingData(){const d=indexCardmarket(printingFixture.prices,printingFixture.products,Date.parse('2026-10-29T19:00:00Z'));d.identities=structuredClone(printingFixture.identities);return d;}
test('Miraidon Holo, Reverse and documented Additionals are priced independently',()=>{
 const r=priceRecord(printingFixture.card,null,'2026-10-29T19:00:00Z',printingData());
 assert.equal(r.baseFinish,'holo');assert.equal(r.quote.amount,.06);
 const [holo,reverse,normal]=['holo','reverse','normal'].map(type=>r.printingQuotes.find(v=>v.printing.type===type));
 assert.equal(holo.quote.fieldSuffix,'');assert.equal(holo.quote.amount,.06);
 assert.equal(reverse.quote.fieldSuffix,'-holo');assert.equal(reverse.quote.amount,.14);
 assert.equal(normal.quote.amount,1.35);assert.equal(normal.quote.productId,897295);
});
test('Sets sums checked printings, Dex stays base, unknown and unticked versions contribute nothing',async()=>{
 const {c}=await client(),r=priceRecord(printingFixture.card,null,'2026-10-29T19:00:00Z',printingData());
 const local={id:'me05-028',name:'Miraidon',setName:'Pitch Black',number:'028'};
 const card=c.sharedPricePatch(local,r,local.id),fp=c.getCardFingerprint(card);
 c.memCardCol.add(local.id);c.memSetCardVariants=new Set([fp+'__standard',fp+'__reverseHolo']);
 let stats=c.calculateProfileStats(),v=c.calculateProfileValues([card],stats);
 assert.equal(v.dex.pence,5);assert.equal(v.sets.pence,17);assert.equal(v.sets.total,1);assert.equal(v.sets.priced,1);
 c.memSetCardVariants.add(fp+'__v141:'+encodeURIComponent(JSON.stringify(['holo','','','standard',[]])));
 stats=c.calculateProfileStats();assert.equal(c.calculateProfileValues([card],stats).sets.pence,17,'legacy base references count once');
 c.memSetCardVariants.add(fp+'__v141:'+encodeURIComponent(JSON.stringify(['holo','cosmos','','standard',[]])));
 stats=c.calculateProfileStats();v=c.calculateProfileValues([card],stats);
 assert.equal(v.sets.pence,17);assert.equal(v.sets.unpriced,1);assert.equal(v.sets.priced,0);assert.equal(v.sets.total,1);
 c.memSetCardVariants=new Set([fp+'__reverseHolo']);stats=c.calculateProfileStats();v=c.calculateProfileValues([card],stats);
 assert.equal(v.sets.pence,12,'reverse-only ownership must not add base');assert.equal(v.dex.pence,5);
});
test('a verified additional printing is valued only once and only when selected',async()=>{
 const {c}=await client(),data=printingData();
 // A separate exact product in the right expansion is valid evidence for this test.
 data.catalogue.set(897295,{...data.catalogue.get(897295),idExpansion:6569});
 const r=priceRecord(printingFixture.card,null,'2026-10-29T19:00:00Z',data);
 const local={id:'me05-028',name:'Miraidon',setName:'Pitch Black',number:'028'},card=c.sharedPricePatch(local,r,local.id),fp=c.getCardFingerprint(card);
 const key='v141:'+encodeURIComponent(JSON.stringify(['normal','','','standard',[]]));
 // The documented Holo/Reverse pair remains base; the separate Non Holo is additional.
 assert.equal(r.baseFinish,'holo');assert.equal(r.quote.productId,895815);
 c.memSetCardVariants=new Set([fp+'__standard']);let stats=c.calculateProfileStats();const base=c.calculateProfileValues([card],stats).sets.pence;
 c.memSetCardVariants.add(fp+'__'+key);stats=c.calculateProfileStats();const both=c.calculateProfileValues([card],stats).sets.pence;
 assert.equal(both,base+115);
 c.memSetCardVariants.add(fp+'__other');stats=c.calculateProfileStats();assert.equal(c.calculateProfileValues([card],stats).sets.pence,both,'generic and named references to one alternative deduplicate');
});
test('printing rows show independent prices including verified Additionals',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const r=priceRecord(printingFixture.card,null,'2026-10-29T19:00:00Z',printingData());
 const card=c.sharedPricePatch({id:'me05-028',name:'Miraidon',setName:'Pitch Black',number:'028'},r,'me05-028');
 c.getAvailableSetCardVariants=()=>[{key:'standard',label:'Holo'},{key:'reverseHolo',label:'Reverse'},{key:'v141:'+encodeURIComponent(JSON.stringify(['normal','','','standard',[]])),label:'Non Holo'}];
 c.isSetCardVariantOwned=()=>true;c.getSetVariantCategory=()=>'';c.escapeSetVariantHtml=s=>String(s);c.getSetVariantLabelMarkup=(s,p='')=>s+p;
 const start=html.indexOf('function getSetVariantOptionsMarkup(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 const output=c.getSetVariantOptionsMarkup(card,true);
 assert.match(output,/Holo.*£0.05/);assert.match(output,/Reverse.*£0.12/);assert.match(output,/Non Holo.*£1.15/);
});
test('a shared foil bucket cannot price two distinct foil finishes when normal also uses that product',()=>{
 const data=printingData(),c=structuredClone(printingFixture.card);
 c.variants_detailed.forEach(v=>v.thirdParty.cardmarket=895815);
 assert.equal(directCardmarketQuote(c,data,'reverse'),null);
 assert.equal(directCardmarketQuote(c,data,'holo'),null);
 assert.equal(directCardmarketQuote(c,data,'normal').amount,.06);
});

const auditFixture=JSON.parse(await readFile(new URL('./catalogue-audit-regressions.json',import.meta.url),'utf8'));
const {normalizeMarketplaceName,marketplaceProductName}=await import('../scripts/marketplace-identity.mjs');
const {resolveIdentities}=await import('../scripts/resolve-identities.mjs');
function auditedData(){const d=indexCardmarket(auditFixture.prices,auditFixture.products,Date.parse('2026-10-29T20:00:00Z'));d.identities=structuredClone(auditFixture.identities);resolveIdentities(d,auditFixture.metadata,auditFixture.names);return d;}
test('notation matching preserves Energy types, genders, Delta Species, Greek letters and identity suffixes',()=>{
 const n=normalizeMarketplaceName;
 for(const [a,b] of [['Voltaic Lightning Energy','Voltaic [L] Energy'],['Fighting Energy','[F] Energy'],['Metal Energy','[M] Energy'],['Nidoran♀','Nidoran [F]'],['Nidoran♂','Nidoran [M]'],['Metagross δ','Metagross δ Delta Species'],['Miracle Sphere α','Miracle Sphere alpha'],['Mystery Plate δ','Mystery Plate delta'],['Impostor Professor Oak','Imposter Professor Oak']])assert.equal(n(a),n(b),a);
 assert.notEqual(n('Palkia'),n('Palkia LV.X'));assert.notEqual(n('Pikachu'),n('Pikachu EX'));
 assert.notEqual(n('Fire Energy'),n('[F] Energy'));assert.notEqual(n('Metagross'),n('Metagross δ'));
 assert.equal(marketplaceProductName({name:'Ancient Technical Machine [Ice]'}),n('Ancient Technical Machine [Ice]'));
});
test('actual Voltaic Energy and Miraidon use separate prices for their documented Additionals',()=>{
 const data=auditedData();
 for(const [id,amounts] of [['me05-084',[.08,.17,1.04]],['me05-028',[.06,.14,1.35]]]){
  const r=priceRecord(auditFixture.metadata.cards[id],null,'2026-10-29T20:00:00Z',data);
  assert.equal(r.baseFinish,'holo');assert.equal(r.quote.amount,amounts[0]);
  for(const [i,type] of ['holo','reverse','normal'].entries())assert.equal(r.printingQuotes.find(v=>v.printing.type===type).quote.amount,amounts[i]);
 }
});
test('Additionals rejects a wrong family, metacard, name, undeclared SKU or variant type',()=>{
 for(const change of ['family','metacard','name','type']){
  const d=auditedData(),c=structuredClone(auditFixture.metadata.cards['me05-084']);
  if(change==='type')c.variants_detailed.find(v=>v.type==='normal').type='holo';
  else{const p={...d.catalogue.get(897299)};if(change==='family')p.idExpansion=999;if(change==='metacard')p.idMetacard=1;if(change==='name')p.name='Different Energy';d.catalogue.set(897299,p);}
  const r=priceRecord(c,null,'2026-10-29T20:00:00Z',d);
  assert.equal(r.printingQuotes.some(v=>v.quote?.productId===897299&&(change!=='type'||v.printing.type==='holo')),false,change);assert.ok(r.quote);
 }
});
test('independent set/number printed names safely link LV.X and Delta Species prices',()=>{
 const d=auditedData();
 for(const id of ['dp4-106','ex11-11','ex5-84','base1-73']){
  const r=priceRecord(auditFixture.metadata.cards[id],null,'2026-10-29T20:00:00Z',d);assert.ok(r.quote,id);
 }
 const r=priceRecord(auditFixture.metadata.cards['dp4-106'],null,'2026-10-29T20:00:00Z',d);assert.ok(r.nameAliases.includes('Palkia LV.X'));
});
test('unique complete-move repair fixes the actual unrelated Team Aqua product without merging Pikachu printings',()=>{
 const d=auditedData(),repair=d.mappingRepairs.find(r=>r.cardId==='ex4-1');assert.equal(repair.productId,275978);
 const r=priceRecord(auditFixture.metadata.cards['ex4-1'],null,'2026-10-29T20:00:00Z',d);assert.equal(r.quote.productId,275978);
 assert.equal(d.mappingRepairs.some(r=>r.cardId==='g1-RC29'||r.cardId==='g1-26'),false);
 const pika=priceRecord(auditFixture.metadata.cards['g1-RC29'],null,'2026-10-29T20:00:00Z',d);assert.equal(pika.quote.productId,288538);
});
test('a source sibling without a marketplace ID prevents a false unique-signature repair',()=>{
 const d=indexCardmarket(auditFixture.prices,auditFixture.products,Date.parse('2026-10-29T20:00:00Z'));d.identities=structuredClone(auditFixture.identities);
 const meta=structuredClone(auditFixture.metadata);meta.cards['ex4-999']={...meta.cards['ex4-1'],id:'ex4-999',localId:'999'};
 resolveIdentities(d,meta,auditFixture.names);assert.equal(d.mappingRepairs.some(r=>r.cardId==='ex4-1'),false);
});
test('market download failure preserves a previously audited quote and its original source date',()=>{
 const c=auditFixture.metadata.cards['me05-084'],r=priceRecord(c,null,'2026-10-29T20:00:00Z',auditedData());
 const kept=priceRecord(c,r,'2026-10-30T01:00:00Z',{updated:null,catalogue:new Map(),guide:new Map(),identities:auditFixture.identities});
 assert.equal(kept.quote.amount,.08);assert.equal(kept.quote.updated,r.quote.updated);assert.equal(kept.retained,true);assert.deepEqual(kept.printingQuotes,r.printingQuotes);
});
test('set expansion repair requires ten independent, exact-name and complete-signature confirmations',()=>{
 function fixture(count){const products={products:[]},prices={version:1,createdAt:'2026-10-29T02:00:00Z',priceGuides:[]},identities={cards:{},sourceSha256:'test'},metadata={cards:{}},names={cards:{},sourceSha256:'names'};
  for(let i=1;i<=count;i++){const id='s-'+i;products.products.push({idProduct:1000+i,idCategory:51,idExpansion:200,name:'Mon'+i+' [Hit'+i+']'});prices.priceGuides.push({idProduct:1000+i,idCategory:51,trend:1});identities.cards[id]={name:'Mon'+i,setId:'s',number:String(i),expansionId:100,thirdParty:{cardmarket:1000+i},variants:[]};metadata.cards[id]={id,name:'Mon'+i,localId:String(i),set:{id:'s'},category:'Pokemon',attacks:[{name:'Hit'+i}]};names.cards[id]={name:'Mon'+i,foilOnly:false};}
  const d=indexCardmarket(prices,products,Date.parse('2026-10-29T20:00:00Z'));d.identities=identities;return {d,metadata,names};
 }
 let f=fixture(9);resolveIdentities(f.d,f.metadata,f.names);assert.equal(f.d.expansionRepairs.length,0);
 f=fixture(10);resolveIdentities(f.d,f.metadata,f.names);assert.equal(f.d.expansionRepairs[0].expansionId,200);assert.equal(f.d.expansionRepairs[0].agreeingCards,10);
});
test('two differently numbered cards cannot be assigned two guide buckets without numbered product evidence',()=>{
 const e={name:'Pikachu',setId:'s',expansionId:123,thirdParty:{cardmarket:99},variants:[]},ids={cards:{'s-1':{...e,number:'1'},'s-2':{...e,number:'2'}},sourceSha256:'s'},meta={cards:{}},names={cards:{'s-1':{name:'Pikachu',foilOnly:true},'s-2':{name:'Pikachu',foilOnly:false}},sourceSha256:'n'};
 for(const id of ['s-1','s-2'])meta.cards[id]={id,name:'Pikachu',localId:id.slice(-1),set:{id:'s'},category:'Pokemon',attacks:[{name:'Pound'}]};
 const make=()=>{const d=indexCardmarket({version:1,createdAt:'2026-10-29T00:00:00Z',priceGuides:[{idProduct:99,idCategory:51,trend:2,'trend-holo':20}]},{products:[{idProduct:99,idCategory:51,idExpansion:123,name:'Pikachu [Pound]'}]},Date.parse('2026-10-29T20:00:00Z'));d.identities=structuredClone(ids);return d;};
 let d=make();resolveIdentities(d,meta,names);assert.equal(d.approvedFinishPairs.size,0);
 assert.equal(priceRecord(meta.cards['s-1'],null,'2026-10-29T20:00:00Z',d).quote,null);assert.equal(priceRecord(meta.cards['s-2'],null,'2026-10-29T20:00:00Z',d).quote,null);
 d=make();resolveIdentities(d,meta,{...names,cards:{'s-1':{name:'Pikachu',foilOnly:false},'s-2':{name:'Pikachu',foilOnly:false}}});assert.equal(d.approvedFinishPairs.size,0);
});
test('interactive audit renders sixty rows at once, filters names, and exports real CSV newlines',async()=>{
 const {renderAudit}=await import('../scripts/audit-view.mjs');
 const rows=Array.from({length:80},(_,i)=>({card_id:'s-'+i,set_name:'Test',number:String(i),name:i===0?'Voltaic "Lightning", Energy':'Card '+i,status:i===0?'priced_source_link':'unresolved_identity',base_amount:i===0?.08:'',currency:'EUR',price_source:'Cardmarket trend',price_date:'2026-10-29',priced_printings:1,printing_count:1}));
 const html=renderAudit(rows,{generatedAt:'2026-10-29',mode:'offline_source_and_download_audit',snapshotCards:80,basePriced:1,baseUnpriced:79,referenceOnly:0,checkedCards:80},[]),script=html.slice(html.indexOf('<script>')+8,html.lastIndexOf('</script>'));
 class Node{constructor(){this.children=[];this.value='';this.listeners={};this.textContent='';}append(...x){this.children.push(...x);}replaceChildren(...x){this.children=x;}addEventListener(k,f){this.listeners[k]=f;}click(){}}
 const nodes=new Map();let exported;const c={document:{getElementById:id=>{if(!nodes.has(id))nodes.set(id,new Node());return nodes.get(id)},createElement:()=>new Node()},Blob,URL:{createObjectURL:b=>{exported=b;return 'blob:test'},revokeObjectURL(){}},setTimeout(){}};
 vm.createContext(c);vm.runInContext(script,c);assert.equal(nodes.get('body').children.length,60);
 nodes.get('search').value='Voltaic';nodes.get('search').listeners.input();assert.equal(nodes.get('body').children.length,1);
 nodes.get('export').onclick();const csv=await exported.text();assert.ok(csv.includes('\r\n'));assert.ok(csv.includes('Voltaic ""Lightning"", Energy'));assert.equal(csv.split('\r\n').length,2);
});
test('ordinary unlimited is selected ahead of shadowless and first-edition products',()=>{
 const d=indexCardmarket({version:1,createdAt:'2026-10-29',priceGuides:[{idProduct:1,idCategory:51,trend:10},{idProduct:2,idCategory:51,trend:100}]},{products:[{idProduct:1,idCategory:51,idExpansion:1,name:'Alakazam [Pound]'},{idProduct:2,idCategory:51,idExpansion:1,name:'Alakazam [Pound]'}]},Date.parse('2026-10-29T20:00:00Z'));
 const c={id:'base-1',name:'Alakazam',variants_detailed:[{type:'holo',subtype:'unlimited',thirdParty:{cardmarket:1},variantId:'u'},{type:'holo',subtype:'shadowless',thirdParty:{cardmarket:2},variantId:'s'}]};
 assert.equal(directCardmarketQuote(c,d).amount,10);
});

test('mismatched source archives cannot trigger automatic identity repairs',()=>{
 const d=indexCardmarket(auditFixture.prices,auditFixture.products,Date.parse('2026-10-29T20:00:00Z'));d.identities=structuredClone(auditFixture.identities);
 const meta=structuredClone(auditFixture.metadata);meta.sourceSha256='different-archive';
 resolveIdentities(d,meta,auditFixture.names);
 assert.ok(d.referenceWarning);assert.equal(d.mappingRepairs.length,0);assert.equal(d.expansionRepairs.length,0);assert.equal(d.approvedFinishPairs.size,0);
});
const extraFixture=JSON.parse(await readFile(new URL('./additional-printings-regression.json',import.meta.url),'utf8'));
function extraData(){const d=indexCardmarket(extraFixture.prices,extraFixture.products,Date.parse('2026-10-30T12:00:00Z'));d.identities=structuredClone(extraFixture.identities);resolveIdentities(d,extraFixture.metadata,extraFixture.names);return d;}
test('real Cosmos, Non Holo and retailer stamps receive separate exact-SKU quotes across expansion families',()=>{
 const d=extraData();
 for(const [id,sku,foil,stamp] of [['me03-006',881886,'',''],['me05-040',914415,'cosmos',''],['me05-056',899378,'cosmos',''],['me05-012',897287,'','whats-your-favourite'],['me05-020',897285,'','whats-your-favourite'],['me05-056',897286,'','whats-your-favourite']]){
  const r=priceRecord(extraFixture.metadata.cards[id],null,'2026-10-30T12:00:00Z',d);
  const v=r.printingQuotes.find(v=>v.quote?.productId===sku);assert.ok(v,id+':'+sku);assert.equal(v.printing.foil,foil);assert.equal(v.printing.stamp[0]||'',stamp);
  assert.equal(v.quote.amount,d.guide.get(sku).trend);assert.notEqual(r.quote.productId,sku,'base price must remain separate');
 }
 for(const id of ['me02-001','sv09-018','me01-010','me04-013','sv08.5-005','me02.5-007']){
  const r=priceRecord(extraFixture.metadata.cards[id],null,'2026-10-30T12:00:00Z',d);
  const e=d.identities.cards[id];const foreign=e.variants.filter(v=>d.catalogue.get(v.thirdParty.cardmarket)?.idExpansion!==e.expansionId);
  assert.ok(foreign.length,id);assert.ok(r.printingQuotes.some(v=>v.quote&&foreign.some(x=>x.thirdParty.cardmarket===v.quote.productId)),id);
 }
});
test('supplement cannot attach a stamped price to a different card or metacard',()=>{
 const d=extraData(),p={...d.catalogue.get(897287),idMetacard:1};d.catalogue.set(897287,p);
 assert.equal(priceRecord(extraFixture.metadata.cards['me05-012'],null,'2026-10-30T12:00:00Z',d).printingQuotes.some(v=>v.quote?.productId===897287),false);
});
test('stamped printing label keeps its price within the final wording line',async()=>{
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('function getSetVariantLabelMarkup('),c={escapeSetVariantHtml:s=>s};vm.createContext(c);vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 const text=c.getSetVariantLabelMarkup("Stamp (What's Your Favourite?)",'<small>N/A</small>');
 assert.ok(text.endsWith("(What's Your Favourite?)<small>N/A</small></span>"));
 assert.equal(c.getSetVariantLabelMarkup('Holo','<small>£1</small>'),'Holo<small>£1</small>');
});
test('Account Dex tally displays descending GBP values with N/A last and stable alphabetical ties',async()=>{
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('function paintProfileDexSelections(');
 const list={rows:[],replaceChildren(){this.rows=[]},appendChild(n){this.rows.push(n.textContent)}},nodes={profileDexValueDetails:{},profileDexValueCards:list,profileDexValueSummary:{}};
 const c={document:{getElementById:id=>nodes[id],createElement:()=>({})},Intl};vm.createContext(c);vm.runInContext(html.slice(start,html.indexOf('\nasync function loadSharedPrices',start)),c);
 const cards=[{name:'Cheap',pence:100},{name:'Missing',pence:null},{name:'Zero',pence:0},{name:'Zebra',pence:2000},{name:'Alpha',pence:2000},{name:'Other missing',pence:null}];
 c.paintProfileDexSelections({total:6,selectedCards:cards});
 assert.deepEqual(list.rows,['Alpha — £20.00','Zebra — £20.00','Cheap — £1.00','Zero — £0.00','Missing — N/A','Other missing — N/A']);assert.equal(cards[0].name,'Cheap');
});
test('stamped-only contest promos expose one base option even with generic finish flags and old saved ticks',async()=>{
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const norm=v=>({type:v.type,foil:v.foil||'',subtype:v.subtype||'',size:v.size||'standard',stamp:v.stamp||[]});const key=v=>'named:'+JSON.stringify(norm(v));
 const c={normaliseNamedPrinting:norm,namedVariantKey:key,getExpansionCardPrintingEvidence:()=>null,findCardPrintingEvidence:(card,rows)=>{const row=rows.find(r=>r[0]===card.set.id&&r[2]===card.number&&r[3]===card.name);return row?{setId:row[0],printings:row[4]}:null;},getCardVariantSupplement:()=>null,getThirtyCelebrationVariantSupplement:()=>null,getCosmosCardPrintingEvidence:()=>null,isExcludedCardPrinting:()=>false,getSupplementalPromoCard:()=>null,shouldKeepNamedPrinting:()=>true,isUnsupportedPlainPrinting:()=>false,isIntrinsicSetStamp:()=>false,namedPrintingLabel:p=>p.stamp.length?'Stamp ('+p.stamp[0]+')':p.type,sortSetCardVariantDefinitions:(_,v)=>v,getVerifiedAdditionalCardPrintings:()=>[],getCardAuxiliaryPrintings:()=>[],getOwnedSetCardVariants:()=>['reverseHolo','holo'],decodeNamedVariantKey:()=>null};
 vm.createContext(c);const start=html.indexOf('const STAMP_ONLY_PROMOS');vm.runInContext(html.slice(start,html.indexOf('function migrateNamedSetCardVariants',start)),c);
 for(const [number,name] of [['SWSH303','Bulbasaur'],['SWSH304','Arcanine'],['SWSH305','Greninja']]){
  const card={set:{id:'swshp'},number,name,variants:{reverseHolo:true},variants_detailed:[{type:'normal'},{type:'normal',stamp:['illustration-contest-2022']}]};
  const options=c.getAvailableSetCardVariants(card);assert.equal(options.length,1);assert.equal(options[0].key,'standard');assert.match(options[0].label,/illustration-contest-2022/);
 }
 const ordinary={set:{id:'other'},number:'1',name:'Bulbasaur',variants_detailed:[{type:'normal'},{type:'normal',stamp:['shop']}]};c.getOwnedSetCardVariants=()=>[];assert.equal(c.getAvailableSetCardVariants(ordinary).length,2);
});
test('legacy duplicate stamp/base selections contribute one price before opening the card',async()=>{
 const {c}=await client(),card={id:'swshp-SWSH303',setName:'SWSH Black Star Promos',number:'SWSH303',baseFinish:'normal'};
 c.getExclusiveExpansionPromoPrinting=()=>({type:'normal',stamp:['illustration-contest-2022']});c.namedVariantKey=()=> 'v141:stamp';c.decodeNamedVariantKey=()=>null;c.isGenericPromoFinish=()=>false;
 c.memSetCardVariants=new Set([card.id+'__standard',card.id+'__v141:stamp']);assert.deepEqual(Array.from(c.selectedSetPriceKeys(card)),['standard']);
});
const claimantFixture=JSON.parse(await readFile(new URL('./conflict-claimants-regression.json',import.meta.url),'utf8'));
function claimantData(){const d=indexCardmarket(claimantFixture.prices,claimantFixture.products,Date.parse('2026-10-31T12:00:00Z'));d.identities=structuredClone(claimantFixture.identities);resolveIdentities(d,claimantFixture.metadata,claimantFixture.names);return d;}
test('a false claimant cannot block the independently named and complete-move matched Tag Team card',()=>{
 const d=claimantData(),t='2026-10-31T12:00:00Z';
 const right=priceRecord(claimantFixture.metadata.cards['sm10-82'],null,t,d),wrong=priceRecord(claimantFixture.metadata.cards['sm10-81'],null,t,d);
 assert.equal(right.quote.productId,370787);assert.equal(wrong.quote,null);
});
test('same-name promo artworks use independently numbered exact corrections, never the borrowed old SKU',()=>{
 const d=claimantData();
 for(const [id,sku] of [['smp-SM242',449233],['smp-SM247',576719],['smp-SM248',576720]]){
  const r=priceRecord(claimantFixture.metadata.cards[id],null,'2026-10-31T12:00:00Z',d);
  assert.equal(r.quote.productId,sku,id);assert.equal(r.baseFinish,'holo');assert.equal(r.quote.amount,d.guide.get(sku).trend);
 }
 const r=priceRecord(claimantFixture.metadata.cards['smp-SM174'],null,'2026-10-31T12:00:00Z',d);assert.equal(r.quote.productId,369353,'new numbered reference resolves this formerly ambiguous artwork');
 const withoutNumbered=claimantData();withoutNumbered.numberedLinks.delete('smp-SM174');
 assert.equal(priceRecord(claimantFixture.metadata.cards['smp-SM174'],null,'2026-10-31T12:00:00Z',withoutNumbered).quote,null,'without numbered evidence the old ambiguity remains blocked');
});
test('registered artwork resolves exact GG and McDonalds fronts without crossing names or numbers',async()=>{
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');const start=html.indexOf('const REGISTERED_CARD_FRONTS'),end=html.indexOf('function getCardArtworkSources',start);
 const c={AUDITED_ARTWORK_SET_ALIASES:{swsh12pt5gg:'swsh12.5gg'}};vm.createContext(c);vm.runInContext(html.slice(start,end),c);
 for(const [set,number] of [['swsh12pt5gg','GG30'],['mcd16','6'],['mcd18','4'],['mcd19','6']]){
  const r=c.registeredCardFronts({set:{id:set},number,name:'Pikachu'});assert.ok(r.small.length,set);assert.ok(r.small[0].includes('/'+number+'.png'));
  assert.equal(c.registeredCardFronts({set:{id:set},number,name:'Raichu'}).small.length,0);
 }
});
test('image loading indicator starts and clears the busy state',async()=>{
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('function setCardImageLoading');const flags=new Set(),attrs={};const slot={classList:{toggle:(s,b)=>b?flags.add(s):flags.delete(s)},setAttribute:(k,v)=>attrs[k]=v};const c={};vm.createContext(c);vm.runInContext(html.slice(start,html.indexOf('function assignTcgArtworkSource',start)),c);
 const img={closest:()=>slot};c.setCardImageLoading(img,true);assert.ok(flags.has('card-image-loading'));assert.equal(attrs['aria-busy'],'true');c.setCardImageLoading(img,false);assert.equal(flags.size,0);assert.equal(attrs['aria-busy'],'false');
});
test('new numbered artwork corrections use distinct exact products and real daily prices',async()=>{
 const f=JSON.parse(await readFile(new URL('./numbered-printings-regression.json',import.meta.url),'utf8')),d=indexCardmarket(f.prices,f.products,Date.parse('2026-10-31T12:00:00Z'));
 for(const [id,sku] of [['sm10-198',372480],['smp-SM81',311416],['xyp-XY124',293003]]){
  const r=priceRecord(f.cards[id],null,'2026-10-31T12:00:00Z',d);assert.equal(r.quote.productId,sku);assert.equal(r.baseFinish,'holo');assert.equal(r.quote.amount,d.guide.get(sku).trend);
 }
});
test('Camerupt artworks contribute their separate prices once each in Dex and Sets totals',async()=>{
 const f=JSON.parse(await readFile(new URL('./camerupt-numbered-regression.json',import.meta.url),'utf8')),d=indexCardmarket(f.prices,f.products,Date.parse('2026-10-31T17:00:00Z'));
 d.identities=structuredClone(f.identities);resolveIdentities(d,f.metadata,f.names);const {c}=await client();
 const cards=['xy5-29','xy5-146'].map(id=>c.sharedPricePatch({id,name:'Camerupt EX',number:f.cards[id].localId,setName:'Primal Clash'},priceRecord(f.cards[id],null,'2026-10-31T17:00:00Z',d),id));
 for(const card of cards){c.memCardCol.add(card.id);c.memSetCardVariants.add(c.getCardFingerprint(card)+'__standard');}
 let v=c.calculateProfileValues(cards,c.calculateProfileStats());assert.equal(v.dex.priced,2);assert.equal(v.sets.priced,2);assert.equal(v.dex.pence,2881);assert.equal(v.sets.pence,2881);
 c.memSetCardVariants.delete(c.getCardFingerprint(cards[1])+'__standard');v=c.calculateProfileValues(cards,c.calculateProfileStats());assert.equal(v.sets.pence,337);assert.equal(v.dex.pence,2881);
});
