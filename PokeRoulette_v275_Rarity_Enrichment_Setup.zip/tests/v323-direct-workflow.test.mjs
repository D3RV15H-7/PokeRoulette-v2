import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {indexCardmarket,directCardmarketQuote} from '../scripts/cardmarket-source.mjs';
import {resolveIdentities} from '../scripts/resolve-identities.mjs';
import {priceRecord,buildSnapshot,PRICING_MODEL_VERSION,selectBootstrapSnapshot} from '../scripts/update-prices.mjs';
import {applyNumberedLinks} from '../scripts/numbered-links.mjs';
const read=p=>JSON.parse(fs.readFileSync(new URL(p,import.meta.url)));
const registry=read('../data/numbered-marketplace-links-v1.json'),frozen=read('./v323-workflow-fixture.json'),meta=frozen.metadata,names=frozen.names;
const now='2026-11-14T14:00:00Z';
function fixture(ids){
 const rows=ids.map(id=>registry.cards[id]);
 const products={products:rows.map(r=>({idProduct:r.productId,idCategory:51,idExpansion:r.expansionId,name:r.catalogueName}))};
 const prices={version:1,createdAt:'2026-11-13T02:44:11+0100',priceGuides:rows.map(r=>({idProduct:r.productId,idCategory:51,trend:10,'trend-holo':20}))};
 const d=indexCardmarket(prices,products,Date.parse(now));d.identities={sourceSha256:'fixture',cards:Object.fromEntries(rows.map(r=>[r.setId+'-'+r.number,{name:r.sourceName,setId:r.setId,number:r.number,expansionId:r.expansionId,variants:[],thirdParty:{cardmarket:r.productId}}]))};
 const m={sourceSha256:'fixture',cards:Object.fromEntries(ids.map(id=>[id,structuredClone(meta.cards[id])]))};resolveIdentities(d,m,names);return {d,m,prices};
}
test('Venusaur XY123 reads its own Cardmarket Trend directly and never the old product',()=>{const {d,m,prices}=fixture(['xyp-XY123']);const r=priceRecord(m.cards['xyp-XY123'],null,now,d);assert.equal(r.quote.productId,291579);assert.equal(r.quote.amount,10);assert.equal(r.quote.source,'Cardmarket trend');assert.equal(r.quote.updated,prices.createdAt);assert.equal(r.baseFinish,'holo');assert.equal(r.printingQuotes.length,1);});
test('Arbok 35 Normal and Reverse use the corrected product and separate guide fields',()=>{const {d,m}=fixture(['ecard1-35']);const r=priceRecord(m.cards['ecard1-35'],null,now,d);assert.equal(r.quote.productId,274910);assert.deepEqual(r.printingQuotes.map(p=>p.quote.amount),[10,20]);});
test('Porygon a and b are separately numbered products with separate prices and ownership identities',()=>{const {d,m}=fixture(['ecard2-103a','ecard2-103b']);for(const [id,pid]of [['ecard2-103a',275179],['ecard2-103b',275178]]){const r=priceRecord(m.cards[id],null,now,d);assert.equal(r.quote.productId,pid);assert.equal(r.number,id.split('-')[1]);assert.equal(r.printingQuotes.length,2);}});
test('a qualified Trainer marketplace name is accepted only by its exact numbered mapping',()=>{const {d,m}=fixture(['sv04.5-088']);const c=m.cards['sv04.5-088'];assert.equal(priceRecord(c,null,now,d).quote.productId,751627);assert.equal(priceRecord({...c,localId:'087'},null,now,d).quote,null);});
test('changed product, expansion or full source moves invalidates a correction',()=>{for(const type of ['expansion','name','moves']){const {d,m}=fixture(['xyp-XY123']);if(type==='moves')m.cards['xyp-XY123'].attacks=[{name:'Wrong'}];else d.catalogue.get(291579)[type==='name'?'name':'idExpansion']=type==='name'?'Wrong':999;resolveIdentities(d,m,names);assert.equal(priceRecord(m.cards['xyp-XY123'],{quote:{amount:999,productId:281319,source:'Cardmarket trend'}},now,d).quote,null);}});
test('a missing Trend does not silently substitute Cardmarket averages or asking prices',()=>{const {d,m}=fixture(['xyp-XY123']);Object.assign(d.guide.get(291579),{trend:null,avg30:100,avg:200,low:50});assert.equal(priceRecord(m.cards['xyp-XY123'],null,now,d).quote,null);});
test('numbered mapping changes are part of the cache identity fingerprint',()=>{const {d,m}=fixture(['xyp-XY123']);const before=d.numberedRegistrySha256;const r=structuredClone(registry);r.cards['xyp-XY123'].basis+=' checked';applyNumberedLinks(d,m,names,r);assert.notEqual(d.numberedRegistrySha256,before);});
test('paired numbered evidence separates Pikachu base and secret artwork and Trainers Mail 92/92a',()=>{const {d,m}=fixture(['sm12-66','sm12-241','xy6-92','xy6-92a']);for(const [id,pid]of [['sm12-66',407979],['sm12-241',398534],['xy6-92',282760],['xy6-92a',297897]])assert.equal(priceRecord(m.cards[id],null,now,d).quote.productId,pid);});
test('a third product or a missing numbered counterpart blocks a paired deduction',()=>{const {d,m}=fixture(['sm12-66','sm12-241']);d.catalogue.set(999,{idProduct:999,idExpansion:2644,name:registry.cards['sm12-241'].catalogueName});applyNumberedLinks(d,m,names);assert.equal(d.numberedLinks.has('sm12-241'),false);assert.equal(d.numberedLinks.has('sm12-66'),true);assert.ok(d.numberedLinkIssues.some(i=>i.reason==='paired_numbered_listing_evidence_changed'));});
test('explicitly reviewed physical aliases can share a price while unrelated numbers stay blocked',()=>{
 const c={id:'t-1a',name:'Alias Mon',localId:'1a',hp:50,set:{id:'t'},attacks:[{name:'Hit'}]};
 const metadata={cards:{'t-1a':c,'t-1b':{...c,id:'t-1b',localId:'1b'}}},rows=Object.fromEntries(Object.values(metadata.cards).map(c=>[c.id,{setId:'t',number:c.localId,sourceName:c.name,sourceMoves:['hit'],productId:1,expansionId:7,catalogueName:'Alias Mon [Hit]',finish:'normal',evidenceUrl:'https://www.cardmarket.com/example',evidenceCardId:c.id,numberedEvidenceVerified:true,physicalAliasGroup:'one-physical-card'}]));
 const d={catalogue:new Map([[1,{idProduct:1,idExpansion:7,name:'Alias Mon [Hit]'}]])};const r={cards:rows,physicalAliases:{'one-physical-card':{reviewed:true,verifiedSamePhysicalPrinting:true,evidenceUrl:'https://www.cardmarket.com/example',printedNumber:'1',cardIds:['t-1a','t-1b'],setId:'t',productId:1,finish:'normal'}}};
 applyNumberedLinks(d,metadata,{},r);assert.equal(d.numberedLinks.size,2);delete r.physicalAliases;applyNumberedLinks(d,metadata,{},r);assert.equal(d.numberedLinks.size,0);
});
test('bulk daily pricing avoids an individual provider call when current direct quotes cover the printings',async()=>{
 const {d,m}=fixture(['xyp-XY123']);let detailCalls=0;
 const fetchImpl=async url=>{if(url.endsWith('/sets'))return Response.json([{id:'xyp',name:'XY Black Star Promos'}]);if(url.endsWith('/cards'))return Response.json([{id:'xyp-XY123',name:'Venusaur EX'}]);if(url.includes('/cards/')){detailCalls++;return Response.json(m.cards['xyp-XY123']);}return new Response('',{status:404});};
 const r=await buildSnapshot({directData:d,fetchImpl,now,workers:1});assert.equal(detailCalls,0);assert.equal(r.summary.bulkCardmarketRefreshed,1);assert.equal(r.cards['xyp-XY123'].quote.productId,291579);assert.equal(r.marketplaceMappingVersion,324);assert.equal(r.pricingModelVersion,PRICING_MODEL_VERSION);
});

test('an old restored workflow cache cannot replace the corrected bootstrap snapshot',()=>{const old={schemaVersion:1,sets:{},cards:{a:{quote:{amount:999}}},pricingModelVersion:266},good={...old,pricingModelVersion:323,cards:{a:{quote:{amount:1}}}};assert.equal(selectBootstrapSnapshot(old,good),good);assert.equal(selectBootstrapSnapshot(good,old),good);assert.equal(selectBootstrapSnapshot(good,{schemaVersion:1,cards:{},sets:{},pricingModelVersion:323}),good);});
