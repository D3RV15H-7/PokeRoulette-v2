# PokéRoulette v2.75 — verified card rarity enrichment

The daily GitHub Actions workflow already refreshes the TCGdex card-database
archive through `scripts/build-audit-references.py`. The additional
`scripts/build-rarity-map.mjs` extracts card-level rarity, exact set ID,
card number and name to `data/card-rarities-v1.json`, published with Pages.

The app fetches this index only when opening its first card preview. A match
requires the exact card ID plus card number and name. Unmatched or unknown
rarities are not inferred. Promo marks and the `ex`/`GX`/`V`/`VMAX` suffix
renderer continue using the existing v2.74 rules.

For source-data errors, add a *reviewed* row under `cards` in
`data/verified-rarity-overrides-v1.json` with `rarity`, `name`, `localId`,
`set: {id}`, and an HTTPS `url` documenting the correct printing. These
records override the TCGdex value for that exact ID at build time.

Bulbapedia article text has CC BY-NC-SA attribution/share-alike terms and
some media has separate rights. This integration does **not** scrape or
republish Bulbapedia text or card scans. Bulbapedia may be cited as a review
reference for individually approved correction records.

Current catalogue count is a record count, not a guarantee that every
provider record is accurate. Nonstandard special and missing classifications
remain blank until verified. If the source archive is temporarily offline,
the pipeline keeps the last bundled references.
