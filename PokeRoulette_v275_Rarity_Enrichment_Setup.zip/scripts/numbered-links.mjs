import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {normalizeMarketplaceName as normal} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
const bundled=JSON.parse(readFileSync(new URL('../data/numbered-marketplace-links-v1.json',import.meta.url),'utf8'));
const moves=c=>[...(c.abilities||[]),...(c.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort();
// These are numbered identity references, never stored price overrides.
// Both the numbered reference and current catalogue identity must still agree.
export function applyNumberedLinks(data,metadata,names,registry=bundled){
 data.numberedLinks=new Map();data.numberedLinkIssues=[];
 data.numberedRegistryVersion=Number(registry.version)||1;
 data.numberedRegistrySha256=createHash('sha256').update(JSON.stringify(registry)).digest('hex');
 data.approvedPhysicalAliases=new Map();
 const candidates=new Map(),claims=new Map();
 for(const [id,row] of Object.entries(registry.cards||{})){
  const c=metadata?.cards?.[id],p=data.catalogue.get(Number(row.productId));
  const ref=c&&names?.cards?.[c.set.id+'-'+normalNumber(c.localId)];
  const reject=reason=>data.numberedLinkIssues.push({cardId:id,productId:row.productId,reason});
  if(!c||c.set.id!==row.setId||normalNumber(c.localId)!==normalNumber(row.number)||normal(c.name)!==normal(row.sourceName)){reject('source_identity_changed');continue;}
  if(row.independentName&&(!ref||normal(ref.name)!==normal(row.independentName))){reject('independent_identity_changed');continue;}
  if(JSON.stringify(moves(c))!==JSON.stringify(row.sourceMoves)){reject('source_moves_changed');continue;}
  if(row.hp!=null&&Number(c.hp)!==Number(row.hp)){reject('source_hp_changed');continue;}
  if(row.printings?.some(v=>!['normal','holo','reverse'].includes(v.type)||Number(v.productId)!==Number(row.productId)||!['','-holo'].includes(v.fieldSuffix))){reject('invalid_explicit_printing_map');continue;}
  if(!p||p.idExpansion!==row.expansionId||p.name!==row.catalogueName){reject('catalogue_identity_changed');continue;}
  // The reference must explicitly publish both this numbered card and its SKU.
  if(!row.evidenceUrl||!row.evidenceCardId||!row.numberedEvidenceVerified||!['normal','holo','reverse'].includes(row.finish)){reject('incomplete_numbered_evidence');continue;}
  candidates.set(id,row);const key=row.setId+':'+row.productId;
  if(!claims.has(key))claims.set(key,[]);claims.get(key).push(id);
 }
 // Limited, reviewed paired-listing evidence. A changed family, extra product
 // or invalid counterpart makes the deduction ambiguous again; never choose
 // the cheapest, newest or nearest-number candidate.
 for(const [id,row]of candidates){
  const proof=row.residualEvidence;if(!proof)continue;
  const counterpart=candidates.get(proof.counterpartCardId);
  const family=[...data.catalogue.values()].filter(p=>p.idExpansion===row.expansionId&&p.name===row.catalogueName).map(p=>p.idProduct).sort((a,b)=>a-b);
  const expected=[...(proof.catalogueFamilyIds||[])].sort((a,b)=>a-b);
  if(!counterpart||counterpart.setId!==row.setId||counterpart.productId===row.productId||expected.length!==2||!expected.includes(counterpart.productId)||!expected.includes(row.productId)||JSON.stringify(family)!==JSON.stringify(expected)||JSON.stringify(counterpart.sourceMoves)!==JSON.stringify(row.sourceMoves)){
   candidates.delete(id);data.numberedLinkIssues.push({cardId:id,reason:'paired_numbered_listing_evidence_changed'});
  }
 }
 for(const ids of claims.values()){
  if(ids.some(id=>!candidates.has(id)))continue;
  if(new Set(ids.map(id=>normalNumber(candidates.get(id).number))).size>1){
   const groups=new Set(ids.map(id=>candidates.get(id).physicalAliasGroup));
   const groupId=groups.size===1?[...groups][0]:null,alias=groupId&&registry.physicalAliases?.[groupId];
   const rows=ids.map(id=>candidates.get(id)),source=ids.map(id=>metadata.cards[id]);
   const verified=alias?.reviewed===true&&alias?.verifiedSamePhysicalPrinting===true&&alias.evidenceUrl&&alias.printedNumber&&
    JSON.stringify([...alias.cardIds||[]].sort())===JSON.stringify([...ids].sort())&&
    rows.every(r=>r.setId===alias.setId&&Number(r.productId)===Number(alias.productId)&&r.finish===alias.finish)&&
    source.every(c=>normal(c.name)===normal(source[0].name)&&Number(c.hp||0)===Number(source[0].hp||0)&&JSON.stringify(moves(c))===JSON.stringify(moves(source[0])));
   if(!verified){for(const id of ids)data.numberedLinkIssues.push({cardId:id,reason:'numbered_references_share_product'});continue;}
   data.approvedPhysicalAliases.set(groupId,alias);
  }
  for(const id of ids)data.numberedLinks.set(id,candidates.get(id));
 }
 const expansions=new Map();
 for(const row of data.numberedLinks.values()){
  if(!expansions.has(row.setId))expansions.set(row.setId,new Set());expansions.get(row.setId).add(row.expansionId);
 }
 data.numberedSetExpansions=new Map([...expansions].filter(([,s])=>s.size===1).map(([id,s])=>[id,[...s][0]]));
}
export function numberedProductMatches(card,product,data){
 const row=data?.numberedLinks?.get(card.id);
 return !!row&&card.set?.id===row.setId&&normalNumber(card.localId||card.number)===normalNumber(row.number)&&[row.sourceName,row.independentName].filter(Boolean).some(n=>normal(n)===normal(card.name))&&product?.idProduct===row.productId&&product.idExpansion===row.expansionId&&product.name===row.catalogueName;
}
