import {readFileSync} from 'node:fs';
import {normalNumber,positive} from './price-model.mjs';
import {normalizeMarketplaceName as normal} from './marketplace-identity.mjs';
const rules=JSON.parse(readFileSync(new URL('../data/verified-provider-links-v323.json',import.meta.url),'utf8')).cards;
const nameNormal=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[\s.‘’'\-\[\]]/g,'');
export function verifiedProviderRule(card){
 const r=rules[card?.id];if(!r)return null;
 const names=[r.name,...r.nameAliases||[]].map(nameNormal);
 if(card.set?.id!==r.setId||normalNumber(card.localId||card.number)!==normalNumber(r.number)||!names.includes(nameNormal(card.name)))return null;
 if(card.hp!=null&&r.hp!=null&&Number(card.hp)!==r.hp)return null;
 const moves=[...(card.abilities||[]),...(card.attacks||[])].map(m=>normal(m.name)).sort();
 if((Array.isArray(card.abilities)||Array.isArray(card.attacks))&&JSON.stringify(moves)!==JSON.stringify(r.moves.map(normal).sort()))return null;
 return r;
}
export function verifiedProviderQuote(card,finish,now){
 const r=verifiedProviderRule(card);if(!r||!r.finishes.includes(finish))return null;
 const bucket=finish==='holo'?'holofoil':finish==='reverse'?'reverse-holofoil':'normal';
 const sources=[card.pricing?.tcgplayer,...(card.variants_detailed||[]).filter(v=>v.type===finish&&(!v.size||v.size==='standard')&&!v.staff&&!v.foil&&!v.subtype&&!v.stamp?.length).map(v=>v.pricing?.tcgplayer)].filter(Boolean);
 const p=sources.find(p=>p.unit==='USD'&&Number(p[bucket]?.productId)===r.tcgplayerId&&positive(p[bucket]?.marketPrice)!==null&&Number.isFinite(Date.parse(p.updated))&&Date.parse(p.updated)<=Date.parse(now)+86400000&&Date.parse(now)-Date.parse(p.updated)<=7*86400000);
 return p?{amount:Number(p[bucket].marketPrice),currency:'USD',source:'TCGplayer market',updated:p.updated,priority:1,productId:r.tcgplayerId,finishBucket:bucket,via:'independently verified exact TCGplayer product'}:null;
}
export function applyVerifiedProviderFallback(record,card,now){
 const r=verifiedProviderRule(card);if(!r)return record;
 record={...record,name:r.name,nameAliases:[...new Set([...(record.nameAliases||[]),...(r.nameAliases||[]),card.name].filter(n=>n!==r.name))],printingQuotes:record.printingQuotes.filter(p=>p.printing.foil||p.printing.subtype||p.printing.stamp?.length||r.finishes.includes(p.printing.type))};
 const quotes=r.finishes.map(type=>({printing:{type,foil:'',subtype:'',size:'standard',stamp:[]},quote:verifiedProviderQuote(card,type,now)}));
 const base=quotes.find(q=>q.printing.type===r.baseFinish)?.quote;
 if((!record.quote||record.quote.source!=='Cardmarket trend')&&base){
  record={...record,quote:base,baseFinish:r.baseFinish,identityStatus:'verified_tcgplayer',identityPolicyVersion:323,rejectCachedQuote:true,retained:false,noFreshQuote:false,noPriceReason:null,marketMatchReason:null,identityEvidence:{url:r.tcgplayerImage,cardId:card.id,productId:r.tcgplayerId,basis:r.evidence}};
 }
 for(const q of quotes){
  if(!q.quote)continue;
  const i=record.printingQuotes.findIndex(v=>v.printing.type===q.printing.type&&!v.printing.foil&&!v.printing.subtype&&!v.printing.stamp?.length);
  if(i<0)record.printingQuotes.push({...q,reason:null});
  else if(!record.printingQuotes[i].quote||record.printingQuotes[i].quote.source!=='Cardmarket trend')record.printingQuotes[i]={...q,reason:null};
 }
 return record;
}
