// Builds a publishable, provenance-aware rarity index from our verified card metadata.
// Bulbapedia serves as an attributed verification reference for curated corrections;
// no Bulbapedia images or article content are scraped.
import {readFile,writeFile} from 'node:fs/promises';
const source=JSON.parse(await readFile('data/source-card-metadata-v1.json','utf8'));
const approvedPath='data/verified-rarity-overrides-v1.json';
let approved={cards:{}};
try {approved=JSON.parse(await readFile(approvedPath,'utf8'));} catch(e) {if(e.code!=='ENOENT')throw e;}
function validId(id){return /^[a-z0-9+_.]+-[a-z0-9_!?+.-]+$/i.test(id);}
function validRow(row){return row&&typeof row==='object'&&typeof row.rarity==='string'&&row.rarity.trim()&&row.name&&row.set?.id&&row.localId;}
const cards={};let skipped=0;
for (const [key,row] of Object.entries(source.cards||{})){
  const id=String(key).toLowerCase();
  if(!validId(id)||!validRow(row)){skipped++;continue;}
  cards[id]={name:String(row.name),number:String(row.localId),setId:String(row.set.id).toLowerCase(),rarity:row.rarity.trim(),source:'tcgdex'};
}
for(const [key,row] of Object.entries(approved.cards||{})){
  if(!validId(key)||!validRow(row)||typeof row.url!=='string'||!/^https:\/\//.test(row.url))throw Error('Invalid approved rarity override '+key);
  cards[key.toLowerCase()]={name:row.name,number:String(row.localId),setId:String(row.set.id).toLowerCase(),rarity:row.rarity.trim(),source:'verified-override',reference:row.url};
}
const report={schemaVersion:1,generatedAt:new Date().toISOString(),sourceGeneratedAt:source.generatedAt,records:Object.keys(cards).length,skipped,overrides:Object.keys(approved.cards||{}).length};
await writeFile('data/card-rarities-v1.json',JSON.stringify({...report,cards}));
console.log(JSON.stringify(report));
