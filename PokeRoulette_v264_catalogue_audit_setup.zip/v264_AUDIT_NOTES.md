# PokéRoulette v264 — catalogue coverage instrumentation

This is an incremental diagnostics update, not a claim that all cards have been priced.

- Pricing model 264 forces a new pass through existing daily price-record caching rules.
- The daily refresh now emits `diagnostics/catalogue-coverage-gate.json` with complete catalogue and printing coverage counts.
- `price-coverage-summary.json` includes grouped root-cause diagnoses (`diagnosisCounts`).
- Existing per-card and per-printing CSVs and HTML audit remain available in the workflow diagnostics artifact.
- Missing or conflicting marketplace identities are *not* automatically assigned another card's price.

**Limitations:** The uploaded archive contains a placeholder `data/prices-v1.json` (zero cards). This offline environment cannot retrieve live Cardmarket downloads or the published GitHub Pages snapshot. Therefore, no live price coverage, verified correction count, or all-cards completion claim is possible from this archive alone. Run the daily workflow online to obtain the complete catalogue audit and identify the remaining exceptions. The existing matching rules were not broadly loosened.

Run: `node --test tests/*.test.mjs && python3 -m unittest discover -s tests -p 'test_*.py'`.
