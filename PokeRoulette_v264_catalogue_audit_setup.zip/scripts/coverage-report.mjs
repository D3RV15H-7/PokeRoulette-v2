import {mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {normalizeMarketplaceName,marketplaceProductName,variantProductAllowed} from './marketplace-identity.mjs';
import {productMatchesCard} from './cardmarket-source.mjs';
import {normalNumber} from './price-model.mjs';
import {renderAudit} from './audit-view.mjs';
const csvCell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
export async function writeCoverageReport(snapshot,data,{directory='diagnostics',manifest={},mode='published_snapshot'}={}){
 const cards=snapshot.cards||{},metadata=data?.sourceMetadata?.cards||{},reference=data?.identities?.cards||{};
 const rows=[],printingRows=[],bySet=new Map(),repairs=new Map((data?.mappingRepairs||[]).map(r=>[r.cardId,r]));
 const setIds=new Set([...Object.keys(snapshot.sets||{}),...(manifest.sets||[]).map(s=>s.id),...(manifest.supplemental||[]).map(s=>s.id)]);
 const ids=new Set([...Object.keys(cards),...Object.keys(reference),...Object.entries(metadata).filter(([,c])=>setIds.has(c.set.id)&&!/^([ab]\d|p-[ab])/i.test(c.set.id)).map(([id])=>id)]);
 const supplementary=[];
 for(const set of manifest.supplemental||[])for(const c of set.cards||[]){if(ids.has(c.id))continue;const found=Object.entries(cards).find(([id,r])=>(r.ownershipAliases||[]).includes(c.id));if(!found){ids.add(c.id);supplementary.push([c.id,{...c,localId:c.number,set:{id:set.id,name:set.name}}]);}}
 const supplementalMap=new Map(supplementary);
 for(const id of [...ids].sort()){
  const record=cards[id],e=reference[id],c=metadata[id]||supplementalMap.get(id)||{id,name:record?.name||e?.name,localId:record?.number||e?.number,set:{id:record?.setId||e?.setId}};
  const setId=c.set.id,setName=snapshot.sets?.[setId]?.name||c.set.name||manifest.supplemental?.find(s=>s.id===setId)?.name||setId;
  const independent=data?.independentNames?.cards?.[setId+'-'+normalNumber(c.localId)];
  const sourceCard={...c,_independentName:independent?.name};
  const verified=data?.numberedLinks?.get(id);
  const candidateIds=[...new Set([verified?.productId,e?.thirdParty?.cardmarket,...(e?.variants||[]).map(v=>v.thirdParty?.cardmarket)].filter(Boolean))];
  const mismatches=candidateIds.filter(sku=>{const p=data?.catalogue.get(Number(sku));return p&&!productMatchesCard(sourceCard,p);});
  let status;
  if(!record)status=supplementalMap.has(id)?'supplemental_not_linked':'not_in_published_catalogue';
  else if(record.quote)status=record.retained?'priced_retained_previous_quote':record.identityStatus==='verified_base'?'priced_verified_source_base':record.identityStatus==='numbered'?'priced_numbered_product_reference':record.identityStatus==='corrected'?'priced_exact_override':repairs.has(id)?'priced_relinked_unique_signature':record.quote.via==='Cardmarket daily extract'?'priced_source_link':'priced_provider_quote';
  else status=record.noPriceReason==='identity_conflict'?'unresolved_identity':!e&&!verified?'no_published_identity':candidateIds.some(sku=>data?.guide.has(Number(sku)))?'no_supported_quote_or_finish':'no_market_quote';
  let diagnosis='',action='';
  if(record&&!record.quote){
   const issue=data?.numberedLinkIssues?.find(r=>r.cardId===id);
   const guides=candidateIds.map(sku=>data?.guide.get(Number(sku))).filter(Boolean);
   const hasSupported=guides.some(g=>['trend','avg','avg1','avg7','avg30','trend-holo','avg-holo','avg1-holo','avg7-holo','avg30-holo'].some(k=>Number(g[k])>0));
   const onlyAsking=!hasSupported&&guides.some(g=>Number(g.low)>0||Number(g['low-holo'])>0);
   if(issue){diagnosis=issue.reason;action='Recheck the numbered listing, source metadata and current catalogue before accepting this identity.';}
   else if(record.noPriceReason==='identity_conflict'){diagnosis=mismatches.length?'name_or_product_conflict':'numbered_printing_reference_needed';action='Confirm the exact numbered product, standard size and finish; do not borrow a same-name artwork or guide bucket.';}
   else if(onlyAsking){diagnosis='asking_prices_only';action='Identity candidates exist, but only asking prices are available in this download. Wait for a supported trend/average or use a verified same-printing provider quote.';}
   else if(guides.length&&!hasSupported){diagnosis='empty_sales_price_fields';action='The guide row has no usable trend/average. Recheck future downloads or an exact-printing provider fallback; never substitute zero.';}
   else if(!e&&!verified){diagnosis='published_product_link_missing';action='Obtain an exact numbered product reference; a unique name and complete-signature match within the confirmed set can also supply a link.';}
   else{diagnosis='supported_finish_quote_missing';action='Verify which printing and price-guide field apply. A website listing or price for a different finish is insufficient.';}
  }
  const variants=record?.printingQuotes||[],pricedVariants=variants.filter(v=>v.quote).length;
  const row={card_id:id,set_id:setId,set_name:setName,number:c.localId||record?.number,name:record?.name||c.name,independent_printed_name:independent?.name||'',status,base_finish:record?.baseFinish||'',base_amount:record?.quote?.amount??'',currency:record?.quote?.currency||'',price_source:record?.quote?.source||'',price_date:record?.quote?.updated||'',selected_product_id:record?.quote?.productId||'',candidate_product_ids:candidateIds.join('|'),candidate_product_names:candidateIds.map(sku=>data?.catalogue.get(Number(sku))?.name||'not in catalogue').join(' | '),name_mismatch_product_ids:mismatches.join('|'),printing_count:variants.length,priced_printings:pricedVariants,unpriced_printings:variants.length-pricedVariants,repair_basis:repairs.get(id)?.basis||data?.approvedFinishPairs?.get(id)?.basis||'',source_metadata_available:!!metadata[id],scope:record?'in_price_snapshot':'additional_reference_or_app_card'};
  Object.assign(row,{match_diagnosis:diagnosis,suggested_action:action,verified_product_id:verified?.productId||'',numbered_evidence_url:verified?.evidenceUrl||record?.identityEvidence?.url||''});
  rows.push(row);
  for(const v of variants)printingRows.push({card_id:id,set_name:setName,number:row.number,name:row.name,type:v.printing.type,foil:v.printing.foil,subtype:v.printing.subtype,stamp:(v.printing.stamp||[]).join('|'),amount:v.quote?.amount??'',currency:v.quote?.currency||'',source:v.quote?.source||'',price_date:v.quote?.updated||'',product_id:v.quote?.productId||'',field_suffix:v.quote?.fieldSuffix??'',status:v.quote?'priced':v.reason||'unpriced'});
  if(!bySet.has(setId))bySet.set(setId,{set_id:setId,set_name:setName,checked_cards:0,in_snapshot:0,priced_base:0,unpriced_base:0,reference_only:0,priced_printings:0,unpriced_printings:0});
  const s=bySet.get(setId);s.checked_cards++;if(record){s.in_snapshot++;if(record.quote)s.priced_base++;else s.unpriced_base++;}else s.reference_only++;s.priced_printings+=pricedVariants;s.unpriced_printings+=variants.length-pricedVariants;
 }
 const emptySets=Object.entries(snapshot.sets||{}).filter(([id])=>!bySet.has(id)&&!/^([ab]\d|p-[ab])/i.test(id)&&id!=='jumbo');
 for(const [id,set] of emptySets)bySet.set(id,{set_id:id,set_name:set.name,checked_cards:0,in_snapshot:0,priced_base:0,unpriced_base:0,reference_only:0,priced_printings:0,unpriced_printings:0,coverage_note:'No eligible standalone card record in audited inventories; not assumed complete.'});
 const categories={};for(const r of rows)categories[r.status]=(categories[r.status]||0)+1;
 const diagnosisCounts={};for(const r of rows)if(r.match_diagnosis)diagnosisCounts[r.match_diagnosis]=(diagnosisCounts[r.match_diagnosis]||0)+1;
 const summary={generatedAt:new Date().toISOString(),snapshotGeneratedAt:snapshot.generatedAt,mode,marketExtractDate:data?.updated||null,checkedCards:rows.length,sets:bySet.size,snapshotCards:Object.keys(cards).length,basePriced:Object.values(cards).filter(r=>r.quote).length,baseUnpriced:Object.values(cards).filter(r=>!r.quote).length,referenceOnly:rows.filter(r=>r.scope!=='in_price_snapshot').length,printedVariants:rows.reduce((n,r)=>n+r.printing_count,0),pricedVariants:rows.reduce((n,r)=>n+r.priced_printings,0),categories,diagnosisCounts,identityRepairs:data?.mappingRepairs?.length||0,validatedFinishPairCards:data?.approvedFinishPairs?.size||0,limitations:['Automated full-reference and price-download audit; not an independent visual verification of every Cardmarket listing.','Unique links still rely on published source identities; ambiguous names, finishes and reprints remain unresolved.','Reference-only rows are not automatically assumed to be present or collected in the app.','Provider and retained quotes are identified separately from fresh direct-extract quotes.']};
 summary.retainedEarlierQuotes=Object.values(cards).filter(r=>r.quote&&r.retained).length;
 summary.numberedProductLinks=data?.numberedLinks?.size||0;
 summary.numberedLinkValidationIssues=data?.numberedLinkIssues?.length||0;
 summary.verifiedSourceBaseFallbacks=Object.values(cards).filter(r=>r.identityStatus==='verified_base'&&r.quote).length;
 summary.setsWithCards=[...bySet.values()].filter(s=>s.checked_cards>0).length;
 summary.catalogEntriesWithoutCardRecords=emptySets.map(([id,set])=>({setId:id,name:set.name}));
 summary.expansionRepairs=data?.expansionRepairs||[];
 await mkdir(directory,{recursive:true});
 const writeCsv=async(name,a)=>{const cols=[...new Set(a.flatMap(Object.keys))];await writeFile(join(directory,name),cols.join(',')+'\n'+a.map(r=>cols.map(k=>csvCell(r[k])).join(',')).join('\n')+'\n');};
 await writeCsv('card-price-coverage.csv',rows);await writeCsv('set-price-coverage.csv',[...bySet.values()].sort((a,b)=>a.set_name.localeCompare(b.set_name)));await writeFile(join(directory,'price-coverage-summary.json'),JSON.stringify(summary,null,2));
 await writeCsv('printing-price-coverage.csv',printingRows);
 await writeFile(join(directory,'price-coverage.html'),renderAudit(rows,summary,[...bySet.values()].sort((a,b)=>a.set_name.localeCompare(b.set_name))));
 await writeFile(join(directory,'marketplace-link-repairs.json'),JSON.stringify(data?.mappingRepairs||[],null,2));
 await writeFile(join(directory,'set-expansion-repairs.json'),JSON.stringify(data?.expansionRepairs||[],null,2));
 return summary;
}
