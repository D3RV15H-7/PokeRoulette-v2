# PokeRoulette v250 — missing promo prices and reprint names

1. Upload PokeRoulette_v250_missing_promo_prices_setup.zip to the repository root.
2. Replace the root index.html with PokeRoulette_v250_missing_promo_prices.html (rename the downloaded HTML to index.html).
3. Replace .github/workflows/daily-prices.yml with the full contents of IPHONE_WORKFLOW.yml, and commit to main. This starts the new daily price job automatically.

The source catalogue currently omits 26 English cards whose exact identities already exist in the publisher’s source. The generator now validates those source identities against the Cardmarket product catalogue and includes them in the shared snapshot. This avoids individual failing API requests for omitted cards. Sixteen of these 26 have positive Cardmarket quotes in the 29 October extract; ten retain N/A because the available guide fields have no usable quote. No prices are invented or entered manually.

Palkia LV.X in the 30th Classic Collection is source position 022 and printed number 106. The source calls it Palkia; Cardmarket product 907950 calls it Palkia LV.X. This exact set/position/product combination now has a verified name alias. The client recognises the saved LV.X collection fingerprint and continues rejecting different printings and ambiguous identities.

The three screenshot examples now resolve in regression tests: Alolan Exeggutor MEP094 (895609), Moltres MEP096 (895606), and Palkia LV.X (907950). Tests also verify eight saved selections comprising MEP094–100 plus Palkia, without opening any cards, count as eight priced physical cards.

Source priority and true source dates are unchanged: Cardmarket Trend, TCGplayer Market, then Cardmarket averages. Previous valid quotes are retained on failures. Phones still download one shared snapshot; product/source processing runs in GitHub Actions.

The daily schedule remains 01:17 UTC. The shared-prices-v241 cache prefix is intentionally retained for continuity. The first v250 run rechecks existing records. Diagnostics use price-diagnostics-v250. Keep v249 until v250 has deployed successfully.

Validation: 40 Node tests and four Python parser tests, including real product/guide rows from 29 October. Tests do not constitute a live deployment or access to the user’s private collection.
