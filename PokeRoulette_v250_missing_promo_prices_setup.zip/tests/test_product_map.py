import importlib.util,pathlib,unittest
spec=importlib.util.spec_from_file_location('product_map',pathlib.Path(__file__).parents[1]/'scripts/build-product-map.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ParserTests(unittest.TestCase):
 def test_nested_literal(self):
  c=m.literal('const card: Card = {name:{en:"Moltres"},variants:[{type:"normal",stamp:["30th-anniversary"],thirdParty:{cardmarket:907617}}]}','Card')
  self.assertEqual(c['variants'][0]['thirdParty']['cardmarket'],907617)
 def test_no_execution(self):
  c=m.literal('const card: Card = {name:{en:"Safe"},variants: getVariants(),thirdParty:{cardmarket: doSomething()}}','Card')
  self.assertIsNone(c['variants']);self.assertIsNone(c['thirdParty']['cardmarket'])
 def test_comments_and_strings(self):
  c=m.literal('const card: Card = {/* note */ name:{en:"Farfetch\\\'d"}, description:{en:"Braces { and } are text"}, variants:[]}','Card')
  self.assertEqual(c['description']['en'],'Braces { and } are text')
 def test_imports_are_not_evaluated(self):
  c=m.literal('import Something from "unsafe"; const card: Card = {set:Something,name:{en:"Safe"},variants:[]}','Card')
  self.assertIsNone(c['set']);self.assertEqual(c['name']['en'],'Safe')
if __name__=='__main__':unittest.main()
