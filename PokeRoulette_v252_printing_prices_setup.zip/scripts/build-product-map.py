"""Read literal identity data from TCGdex source. Never execute downloaded code."""
import ast,datetime,hashlib,io,json,pathlib,re,sys,tarfile,urllib.request
TOKEN=re.compile(r'''\s+|//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[A-Za-z_$][\w$]*|\d+(?:\.\d+)?|[^\s]''')
class Reader:
 def __init__(self,text):self.t=[x for x in TOKEN.findall(text) if not x.isspace() and not x.startswith('//') and not x.startswith('/*')];self.i=0
 def peek(self):return self.t[self.i] if self.i<len(self.t) else ''
 def pop(self):v=self.peek();self.i+=1;return v
 def expression(self,ends):
  stack=[]
  while self.peek():
   v=self.peek()
   if not stack and v in ends:return
   self.pop()
   if v in ['{','[','(']:stack.append({'{':'}','[':']','(':')'}[v])
   elif stack and v==stack[-1]:stack.pop()
 def value(self):
  v=self.pop()
  if v=='{':
   out={}
   while self.peek() and self.peek()!='}':
    key=self.pop()
    if key==',':continue
    if key.startswith(('"',"'")):
     try:key=ast.literal_eval(key)
     except: key=''
    if self.pop()!=':':self.expression({',','}'});continue
    val=self.value()
    if self.peek() not in [',','}']:self.expression({',','}'});val=None
    out[key]=val
    if self.peek()==',':self.pop()
   self.pop();return out
  if v=='[':
   out=[]
   while self.peek() and self.peek()!=']':
    start=self.i;val=self.value()
    if self.peek() not in [',',']']:self.expression({',',']'});val=None
    out.append(val)
    if self.peek()==',':self.pop()
    if self.i==start:raise ValueError('Non-advancing parser')
   self.pop();return out
  if v.startswith(('"',"'")):
   try:return ast.literal_eval(v)
   except:return None
  if v in ['true','false','null']:return {'true':True,'false':False,'null':None}[v]
  if re.fullmatch(r'\d+(?:\.\d+)?',v):return float(v) if '.' in v else int(v)
  return None

def literal(text,kind):
 m=re.search(r'\bconst\s+\w+\s*:\s*'+kind+r'\s*=\s*\{',text)
 if not m:return None
 return Reader(text[m.end()-1:]).value()

def build(blob):
 archive=tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz');texts={}
 for member in archive.getmembers():
  p=pathlib.PurePosixPath(member.name)
  if member.isfile() and len(p.parts)>2 and p.parts[1]=='data' and p.suffix=='.ts' and member.size<250000:
   texts[pathlib.PurePosixPath(*p.parts[1:])]=archive.extractfile(member).read().decode('utf-8')
 sets={};cards={};skipped=0
 for p,text in texts.items():
  try:s=literal(text,'Set')
  except Exception:continue
  if s and isinstance(s.get('id'),str) and isinstance(s.get('thirdParty',{}),dict) and isinstance(s.get('thirdParty',{}).get('cardmarket'),int):
   sets[p.with_suffix('')]={'id':s['id'],'name':(s.get('name') or {}).get('en'),'expansionId':s['thirdParty']['cardmarket']}
 for p,text in texts.items():
  parent=sets.get(p.parent)
  if not parent:continue
  try:c=literal(text,'Card')
  except Exception:skipped+=1;continue
  if not isinstance(c,dict) or not isinstance(c.get('name'),dict) or not c['name'].get('en'):continue
  variants=c.get('variants');valid=[]
  if isinstance(variants,list):
   for v in variants:
    if not isinstance(v,dict) or v.get('type') not in ['normal','holo','reverse']:continue
    third=v.get('thirdParty')
    if not isinstance(third,dict) or not isinstance(third.get('cardmarket'),int):continue
    if v.get('size') not in [None,'standard'] or v.get('staff'):continue
    langs=v.get('languages')
    if langs and (not isinstance(langs,list) or 'en' not in langs):continue
    valid.append({k:v[k] for k in ['type','size','stamp','subtype','foil','staff','languages','thirdParty'] if k in v})
  # Older source records may expose a single root product. Preserve flags
  # so the existing finish selector can distinguish a separate foil bucket.
  third=c.get('thirdParty')
  root=third if isinstance(third,dict) and isinstance(third.get('cardmarket'),int) else None
  if not valid and not root:continue
  cards[parent['id']+'-'+p.stem]={'name':c['name']['en'],'setId':parent['id'],'number':p.stem,'expansionId':parent['expansionId'],'variants':valid,**({'thirdParty':root} if root else {})}
 return {'schemaVersion':1,'source':'TCGdex cards-database','sourceUrl':'https://github.com/tcgdex/cards-database','sourceSha256':hashlib.sha256(blob).hexdigest(),'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cards':cards,'parsedCards':len(cards),'skipped':skipped}

def main():
 dest=pathlib.Path('data/product-identities-v1.json');dest.parent.mkdir(parents=True,exist_ok=True)
 try:
  if len(sys.argv)>1:blob=pathlib.Path(sys.argv[1]).read_bytes()
  else:
   with urllib.request.urlopen('https://codeload.github.com/tcgdex/cards-database/tar.gz/refs/heads/master',timeout=60) as r:blob=r.read(100000001)
  if len(blob)>100000000:raise ValueError('Source archive exceeds 100 MB')
  result=build(blob)
  if len(result['cards'])<100:raise ValueError('Incomplete source identity map')
  for id,name in [('30th-010','Ninetales'),('30th-011','Moltres'),('30th-015','Fuecoco ex')]:
   if result['cards'].get(id,{}).get('name')!=name:raise ValueError('Release identity check failed: '+id)
  tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':')));tmp.replace(dest)
  print(json.dumps({'identityCards':len(result['cards']),'generatedAt':result['generatedAt'],'skipped':result['skipped']}))
 except Exception as e:
  if not dest.exists():raise
  print('Identity source update unavailable; keeping bundled map:',str(e))
if __name__=='__main__':main()
