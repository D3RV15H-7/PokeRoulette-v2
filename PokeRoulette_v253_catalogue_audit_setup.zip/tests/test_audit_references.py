import importlib.util,pathlib,unittest,io,tarfile,json
spec=importlib.util.spec_from_file_location('audit_refs',pathlib.Path(__file__).parents[1]/'scripts/build-audit-references.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def archive(files):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz') as t:
  for name,content in files.items():
   raw=content.encode();entry=tarfile.TarInfo(name);entry.size=len(raw);t.addfile(entry,io.BytesIO(raw))
 return b.getvalue()
class References(unittest.TestCase):
 def source(self):return archive({'repo/data/Series/Test.ts':'const set: Set = {id:"test",name:{en:"Test"},thirdParty:{cardmarket:1}}','repo/data/Series/Test/001.ts':'const card: Card = {name:{en:"Palkia"},category:"Pokemon",attacks:[{name:{en:"Hit"}}],variants:[{type:"holo",thirdParty:{cardmarket:10}}]}'})
 def test_independent_printed_name_and_source_number_stay_separate(self):
  names=archive({'repo/cards/en/old.json':json.dumps([{'id':'old-1','name':'Palkia LV.X','number':'1','rarity':'Rare Holo LV.X'}])})
  metadata,ref=m.build(self.source(),names,{'old':'test'})
  self.assertEqual(metadata['cards']['test-001']['name'],'Palkia');self.assertEqual(ref['cards']['test-1']['name'],'Palkia LV.X');self.assertTrue(ref['cards']['test-1']['foilOnly'])
 def test_conflicting_normalized_numbers_do_not_generate_an_alias(self):
  names=archive({'repo/cards/en/test.json':json.dumps([{'id':'test-1','name':'One','number':'1'},{'id':'test-001','name':'Another','number':'001'}])})
  _,ref=m.build(self.source(),names,{})
  self.assertIsNone(ref['cards']['test-1']);self.assertEqual(ref['conflicts'],['test-1'])
if __name__=='__main__':unittest.main()
