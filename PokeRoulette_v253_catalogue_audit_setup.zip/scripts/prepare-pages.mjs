import {readdir,mkdir,copyFile,readFile,writeFile} from 'node:fs/promises';
import {join,extname} from 'node:path';
const snapshot=JSON.parse(await readFile('data/prices-v1.json','utf8'));
if(snapshot.schemaVersion!==1||!Object.keys(snapshot.cards||{}).length)throw new Error('No generated price snapshot; keeping the existing live site.');
const denied=new Set(['.git','.github','.price-state','node_modules','scripts','tests','diagnostics','_site','product-identities-v1.json','source-card-metadata-v1.json','independent-card-names-v1.json']);
const extensions=new Set(['.html','.htm','.css','.js','.mjs','.json','.webmanifest','.png','.jpg','.jpeg','.gif','.svg','.webp','.ico','.avif','.woff','.woff2','.ttf','.mp3','.ogg','.wav','.mp4','.webm','.txt','.xml']);
async function copy(source,destination){
 await mkdir(destination,{recursive:true});
 for(const entry of await readdir(source,{withFileTypes:true})){
  if(entry.isSymbolicLink()||denied.has(entry.name)||entry.name.startsWith('.')||/^README/i.test(entry.name)||/^PokeRoulette_v\d+/i.test(entry.name))continue;
  const from=join(source,entry.name),to=join(destination,entry.name);
  if(entry.isDirectory())await copy(from,to);
  else if(extensions.has(extname(entry.name).toLowerCase())||entry.name==='CNAME')await copyFile(from,to);
 }
}
await copy('.', '_site');
await writeFile('_site/.nojekyll','');
await readFile('_site/index.html');
console.log('Static app and generated prices are ready for Pages.');
