import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {indexCardmarket} from './cardmarket-source.mjs';
import {resolveIdentities} from './resolve-identities.mjs';
import {priceRecord} from './update-prices.mjs';
import {writeCoverageReport} from './coverage-report.mjs';
const json=async p=>JSON.parse(await readFile(p,'utf8'));
export async function auditAll({baseline,prices,products,identities,metadata,names,manifest,directory}){
 const data=indexCardmarket(prices,products);data.identities=identities;resolveIdentities(data,metadata,names);data.repairById=new Map(data.mappingRepairs.map(r=>[r.cardId,r]));
 const snapshot={...baseline,cards:{...baseline.cards},generatedAt:new Date().toISOString()};
 for(const [id,old] of Object.entries(baseline.cards)){
  const raw=metadata.cards[id];if(!raw)continue;
  const c=structuredClone(raw);
  if(!c.variants_detailed?.length&&!c.variants?.normal&&!c.variants?.holo&&['normal','holo','reverse'].includes(old.baseFinish))c.variants={...c.variants,[old.baseFinish]:true};
  snapshot.cards[id]=priceRecord(c,old,snapshot.generatedAt,data);
 }
 const summary=await writeCoverageReport(snapshot,data,{directory,manifest,mode:'offline_source_and_download_audit'});
 summary.baselinePriced=Object.values(baseline.cards).filter(r=>r.quote).length;
 summary.newlyPriced=Object.entries(snapshot.cards).filter(([id,r])=>r.quote&&!baseline.cards[id]?.quote).length;
 summary.previouslyPricedNowUnresolved=Object.entries(snapshot.cards).filter(([id,r])=>!r.quote&&baseline.cards[id]?.quote).length;
 await writeFile(resolve(directory,'price-coverage-summary.json'),JSON.stringify(summary,null,2));
 await writeFile(resolve(directory,'audit-snapshot.json'),JSON.stringify(snapshot));
 console.log(JSON.stringify(summary,null,2));return {snapshot,data,summary};
}
if(import.meta.url===pathToFileURL(resolve(process.argv[1]||'')).href){
 const a=process.argv.slice(2);if(a.length<4)throw new Error('Usage: audit-all-cards.mjs BASELINE PRICES PRODUCTS OUTPUT_DIRECTORY');
 await mkdir(a[3],{recursive:true});await auditAll({baseline:await json(a[0]),prices:await json(a[1]),products:await json(a[2]),directory:a[3],identities:await json('data/product-identities-v1.json'),metadata:await json('data/source-card-metadata-v1.json'),names:await json('data/independent-card-names-v1.json'),manifest:await json('data/price-mapping.json')});
}
