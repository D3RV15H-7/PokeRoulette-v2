import {normalizeMarketplaceName as normal,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
const moves=c=>[...(c.abilities||[]),...(c.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort();
const signature=(name,ms)=>normal(name)+'|'+ms.join('|');
export function resolveIdentities(data,metadata,names){
 if(!data?.identities?.cards||!metadata?.cards)return;
 data.independentNames=names;data.sourceMetadata=metadata;
 if(data.identities.sourceSha256&&metadata.sourceSha256&&data.identities.sourceSha256!==metadata.sourceSha256){
  data.referenceWarning='Source identity and metadata archives differ; automatic identity repairs were skipped.';
  data.mappingRepairs=[];data.expansionRepairs=[];data.approvedFinishPairs=new Map();
  return;
 }

 const expected=c=>names?.cards?.[c.set.id+'-'+normalNumber(c.localId)]?.name||c.name;
 // A set-level ID can itself be stale. Require agreement from at least
 // ten independently numbered Pokémon and their complete move signatures.
 const votes=new Map();data.expansionRepairs=[];
 for(const [id,e] of Object.entries(data.identities.cards)){
  const c=metadata.cards[id],ref=names?.cards?.[e.setId+'-'+normalNumber(e.number)];if(!c||!ref||c.category!=='Pokemon'||!moves(c).length)continue;
  const expansions=new Set();
  for(const sku of new Set([e.thirdParty?.cardmarket,...e.variants.map(v=>v.thirdParty?.cardmarket)].filter(Boolean))){
   const p=data.catalogue.get(Number(sku)),m=p&&/\s*\[([^\]]+)\]\s*$/.exec(p.name);
   if(m&&marketplaceProductName(p)===normal(ref.name)&&JSON.stringify(m[1].split('|').map(normal).sort())===JSON.stringify(moves(c)))expansions.add(p.idExpansion);
  }
  if(expansions.size!==1)continue;if(!votes.has(e.setId))votes.set(e.setId,new Map());const vote=votes.get(e.setId),exp=[...expansions][0];vote.set(exp,(vote.get(exp)||0)+1);
 }
 const source=structuredClone(data.identities);
 for(const [setId,counts] of votes){const ranked=[...counts].sort((a,b)=>b[1]-a[1]),[winner,count]=ranked[0],total=ranked.reduce((n,r)=>n+r[1],0),old=Object.values(source.cards).find(e=>e.setId===setId)?.expansionId;
  if(winner===old||count<10||count/total<.9||(counts.get(old)||0)>0)continue;
  for(const e of Object.values(source.cards))if(e.setId===setId)e.expansionId=winner;
  data.expansionRepairs.push({setId,previousExpansionId:old,expansionId:winner,agreeingCards:count,checkedCards:total,basis:'independent_printed_name_and_complete_signature_consensus'});
 }
 data.identities=source;
 const sourceGroups=new Map(),productGroups=new Map(),productKeys=new Map();
 const expansionBySet=new Map(Object.values(data.identities.cards).map(e=>[e.setId,e.expansionId]));
 for(const [id,c] of Object.entries(metadata.cards)){
  const e=data.identities.cards[id]||{expansionId:expansionBySet.get(c.set.id)},ms=moves(c);
  if(!e.expansionId||c.category!=='Pokemon'||!ms.length)continue;
  const k=e.expansionId+'|'+signature(expected(c),ms);
  if(!sourceGroups.has(k))sourceGroups.set(k,[]);sourceGroups.get(k).push(id);
 }
 for(const p of data.catalogue.values()){
  const match=/\s*\[([^\]]+)\]\s*$/.exec(p.name);if(!match)continue;
  const k=p.idExpansion+'|'+signature(p.name.slice(0,match.index),match[1].split('|').map(x=>normal(x)).sort());
  productKeys.set(p.idProduct,k);
  if(!productGroups.has(k))productGroups.set(k,[]);productGroups.get(k).push(p.idProduct);
 }
 const repaired=structuredClone(data.identities);data.mappingRepairs=[];
 for(const [k,ids] of sourceGroups){
  const candidates=productGroups.get(k)||[];
  if(ids.length!==1||candidates.length!==1)continue;
  const id=ids[0],e=repaired.cards[id],original=data.identities.cards[id],target=candidates[0];
  if(!e)continue;
  // These are exact, unique full signatures on BOTH sides in one expansion.
  // No fuzzy-name or nearest-price selection is permitted.
  let changed=false;
  const root=original.thirdParty?.cardmarket;
  const sameForeign=id=>{const p=data.catalogue.get(Number(id)),actual=productKeys.get(Number(id));return p&&p.idExpansion!==e.expansionId&&actual?.slice(actual.indexOf('|')+1)===k.slice(k.indexOf('|')+1);};
  if(root&&Number(root)!==target&&!sameForeign(root)){e.thirdParty={...e.thirdParty,cardmarket:target};changed=true;}
  e.variants=(e.variants||[]).map(v=>{
   const p=data.catalogue.get(Number(v.thirdParty?.cardmarket));
   if(sameForeign(v.thirdParty?.cardmarket))return v; // Matching separate printing families retain their own identity.
   if(Number(v.thirdParty.cardmarket)===target)return v;
   changed=true;return {...v,thirdParty:{...v.thirdParty,cardmarket:target}};
  });
  if(changed)data.mappingRepairs.push({cardId:id,productId:target,previousIds:[root,...original.variants.map(v=>v.thirdParty?.cardmarket)].filter(Boolean),basis:'unique_name_and_complete_moves_in_same_expansion_on_both_sides'});
 }
 repaired.sourceSha256+='|names:'+(names?.sourceSha256||'none')+'|resolver:253';
 data.identities=repaired;data.approvedFinishPairs=new Map();
 const groups=new Map();
 for(const [id,e] of Object.entries(repaired.cards)){
  const sku=e.thirdParty?.cardmarket;if(!sku)continue;
  const k=e.setId+':'+sku;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(id);
 }
 for(const [k,ids] of groups){
  if(ids.length!==2)continue;
  const cards=ids.map(id=>metadata.cards[id]),refs=ids.map(id=>{const e=repaired.cards[id];return names?.cards?.[e.setId+'-'+normalNumber(e.number)];});
  if(cards.some(c=>!c||c.category!=='Pokemon'||!moves(c).length)||refs.some(r=>!r)||refs[0].foilOnly===refs[1].foilOnly)continue;
  const e=repaired.cards[ids[0]],p=data.catalogue.get(e.thirdParty.cardmarket),q=data.guide.get(e.thirdParty.cardmarket);
  if(!p||p.idExpansion!==e.expansionId||marketplaceProductName(p)!==normal(refs[0].name)||normal(refs[0].name)!==normal(refs[1].name)||JSON.stringify(moves(cards[0]))!==JSON.stringify(moves(cards[1])))continue;
  const parsed=/\s*\[([^\]]+)\]\s*$/.exec(p.name);
  if(!parsed||JSON.stringify(parsed[1].split('|').map(normal).sort())!==JSON.stringify(moves(cards[0]))||!(q?.trend>0&&q?.['trend-holo']>0))continue;
  ids.forEach((id,i)=>data.approvedFinishPairs.set(id,{productId:p.idProduct,finish:refs[i].foilOnly?'holo':'normal',fieldSuffix:refs[i].foilOnly?'-holo':'',basis:'independent_printed_names_rarity_and_identical_complete_moves_two_distinct_market_buckets'}));
 }
}
