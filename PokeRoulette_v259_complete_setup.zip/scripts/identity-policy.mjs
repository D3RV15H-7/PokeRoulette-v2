import {normalizeMarketplaceName,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
const cache=new WeakMap();
// Identity correction only: prices always come from the current extract.
// Product page: https://www.cardmarket.com/en/Pokemon/Products/Singles/Generations/Pikachu-V2-GENRC29
// Independent product-number corroboration: https://recollectibles.de/products/pikachu-gen-rc29-ultra-rare-englisch
export const CORRECTIONS={
 'smp-SM242':{name:'Eevee GX',setId:'smp',number:'SM242',productId:449233,expansionId:1757,finish:'holo'},
 'smp-SM247':{name:'Reshiram & Charizard GX',setId:'smp',number:'SM247',productId:576719,expansionId:1757,finish:'holo'},
 'smp-SM248':{name:'Pikachu & Zekrom GX',setId:'smp',number:'SM248',productId:576720,expansionId:1757,finish:'holo'},
 'g1-RC29':{name:'Pikachu',setId:'g1',number:'RC29',productId:288538,expansionId:1693,finish:'holo'}};
const clean=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
export function auditIdentities(data){
 if(!data)return {policies:new Map(),conflicts:[]};
 if(cache.has(data))return cache.get(data);
 const groups=new Map(),policies=new Map();
 for(const [id,e] of Object.entries(data.identities?.cards||{})){
  const finishPair=data.approvedFinishPairs?.get(id);
  if(finishPair){policies.set(id,{kind:'finish_pair',...finishPair});continue;}
  const correction=CORRECTIONS[id];
  if(correction){policies.set(id,{kind:'corrected',...correction});continue;}
  const ids=new Set([e.thirdParty?.cardmarket,...(e.variants||[]).map(v=>v.thirdParty?.cardmarket)].filter(Boolean));
  for(const sku of ids){const key=e.setId+':'+sku;if(!groups.has(key))groups.set(key,[]);groups.get(key).push({id,name:e.name,number:e.number,setId:e.setId,productId:sku});}
 }
 const conflicts=[];
 for(const [key,entries] of groups){
  if(new Set(entries.map(e=>normalNumber(e.number))).size<2)continue;
  // A wrong-name claimant must not quarantine the one independently named
  // card whose complete moves agree. Identical artworks remain ambiguous.
  const eligible=entries.filter(e=>{
   const source=data.sourceMetadata?.cards?.[e.id],entry=data.identities.cards[e.id],p=data.catalogue.get(Number(e.productId));
   const ref=data.independentNames?.cards?.[e.setId+'-'+normalNumber(e.number)];
   const parsed=p&&/\[([^\]]+)\]\s*$/.exec(p.name);
   const moves=source&&[...(source.abilities||[]),...(source.attacks||[])].map(x=>normalizeMarketplaceName(x.name)).sort();
   return ref&&source?.category==='Pokemon'&&moves?.length&&p?.idExpansion===entry.expansionId&&marketplaceProductName(p)===normalizeMarketplaceName(ref.name)&&parsed&&JSON.stringify(parsed[1].split('|').map(normalizeMarketplaceName).sort())===JSON.stringify(moves);
  });
  if(eligible.length===1){
   for(const e of entries)if(e.id!==eligible[0].id)policies.set(e.id,{kind:'conflict',productId:e.productId});
   continue;
  }
  conflicts.push({key,entries,reason:'Different source card numbers share a marketplace product; finish/printing requires independent review.'});
  for(const e of entries)policies.set(e.id,{kind:'conflict',productId:e.productId});
 }
 // A known bad link is blocked even when a source refresh omits its entry.
 for(const [id,c] of Object.entries(CORRECTIONS))policies.set(id,{kind:'corrected',...c});
 const result={policies,conflicts};cache.set(data,result);return result;
}
export function identityPolicy(card,data){
 const p=auditIdentities(data).policies.get(card.id)||(CORRECTIONS[card.id]?{kind:'corrected',...CORRECTIONS[card.id]}:null);
 if(!p)return null;
 if(p.kind==='corrected'){
  const product=data?.catalogue.get(p.productId);
  if(card.set?.id!==p.setId||normalNumber(card.localId||card.number)!==normalNumber(p.number)||clean(card.name)!==clean(p.name)||product?.idExpansion!==p.expansionId||clean(product.name.replace(/\s*\[[^\]]+\]\s*$/,''))!==clean(p.name))return {...p,kind:'conflict'};
 }
 return p;
}
export function correctedCard(card,p){
 return {...card,pricing:{},thirdParty:{cardmarket:p.productId},variants:{normal:false,holo:p.finish==='holo',reverse:false},variants_detailed:[{type:p.finish,size:'standard',variantId:'independently-corrected',thirdParty:{cardmarket:p.productId}}]};
}
