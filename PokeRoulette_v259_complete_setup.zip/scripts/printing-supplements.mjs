// Exact printing identities, never custom prices. Source omits these variants.
// Cardmarket's Pitch Black: Additionals catalogue and printed xPBL numbers,
// plus the retailer/blister printing evidence already used by the application.
// Runtime checks require exact set/number/name, family, metacard and full moves.
import {normalizeMarketplaceName as normal,marketplaceProductName} from './marketplace-identity.mjs';
export const PRINTING_SUPPLEMENTS=[
 {id:'me05-012',name:'Armarouge',base:895800,product:897287,stamp:['whats-your-favourite'],url:'https://www.cardmarket.com/en/Pokemon/Products/Singles/Pitch-Black-Additionals/Armarouge-xPBL012'},
 {id:'me05-020',name:'Primarina',base:895808,product:897285,stamp:['whats-your-favourite'],url:'https://www.cardmarket.com/en/Pokemon/Products/Singles/Pitch-Black-Additionals/Primarina-xPBL020'},
 {id:'me05-056',name:'Zarude',base:895841,product:897286,stamp:['whats-your-favourite'],url:'https://www.cardmarket.com/en/Pokemon/Products/Singles/Pitch-Black-Additionals/Zarude-xPBL056'},
 {id:'me05-040',name:'Marshadow',base:895826,product:914415,foil:'cosmos',url:'https://www.cardmarket.com/en/Pokemon/Products/Singles/Pitch-Black-Additionals/Marshadow-xPBL040'}
];
export function applyPrintingSupplements(data){
 data.identities=structuredClone(data.identities);data.printingSupplements=[];
 for(const r of PRINTING_SUPPLEMENTS){
  const e=data.identities.cards[r.id],c=data.sourceMetadata?.cards?.[r.id],p=data.catalogue.get(r.product),b=data.catalogue.get(r.base);
  if(!e||!c||e.setId!==c.set.id||normal(e.name)!==normal(r.name)||e.expansionId!==6569||p?.idExpansion!==6640||b?.idExpansion!==6569||!b.idMetacard||p.idMetacard!==b.idMetacard||marketplaceProductName(p)!==normal(r.name))continue;
  const sig=x=>[...(x.abilities||[]),...(x.attacks||[])].map(v=>normal(v.name)).sort().join('|');
  const match=/\[([^\]]+)\]\s*$/.exec(p.name);if(!match||match[1].split('|').map(normal).sort().join('|')!==sig(c))continue;
  const v={type:'holo',...(r.foil?{foil:r.foil}:{}),...(r.stamp?{stamp:r.stamp}:{}),thirdParty:{cardmarket:r.product}};
  const key=x=>JSON.stringify([x.type,x.foil||'',[...(x.stamp||[])].sort()]);
  if(e.variants.some(x=>key(x)===key(v)))continue;
  e.variants.push(v);data.printingSupplements.push({cardId:r.id,productId:r.product,url:r.url});
 }
}
