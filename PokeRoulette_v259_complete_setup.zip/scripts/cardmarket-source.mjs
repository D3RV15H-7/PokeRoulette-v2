import {baseFinish,positive,normalNumber} from './price-model.mjs';
import {normalizeMarketplaceName,marketplaceProductName,variantProductAllowed} from './marketplace-identity.mjs';
export const CARDMARKET_URLS={prices:'https://downloads.s3.cardmarket.com/productCatalog/priceGuide/price_guide_6.json',products:'https://downloads.s3.cardmarket.com/productCatalog/productList/products_singles_6.json'};
const normal=normalizeMarketplaceName;
const productName=marketplaceProductName;
const signature=(name,attacks)=>normal(name)+'|'+attacks.map(normal).sort().join('|');
// The source omits LV.X for this one reprint. Keep the correction tied to
// its exact source position and marketplace SKU, never to all Palkia cards.
const PRINTING_NAMES={'30th-c-022':{setId:'30th-c',number:'022',sourceName:'Palkia',productName:'Palkia LV.X',productId:907950,expansionId:6601,printedNumber:'106'}};
export function verifiedPrintingName(card,product){
 const row=PRINTING_NAMES[card.id];
 return row&&card.set?.id===row.setId&&normalNumber(card.localId||card.number)===normalNumber(row.number)&&normal(card.name)===normal(row.sourceName)&&product?.idProduct===row.productId&&product.idExpansion===row.expansionId&&productName(product)===normal(row.productName)?row:null;
}
export const productMatchesCard=(card,product)=>productName(product)===normal(card.name)||(card._independentName&&productName(product)===normal(card._independentName))||!!verifiedPrintingName(card,product);
export function indexCardmarket(prices,products,now=Date.now()){
 if(prices?.version!==1||!Array.isArray(prices.priceGuides)||!Array.isArray(products?.products)||!Number.isFinite(Date.parse(prices.createdAt))||Date.parse(prices.createdAt)>now+86400000||now-Date.parse(prices.createdAt)>7*86400000)throw new Error('Invalid or stale Cardmarket download');
 const catalogue=new Map(products.products.filter(p=>p.idCategory===51&&Number.isInteger(p.idProduct)&&p.name).map(p=>[p.idProduct,p]));
 const guide=new Map(prices.priceGuides.filter(p=>p.idCategory===51&&Number.isInteger(p.idProduct)).map(p=>[p.idProduct,p]));
 if(!catalogue.size||!guide.size)throw new Error('Empty Cardmarket download');
 // Verified product identities, not custom prices. Validate the release before
 // matching names and complete attack signatures within that release only.
 const anchors=[[907607,'Exeggcute'],[907608,'Alolan Exeggutor'],[907609,'Volbeat']];
 const releaseValid=anchors.every(([id,name])=>catalogue.get(id)?.idExpansion===6601&&productName(catalogue.get(id))===normal(name));
 const release=new Map();
 if(releaseValid)for(const p of catalogue.values()){
  if(p.idExpansion!==6601)continue;
  const match=/^(.+?)\s*\[([^\]]+)\]\s*$/.exec(p.name);if(!match)continue;
  const key=signature(match[1],match[2].split('|').map(s=>s.trim()));
  release.set(key,release.has(key)?null:p.idProduct);
 }
 return {catalogue,guide,release,releaseValid,updated:prices.createdAt};
}
export function hydrateCardmarketIdentity(card,data){
 const independent=data?.independentNames?.cards?.[card.set?.id+'-'+normalNumber(card.localId||card.number)];
 if(independent)card={...card,_independentName:independent.name};
 const entry=data?.identities?.cards?.[card.id];
 if(!entry)return card;
 if(entry.setId!==card.set?.id||![entry.name,independent?.name].filter(Boolean).some(name=>normal(name)===normal(card.name))||normalNumber(entry.number)!==normalNumber(card.localId||card.number||''))return {...card,_identityMapRejected:true};
 if(!data.catalogue?.size||!data.updated)return card; // Download failure is not an identity rejection.
 const repair=data.repairById?.get(card.id)||data.mappingRepairs?.find(r=>r.cardId===card.id);
 if(repair){
  const fix=id=>repair.previousIds.includes(Number(id))?repair.productId:id;
  card={...card,pricing:{...card.pricing,cardmarket:undefined},thirdParty:{...card.thirdParty,cardmarket:fix(card.thirdParty?.cardmarket)},variants_detailed:(card.variants_detailed||card.variantsDetailed||[]).map(v=>({...v,thirdParty:{...v.thirdParty,cardmarket:fix(v.thirdParty?.cardmarket)},pricing:v.pricing?{...v.pricing,cardmarket:undefined}:undefined}))};
 }
 const validProduct=id=>{const p=data.catalogue.get(Number(id));return p&&p.idExpansion===entry.expansionId&&productMatchesCard(card,p);};
 const validVariant=v=>variantProductAllowed(card,entry,v,data,productMatchesCard);
 const variants=(entry.variants||[]).filter(v=>['normal','holo','reverse'].includes(v.type)&&(!v.size||v.size==='standard')&&!v.staff&&!v.stamp?.some(s=>/staff/i.test(String(s)))&&(!v.languages?.length||v.languages.includes('en'))&&validVariant(v));
 const existing=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v.variantId!=='generated'&&v.thirdParty?.cardmarket);
 // An explicit live ID that disagrees with the source is a conflict to
 // review, even when another printing has the same name and expansion.
 const allowed=new Set([entry.thirdParty?.cardmarket,...(entry.variants||[]).map(v=>v.thirdParty?.cardmarket)].filter(Boolean).map(Number));
 if(existing.length){
  const good=existing.filter(v=>allowed.has(Number(v.thirdParty.cardmarket))&&validVariant(v));
  if(!good.length)return {...card,_identityMapRejected:true};
  const key=v=>JSON.stringify([v.type,v.foil||'',v.subtype||'',v.size||'standard',[...(v.stamp||[])].sort()]);
  const existingKeys=new Set(existing.map(key));
  // Fill only absent printings; an explicitly conflicting live SKU stays rejected.
  good.push(...variants.filter(v=>!existingKeys.has(key(v))).map((v,i)=>({...v,variantId:'verified-extra-'+i})));
  if(!good.length)return {...card,_identityMapRejected:true};
  return {...card,variants:{...card.variants,normal:good.some(v=>v.type==='normal'),holo:good.some(v=>v.type==='holo'),reverse:good.some(v=>v.type==='reverse')},variants_detailed:good,_rejectedVariantCount:existing.length-good.length};
 }
 if(variants.length){
  return {...card,variants:{...card.variants,normal:variants.some(v=>v.type==='normal'),holo:variants.some(v=>v.type==='holo'),reverse:variants.some(v=>v.type==='reverse')},variants_detailed:variants.map((v,i)=>({...v,variantId:'published-source-'+i})),_identitySourceApplied:true};
 }
 if(entry.thirdParty?.cardmarket&&validProduct(entry.thirdParty.cardmarket)){
  const current=card.pricing?.cardmarket?.idProduct||card.thirdParty?.cardmarket;
  if(current&&Number(current)!==Number(entry.thirdParty.cardmarket))return {...card,_identityMapRejected:true};
  const foilOnly=independent?.foilOnly;
  return {...card,...(foilOnly?{variants:{...card.variants,normal:false,holo:true}}:{}),thirdParty:{...card.thirdParty,...entry.thirdParty},_identitySourceApplied:!current};
 }
 return {...card,_identityMapRejected:true};
}
export function directCardmarketQuote(card,data,finishOverride=null){
 if(!data||card._identityMapRejected)return null;
 const finish=finishOverride||baseFinish(card);
 const details=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v.variantId!=='generated'&&v.type===finish&&(!v.size||v.size==='standard')&&(!v.languages?.length||v.languages.some(l=>/^en(?:-|$)/i.test(l)))&&!v.staff);
 const plain=details.filter(v=>(!v.subtype||String(v.subtype).toLowerCase()==='unlimited')&&!v.stamp?.length&&!v.foil);
 const selected=plain.length?plain:details;
 const ids=[...new Set(selected.map(v=>Number(v.thirdParty?.cardmarket)).filter(Boolean))];
 let id=ids.length===1?ids[0]:null,suffix='';
 if(ids.length>1)return null;
 const all=card._pricingAllVariants||card.variants_detailed||card.variantsDetailed||[];
 if(id&&['holo','reverse'].includes(finish)&&['normal','holo','reverse'].every(type=>all.some(v=>v.type===type&&Number(v.thirdParty?.cardmarket)===id)))return null;
 if(id&&((finish==='holo'&&all.some(v=>v.type==='normal'&&Number(v.thirdParty?.cardmarket)===id))||(finish==='reverse'&&all.some(v=>['normal','holo'].includes(v.type)&&Number(v.thirdParty?.cardmarket)===id))))suffix='-holo';
 if(!id&&finish!=='reverse'){
  id=Number(card.pricing?.cardmarket?.idProduct||card.thirdParty?.cardmarket)||null;
  if(id&&finish==='holo'&&card.variants?.normal)suffix='-holo';
 }
 if(!id&&card.set?.id==='30th'&&normal(card.set.name)==='30thcelebration'&&finish==='normal'){
  const moves=[...(card.abilities||[]),...(card.attacks||[])].map(a=>a.name);
  const anchor={'001':[907607,'Exeggcute'],'002':[907608,'Alolan Exeggutor'],'003':[907609,'Volbeat']}[String(card.localId||card.number||'').padStart(3,'0')];
  const known=anchor&&data.releaseValid&&normal(anchor[1])===normal(card.name)?data.catalogue.get(anchor[0]):null;
  const parsed=known&&/^(.+?)\s*\[([^\]]+)\]\s*$/.exec(known.name);
  id=parsed&&signature(parsed[1],parsed[2].split('|').map(s=>s.trim()))===signature(card.name,moves)?anchor[0]:card._cardmarketNameUnique===true?data.release.get(signature(card.name,moves))||null:null;
 }
 const product=data.catalogue.get(id),row=data.guide.get(id);
 const pair=data.approvedFinishPairs?.get(card.id);if(pair&&pair.productId===id&&pair.finish===finish)suffix=pair.fieldSuffix;
 if(!product||!row||!productMatchesCard(card,product))return null;
 const candidates=[['trend',0,'Cardmarket trend'],['avg30',2,'Cardmarket 30-day avg'],['avg7',3,'Cardmarket 7-day avg'],['avg',4,'Cardmarket average'],['avg1',5,'Cardmarket 1-day avg']];
 for(const [field,priority,source] of candidates){const amount=positive(row[field+suffix]);if(amount!==null)return {amount,currency:'EUR',source,updated:data.updated,priority,via:'Cardmarket daily extract',productId:id,fieldSuffix:suffix};}
 return null;
}
export function preferDirectQuote(existing,direct){
 if(!direct)return existing;
 if(existing&&existing.priority<direct.priority)return existing;
 // A download from an earlier source day must not replace a newer same-source quote.
 if(existing&&existing.priority===direct.priority&&String(existing.updated||'').slice(0,10)>String(direct.updated||'').slice(0,10))return existing;
 return direct;
}
