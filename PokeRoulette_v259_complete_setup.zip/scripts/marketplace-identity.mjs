const ENERGY={G:'grass',R:'fire',W:'water',L:'lightning',P:'psychic',F:'fighting',D:'darkness',M:'metal',N:'dragon',C:'colorless',Y:'fairy'};
export function normalizeMarketplaceName(value){
 let s=String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
 s=s.replace(/α/g,' alpha ').replace(/β/g,' beta ').replace(/γ/g,' gamma ');
 s=s.replace(/δ/g,/\b(?:mystery plate|miracle sphere)\b/i.test(s)?' delta ':' delta species ').replace(/(?:delta\s+species\s*){2,}/gi,'delta species ');
 s=s.replace(/\bImpostor Professor Oak\b/gi,'Imposter Professor Oak').replace(/\bProf\.?(?=\s+Oak)/gi,'Professor');
 // Bracketed F/M are genders only after Nidoran. For Energy they are types.
 s=s.replace(/\bNidoran\s*\[F\]/gi,'Nidoran female').replace(/\bNidoran\s*\[M\]/gi,'Nidoran male');
 if(/\benergy\b/i.test(s))s=s.replace(/\[([GRWLPFDMNCY])\]/gi,(_,t)=>' '+ENERGY[t.toUpperCase()]+' ');
 return s.replace(/\s+Lv\.?\s*\d+\b/gi,'').replace(/♀/g,' female ').replace(/♂/g,' male ').toLowerCase().replace(/[^a-z0-9]/g,'');
}
export const marketplaceProductName=p=>normalizeMarketplaceName(String(p?.name||'').replace(/\s*\[(?![GRWLPFDMNCY]\]|Ice\]|Rock\]|Steel\])[^\]]+\]\s*$/i,''));
// Verified family relationship, never an unrestricted expansion bypass.
// Cardmarket's Pitch Black versions page distinguishes Pitch Black: Additionals.
// Source variants supply the exact SKU; the catalogue supplies the metacard.
export const ADDITIONAL_FAMILIES=Object.fromEntries([
 [6569,6640,'Pitch Black'],[6443,6516,'Perfect Order'],[6517,6518,'Chaos Rising'],
 [6299,6300,'Phantasmal Flames'],[6209,6290,'Mega Evolution'],[6395,6455,'Ascended Heroes'],
 [6006,6088,'Journey Together'],[5944,6009,'Prismatic Evolutions'],
 [6134,6197,'Black Bolt'],[6135,6198,'White Flare']
].map(([base,expansionId,name])=>[base,{expansionId,name:name+': Additionals'}]));
const printingKey=v=>JSON.stringify([v.type,v.foil||'',v.subtype||'',v.size||'standard',[...(v.stamp||[])].sort()]);
export function variantProductAllowed(card,entry,variant,data,nameMatches){
 const product=data?.catalogue.get(Number(variant.thirdParty?.cardmarket));
 if(!product||!nameMatches(card,product))return false;
 if(product.idExpansion===entry.expansionId)return true;
 const family=ADDITIONAL_FAMILIES[entry.expansionId];
 if(!family||product.idExpansion!==family.expansionId)return false;
 const declared=(entry.variants||[]).some(v=>printingKey(v)===printingKey(variant)&&Number(v.thirdParty?.cardmarket)===product.idProduct);
 if(!declared||!product.idMetacard)return false;
 return (entry.variants||[]).some(v=>{
  if(!['normal','holo'].includes(v.type))return false;
  const base=data.catalogue.get(Number(v.thirdParty?.cardmarket));
  return base?.idExpansion===entry.expansionId&&base.idMetacard===product.idMetacard&&nameMatches(card,base);
 });
}
