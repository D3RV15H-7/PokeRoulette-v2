// Same base-card price order as the app. No asking prices or manual valuations.
export const positive = value => { const n=Number(value); return value!==null&&value!==''&&Number.isFinite(n)&&n>0?n:null; };
export const clean = value => String(value||'').toLowerCase().replace(/[^a-z0-9]/g,'');
export const normalNumber = value => clean(value).replace(/^([a-z]*)0+(?=\d)/,'$1');
export function numberAliases(value){
 const raw=String(value||'').split('/')[0].trim();const match=/^([a-z]*)(\d+)$/i.exec(raw);
 return [...new Set([raw,raw.toLowerCase(),...(match?[match[1]+Number(match[2]),match[1]+String(Number(match[2])).padStart(2,'0'),match[1]+String(Number(match[2])).padStart(3,'0')]:[])])];
}
function buckets(tcg={}){return {normal:tcg.normal||tcg.unlimited||tcg['1st-edition'],holo:tcg.holofoil||tcg.holo||tcg['unlimited-holofoil']||tcg['1st-edition-holofoil'],reverse:tcg['reverse-holofoil']||tcg.reverse||tcg.reverseHolofoil};}
function sameProduct(a,b){return ['cardmarket','tcgplayer'].some(p=>a?.thirdParty?.[p]&&String(a.thirdParty[p])===String(b?.thirdParty?.[p]));}
export function baseFinish(card){
 const details=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v&&v.variantId!=='generated'&&(!v.size||v.size==='standard')&&(!v.languages?.length||v.languages.some(l=>/^en(?:-|$)/i.test(l)))&&!v.staff&&!v.stamp?.some?.(s=>/staff/i.test(String(s))));
 // Stamped championship reprints are alternatives, not the ordinary base.
 const plain=details.filter(v=>(!v.subtype||String(v.subtype).toLowerCase()==='unlimited')&&!v.stamp?.length&&!v.foil);
 const base=plain.some(v=>v.type==='normal'||v.type==='holo')?plain:details;
 const normal=base.filter(v=>v.type==='normal'),holo=base.filter(v=>v.type==='holo'),reverse=base.find(v=>v.type==='reverse');
 if(!normal.length&&!holo.length&&details.length&&details.every(v=>v.type==='reverse')&&!card.variants?.normal&&!card.variants?.holo)return 'reverse';
 if(normal.length&&holo.length){return reverse&&holo.some(v=>sameProduct(v,reverse))&&!normal.some(v=>sameProduct(v,reverse))?'holo':'normal';}
 if(normal.length)return 'normal';if(holo.length)return 'holo';
 if(card.variants?.normal)return 'normal';if(card.variants?.holo)return 'holo';
 const b=buckets(card.pricing?.tcgplayer);return b.normal?'normal':b.holo?'holo':card.variants?.reverse&&b.reverse?'reverse':null;
}
export function selectQuote(card,finish=baseFinish(card)){
 const tcg=card.pricing?.tcgplayer||{},cm=card.pricing?.cardmarket||{},b=buckets(tcg);
 const detailed=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v&&v.variantId!=='generated'&&(!v.size||v.size==='standard')&&(!v.languages?.length||v.languages.some(l=>/^en(?:-|$)/i.test(l))));
 let type=finish;if(!detailed.some(v=>v.type===type)){if(b.holo&&!b.normal)type='holo';else if(b.normal&&!b.holo)type='normal';}
 let variant=detailed.find(v=>v.type===type&&(!v.subtype||String(v.subtype).toLowerCase()==='unlimited')&&!v.stamp?.length&&!v.foil);
 const sourceBucket=type==='holo'?b.holo:type==='reverse'?b.reverse:b.normal;
 if(!variant&&type==='reverse'&&detailed.length&&detailed.every(v=>v.type==='reverse')){
  // Reverse-only releases can legitimately have a set-wide stamp. Require
  // the exact marketplace product rather than borrowing another finish.
  variant=detailed.find(v=>v.type==='reverse'&&String(v.thirdParty?.tcgplayer||'')===String(sourceBucket?.productId||'')&&v.thirdParty?.tcgplayer);
 }
 const product=String(cm.idProduct||card.thirdParty?.cardmarket||''),variantProduct=String(variant?.thirdParty?.cardmarket||'');
 const mainProduct=product&&(variantProduct===product||(!variantProduct&&((b.holo&&!b.normal)||(card.variants?.holo&&!card.variants?.normal))));
 const suffix=type==='holo'&&!mainProduct?'-holo':'';
 const selected=Object.fromEntries(['trend','avg','avg1','avg7','avg30'].map(k=>[k,cm[k+suffix]]));
 const vp=variant?.pricing||{},vt=vp.tcgplayer||{},vb=buckets(vt);
 const merge=(a,b)=>({...a,...Object.fromEntries(Object.entries(b||{}).filter(([,v])=>v!=null))});
 let detailBucket=type==='holo'?vb.holo:type==='reverse'?vb.reverse:vb.normal;
 if(!detailBucket&&variant?.thirdParty?.tcgplayer){
  const exact=Object.values(vt).filter(value=>value&&typeof value==='object'&&String(value.productId||'')===String(variant.thirdParty.tcgplayer));
  if(exact.length===1)detailBucket=exact[0];
 }
 const chosenCm=merge(selected,vp.cardmarket),chosenTcg=merge(sourceBucket,detailBucket||vt);
 const candidates=[
  [chosenCm.trend,'EUR','Cardmarket trend',vp.cardmarket?.updated||cm.updated],
  [chosenTcg.marketPrice??chosenTcg.market,'USD','TCGplayer market',vt.updated||tcg.updated],
  [chosenCm.avg30,'EUR','Cardmarket 30-day avg',vp.cardmarket?.updated||cm.updated],
  [chosenCm.avg7,'EUR','Cardmarket 7-day avg',vp.cardmarket?.updated||cm.updated],
  [chosenCm.avg??chosenCm.average,'EUR','Cardmarket average',vp.cardmarket?.updated||cm.updated],
  [chosenCm.avg1,'EUR','Cardmarket 1-day avg',vp.cardmarket?.updated||cm.updated]
 ];
 for(const [priority,[value,currency,source,updated]] of candidates.entries()){
  const amount=positive(value);if(amount!==null)return {amount,currency,source,updated:updated||null,priority};
 }
 return null;
}
