import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {selectQuote,baseFinish,clean,normalNumber} from './price-model.mjs';
import {CARDMARKET_URLS,indexCardmarket,directCardmarketQuote,preferDirectQuote,hydrateCardmarketIdentity,verifiedPrintingName} from './cardmarket-source.mjs';
import {auditIdentities,identityPolicy,correctedCard} from './identity-policy.mjs';
import {printingPrices} from './printing-prices.mjs';
import {resolveIdentities} from './resolve-identities.mjs';
import {normalizeMarketplaceName} from './marketplace-identity.mjs';
import {writeCoverageReport} from './coverage-report.mjs';
export const PRICING_MODEL_VERSION=254;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const day=timestamp=>new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London'}).format(new Date(timestamp));
export async function readJson(path,fallback=null){try{return JSON.parse(await readFile(path,'utf8'));}catch{return fallback;}}
export async function atomicJson(path,data){await mkdir(dirname(path),{recursive:true});const temp=path+'.tmp';await writeFile(temp,JSON.stringify(data));await rename(temp,path);}
export function validSnapshot(s){return s?.schemaVersion===1&&s.cards&&typeof s.cards==='object'&&!Array.isArray(s.cards)&&s.sets&&typeof s.sets==='object';}
export async function fetchJson(url,{fetchImpl=fetch,retries=2,timeoutMs=15000}={}){
 let last;
 for(let attempt=0;attempt<=retries;attempt++){
  try{
   const response=await fetchImpl(url,{signal:AbortSignal.timeout(timeoutMs),headers:{Accept:'application/json','User-Agent':'PokeRoulette-daily-price-snapshot/1'}});
   if(!response.ok){const error=new Error('HTTP '+response.status);error.status=response.status;error.retryAfter=Math.min(60,Number(response.headers.get('retry-after'))||0);throw error;}
   return await response.json();
  }catch(error){last=error;error.attempts=attempt+1;if(attempt===retries||error.status===404)throw error;await sleep((error.retryAfter||attempt+1)*1000);}
 }
 throw last;
}
function setMetadata(sets,manifest){
 const result={};
 for(const set of sets){
  const aliases=Object.entries(manifest.setAliases||{}).filter(([,canonical])=>canonical===set.id).map(([id])=>id);
  const bundled=(manifest.sets||[]).filter(s=>s.id===set.id||aliases.includes(s.id)||clean(s.name)===clean(set.name));
  result[set.id]={name:set.name,aliases:[...new Set([set.id,...aliases,...bundled.map(s=>s.id)])],names:[...new Set([set.name,...bundled.map(s=>s.name)])]};
 }
 return result;
}
export function priceRecord(card,previous,now,directData=null){
 if(!directData?.updated&&previous?.pricingModelVersion>=253&&previous.quote)return {...previous,lastAttemptAt:now,retained:true,noFreshQuote:true};
 const originalCard=card;
 let policy=identityPolicy(card,directData)||(!directData&&previous?.rejectCachedQuote?{kind:'conflict'}:null);
 card=['corrected','finish_pair'].includes(policy?.kind)?correctedCard(card,policy):hydrateCardmarketIdentity(card,directData);
 if(card._identityMapRejected&&!policy)policy={kind:'conflict'};
 const finish=baseFinish(card),quote=policy?.kind==='conflict'?null:preferDirectQuote(selectQuote(card,finish),directCardmarketQuote(card,directData));
 const anyPricing=card.pricing?.cardmarket||card.pricing?.tcgplayer||(card.variants_detailed||card.variantsDetailed||[]).some(v=>v.pricing?.cardmarket||v.pricing?.tcgplayer);
 const noPriceReason=directData||anyPricing?'source_has_no_supported_market_quote':'source_pricing_empty';
 const marketMatchReason=card._identityMapRejected?'identity_not_verified':card._identitySourceApplied?'market_quote_missing':directData&&!anyPricing?'no_verified_marketplace_link':noPriceReason;
 const record={name:card.name,setId:card.set.id,number:String(card.localId||card.number||String(card.id).split('-').pop()),baseFinish:finish,quote,
  checkedAt:now,lastAttemptAt:now,retained:false,identitySourceApplied:!!card._identitySourceApplied,identityMapVersion:directData?.identities?.sourceSha256||null,cardmarketExtractChecked:directData?.updated||null,pricingModelVersion:PRICING_MODEL_VERSION};
 record.printingQuotes=printingPrices(card,originalCard,directData,policy?.kind==='conflict');
 record.printingQuotesVersion=252;record.rejectCachedQuote=true;
 const rootProduct=directData?.identities?.cards?.[card.id]?.thirdParty?.cardmarket;
 if(record.quote?.via==='Cardmarket daily extract'&&Number(rootProduct)===Number(record.quote.productId)&&record.baseFinish){
  const simple=record.printingQuotes.find(r=>r.printing.type===record.baseFinish&&!r.printing.foil&&!r.printing.subtype&&!r.printing.stamp.length);
  if(simple){simple.quote=record.quote;simple.reason=null;}
  else if(!record.printingQuotes.length)record.printingQuotes.push({printing:{type:record.baseFinish,foil:'',subtype:'',size:'standard',stamp:[]},quote:record.quote,reason:null});
 }
 if(policy){record.identityPolicyVersion=251;record.identityStatus=policy.kind;record.rejectCachedQuote=true;if(policy.kind==='conflict'){record.noPriceReason='identity_conflict';record.marketMatchReason='identity_conflict';}}
 const naming=verifiedPrintingName(card,directData?.catalogue.get(quote?.productId));
 if(naming){record.nameAliases=[naming.productName];record.printedNumber=naming.printedNumber;}
 if(card._independentName&&card._independentName!==card.name)record.nameAliases=[...new Set([...(record.nameAliases||[]),card._independentName])];
 // A missing field is not proof a previously priced printing has no value.
 // Preserve its real quote and source date, but report the retention explicitly.
 if(!quote&&!record.noPriceReason){record.noPriceReason=noPriceReason;record.marketMatchReason=marketMatchReason;}
 if(!quote&&previous?.quote&&!policy){record.quote=previous.quote;record.checkedAt=previous.checkedAt;record.retained=true;record.noFreshQuote=true;}
 return record;
}
export async function buildSnapshot({previous=null,manifest={},fetchImpl=fetch,baseUrl='https://api.tcgdex.net/v2/en',directData=null,directError=null,workers=4,maxMinutes=240,now=new Date().toISOString(),checkpoint=async()=>{}}={}){
 const start=Date.now(),deadline=start+maxMinutes*60000;
 const get=url=>fetchJson(url,{fetchImpl});
 const [sets,catalogue]=await Promise.all([get(baseUrl+'/sets'),get(baseUrl+'/cards')]);
 if(!Array.isArray(sets)||!sets.length||!Array.isArray(catalogue)||!catalogue.length)throw new Error('Invalid or empty provider catalogue; previous snapshot is untouched.');
 const briefs=catalogue.filter(c=>c?.id&&c.name&&!/^(?:[ab]\d|p-[ab]-)/i.test(c.id));
 const releaseNameCounts=new Map();for(const brief of briefs)if(brief.id.startsWith('30th-'))releaseNameCounts.set(clean(brief.name),(releaseNameCounts.get(clean(brief.name))||0)+1);
 const cards=validSnapshot(previous)?{...previous.cards}:{};
 // Invalidate suspect saved quotes before network requests so a failed
 // refresh cannot resurrect them from the checkpoint or published snapshot.
 for(const [id,old] of Object.entries(cards)){
  const c={id,name:old.name,localId:old.number,set:{id:old.setId}};
  if(identityPolicy(c,directData)||(directData?.updated&&hydrateCardmarketIdentity(c,directData)._identityMapRejected))cards[id]={...priceRecord(c,null,now,directData),lastAttemptAt:old.lastAttemptAt};
 }
 const snapshot={schemaVersion:1,generatedAt:now,status:'building',provider:'TCGdex + Cardmarket daily extracts',cardmarketExtract:directData?{updated:directData.updated}:null,pricingModelVersion:PRICING_MODEL_VERSION,diagnostics:{failedRequests:[],unpriced:[],cardmarketExtract:{available:!!directData,error:directError}},sets:setMetadata(sets,manifest),cards,fx:previous?.fx||null,
  summary:{catalogueCards:briefs.length,requested:0,succeeded:0,failed:0,reused:0,priced:0,unpriced:0,retained:0,pending:0}};
 const summary=snapshot.summary;
 snapshot.diagnostics.identityConflicts=auditIdentities(directData).conflicts;
 summary.identityConflictGroups=snapshot.diagnostics.identityConflicts.length;
 // The live catalogue can lag behind the publisher's own English source.
 // Add those exact identities from the published source, after validating
 // the set, number, name, finish and marketplace product. No guessed prices
 // or individual API requests are required for these omitted entries.
 const catalogueIds=new Set(briefs.map(c=>c.id));
 summary.sourceOnlyCards=0;summary.sourceOnlyPriced=0;
 for(const [id,entry] of Object.entries(directData?.identities?.cards||{})){
  if(catalogueIds.has(id)||!snapshot.sets[entry.setId]||id!==entry.setId+'-'+entry.number||!entry.variants?.length)continue;
  const source={id,name:entry.name,localId:entry.number,set:{id:entry.setId,name:snapshot.sets[entry.setId].name},variants:{},variants_detailed:[{variantId:'generated',type:'normal'}]};
  const hydrated=hydrateCardmarketIdentity(source,directData);
  if(!hydrated._identitySourceApplied||hydrated._identityMapRejected)continue;
  const old=cards[id];
  if(old&&(old.setId!==entry.setId||normalNumber(old.number)!==normalNumber(entry.number)||clean(old.name)!==clean(entry.name)))continue;
  const record=priceRecord(source,old,now,directData);record.catalogueSource='published English identity source';
  cards[id]=record;summary.sourceOnlyCards++;if(record.quote)summary.sourceOnlyPriced++;
 }
 // Restore metadata when a set disappeared temporarily from a catalogue feed.
 for(const [id,set] of Object.entries(previous?.sets||{}))if(!snapshot.sets[id])snapshot.sets[id]=set;
 const pending=briefs.filter(brief=>{const old=cards[brief.id];if(old?.lastAttemptAt&&!old.error&&(!directData||(old.cardmarketExtractChecked===directData.updated&&old.identityMapVersion===(directData.identities?.sourceSha256||null)))&&(old.pricingModelVersion===PRICING_MODEL_VERSION||(!directData&&old.quote))&&day(old.lastAttemptAt)===day(now)){summary.reused++;return false;}return true;});
 // First fetch new cards; an interrupted initial build can resume next run.
 pending.sort((a,b)=>Number(!!cards[a.id])-Number(!!cards[b.id])||String(cards[a.id]?.checkedAt||'').localeCompare(String(cards[b.id]?.checkedAt||'')));
 let next=0,completedSinceCheckpoint=0;
 async function worker(){
  while(next<pending.length&&Date.now()<deadline){
   const brief=pending[next++];summary.requested++;
   try{
    const card=await get(baseUrl+'/cards/'+encodeURIComponent(brief.id));
    if(card?.id!==brief.id||!card.set?.id||!card.name)throw new Error('Card identity mismatch');
    const previousRecord=cards[brief.id];
    const independentName=directData?.independentNames?.cards?.[card.set.id+'-'+normalNumber(card.localId||card.number)]?.name;
    const sameName=previousRecord&&[previousRecord.name,...(previousRecord.nameAliases||[]),independentName].filter(Boolean).some(name=>normalizeMarketplaceName(name)===normalizeMarketplaceName(card.name));
    if(previousRecord&&(previousRecord.setId!==card.set.id||!sameName||normalNumber(previousRecord.number)!==normalNumber(card.localId||card.number||card.id.split('-').pop())))throw new Error('Changed printing identity requires review');
    cards[brief.id]=priceRecord({...card,_cardmarketNameUnique:releaseNameCounts.get(clean(card.name))===1},previousRecord,now,directData);
    // Separate stamped sets only match their own exact set and card identity.
    // Never price a promotional stamp from its unstamped parent printing.
    const record=cards[brief.id];
    for(const set of manifest.supplemental||[]){
      if(set.id!==card.set.id&&clean(set.name)!==clean(card.set.name))continue;
      const entry=set.cards.find(c=>normalNumber(c.number)===normalNumber(record.number)&&clean(c.name)===clean(card.name));
      if(entry)record.ownershipAliases=[entry.id,...(set.id==='ex5.5'?[]:['fp_standalone_'+entry.id])];
    }
    summary.succeeded++;
    if(!snapshot.sets[card.set.id])snapshot.sets[card.set.id]={name:card.set.name||card.set.id,aliases:[card.set.id],names:[card.set.name||card.set.id]};
   }catch(error){
    summary.failed++;
    const failure={cardId:brief.id,name:brief.name,attemptedAt:new Date().toISOString(),httpStatus:error.status||null,attempts:error.attempts||1,errorType:error.name||'Error',message:String(error.message).slice(0,300),retainedPreviousPrice:!!cards[brief.id]?.quote};
    snapshot.diagnostics.failedRequests.push(failure);
    console.warn('[price-request-failed] '+JSON.stringify(failure));
    if(cards[brief.id])cards[brief.id]={...cards[brief.id],lastAttemptAt:now,retained:!!cards[brief.id].quote,error:String(error.message).slice(0,160)};
    // No invented record for a failed first-time request.
   }
   completedSinceCheckpoint++;
   if(completedSinceCheckpoint>=500){completedSinceCheckpoint=0;console.log('[price-progress] '+JSON.stringify({checked:summary.requested,total:pending.length,succeeded:summary.succeeded,failed:summary.failed}));await checkpoint(snapshot);}
   await sleep(150);
  }
 }
 await Promise.all(Array.from({length:Math.min(workers,pending.length)},worker));
 summary.pending=pending.length-summary.requested;
 for(const [cardId,record] of Object.entries(cards)){if(!record.quote)snapshot.diagnostics.unpriced.push({cardId,name:record.name,setId:record.setId,checkedAt:record.checkedAt,reason:record.marketMatchReason||record.noPriceReason||'source_has_no_supported_market_quote'});if(record.quote)summary.priced++;else summary.unpriced++;if(record.retained)summary.retained++;}
 if(!Object.keys(cards).length||(!summary.succeeded&&!summary.reused)){const error=new Error('No successful price checks; previous published snapshot is untouched.');error.diagnostics=snapshot.diagnostics;throw error;}
 summary.publishedIdentityApplied=Object.values(cards).filter(r=>r.identitySourceApplied).length;
 summary.directCardmarketQuotes=Object.values(cards).filter(r=>r.quote?.via==='Cardmarket daily extract').length;
 snapshot.status=summary.failed||summary.pending?'partial':'ready';
 try{
  const rows=await fetchJson('https://api.frankfurter.dev/v2/rates?base=GBP&quotes=USD,EUR',{fetchImpl,retries:0,timeoutMs:7000});
  const usd=rows.find(r=>r.quote==='USD'&&Number(r.rate)>0),eur=rows.find(r=>r.quote==='EUR'&&Number(r.rate)>0);
  if(usd&&eur)snapshot.fx={usd:1/Number(usd.rate),eur:1/Number(eur.rate),date:usd.date};
 }catch{/* Keep the previous rates and their real date. */}
 return snapshot;
}
export async function main(){
 const args=process.argv.slice(2);const option=(key,fallback)=>{const index=args.indexOf(key);return index<0?fallback:args[index+1];};
 const output=resolve(option('--output','data/prices-v1.json')),checkpointPath=resolve('.price-state/checkpoint.json');
 const manifest=await readJson(resolve('data/price-mapping.json'),{});
 let previous=await readJson(output);const checkpoint=await readJson(checkpointPath);
 if(validSnapshot(checkpoint)&&(Date.parse(checkpoint.generatedAt)>Date.parse(previous?.generatedAt||0)||Object.keys(checkpoint.cards).length>Object.keys(previous?.cards||{}).length))previous=checkpoint;
 const previousUrl=option('--previous-url','');
 if(previousUrl&&(!validSnapshot(previous)||!Object.keys(previous.cards).length)){
  try{const served=await fetchJson(previousUrl,{retries:0,timeoutMs:15000});if(validSnapshot(served))previous=served;}catch{}
 }
 let directData=null,directError=null;
 try{
  const [prices,products]=await Promise.all([fetchJson(CARDMARKET_URLS.prices,{timeoutMs:60000}),fetchJson(CARDMARKET_URLS.products,{timeoutMs:60000})]);
  directData=indexCardmarket(prices,products);
  const identities=await readJson(resolve('data/product-identities-v1.json'));
  if(identities?.schemaVersion===1&&identities.cards&&Object.keys(identities.cards).length>=100)directData.identities=identities;
  directData.independentNames=await readJson(resolve('data/independent-card-names-v1.json'));
  resolveIdentities(directData,await readJson(resolve('data/source-card-metadata-v1.json')),directData.independentNames);
  directData.repairById=new Map((directData.mappingRepairs||[]).map(r=>[r.cardId,r]));
  console.log('[cardmarket-extract] '+JSON.stringify({updated:directData.updated,products:directData.catalogue.size,prices:directData.guide.size}));
 }catch(error){
  directError=String(error.message);console.warn('[cardmarket-extract-unavailable] '+directError);
  const identities=await readJson(resolve('data/product-identities-v1.json'));
  // The collision audit must still run when the market download fails.
  if(identities?.cards)directData={catalogue:new Map(),guide:new Map(),release:new Map(),updated:null,identities};
 }
 let snapshot;
 try{
  snapshot=await buildSnapshot({previous,manifest,directData,directError,workers:4,maxMinutes:240,checkpoint:async s=>{
   await atomicJson(checkpointPath,s);
   if(s.diagnostics)await atomicJson(resolve('diagnostics/price-report.json'),{schemaVersion:1,generatedAt:s.generatedAt,summary:s.summary,...s.diagnostics});
  }});
 }catch(error){
  await atomicJson(resolve('diagnostics/price-report.json'),{schemaVersion:1,generatedAt:new Date().toISOString(),fatal:{message:String(error.message),httpStatus:error.status||null,attempts:error.attempts||1},...(error.diagnostics||{failedRequests:[],unpriced:[]})});
  throw error;
 }
 const diagnostics={schemaVersion:1,generatedAt:snapshot.generatedAt,summary:snapshot.summary,...snapshot.diagnostics};
 await writeCoverageReport(snapshot,directData,{directory:resolve('diagnostics'),manifest});
 await atomicJson(resolve('diagnostics/price-report.json'),diagnostics);
 // The public price file contains prices and summary only; full diagnostics
 // are retained as a workflow artifact and are never collection/account data.
 delete snapshot.diagnostics;
 await atomicJson(output,snapshot);await atomicJson(checkpointPath,snapshot);
 console.log(JSON.stringify({status:snapshot.status,...snapshot.summary}));
 if(process.env.GITHUB_STEP_SUMMARY)await writeFile(process.env.GITHUB_STEP_SUMMARY,'## Daily card prices\n\n'+Object.entries(snapshot.summary).map(([k,v])=>'- '+k+': '+v).join('\n')+'\n',{flag:'a'});
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main().catch(error=>{console.error(error.message);process.exitCode=1;});
