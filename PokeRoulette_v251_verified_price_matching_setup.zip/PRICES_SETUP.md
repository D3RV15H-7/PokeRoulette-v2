# PokeRoulette v251 — marketplace identity checks

Upload the versioned ZIP to the repository root. Rename the separate v251 HTML download to index.html and replace the root index.html. Then replace .github/workflows/daily-prices.yml with the full contents of IPHONE_WORKFLOW.yml and commit to main. This starts the new run. Keep v250 until v251 is deployed successfully.

The product mapping for Generations Pikachu RC29 is corrected to Cardmarket 288538 (holo, standard product price field), instead of the erroneous 288464 shared with the ordinary Pikachu 26. The source card ID, number, name, expansion and exact corrected product must agree. Product-number evidence is documented in scripts/identity-policy.mjs. There are no fixed prices: the daily Cardmarket extract supplies the amount and its real date. The 29 October extract has a trend of EUR147.46; the live website can differ from a daily snapshot.

The automatic audit covers 19,256 published source identities. After separating RC29, it flags 707 marketplace product groups involving 1,514 card identities where different numbers share one product. These are potential conflicts, not 1,514 proven wrong prices. Some are legitimate foil/non-foil groupings. This release conservatively excludes quotes for those unresolved identities until an exact printing/bucket is established. In the baseline, 1,511 of those cards had a quote. Your collection’s priced coverage may decrease; ownership and collection ticks are unchanged.

Explicit live IDs must now agree with the source’s candidate IDs and catalogue expansion/name checks. Disagreements are excluded for review rather than silently choosing either product. This adds protection against incorrect live mappings, but does not independently verify every otherwise unique mapping in the entire catalogue.

Corrected or blocked records carry a policy flag. The app uses those records instead of newer or numeric-only saved estimates. Live refreshes cannot restore a rejected price. The generator invalidates flagged previous quotes before network requests, so a failed refresh cannot retain them. Diagnostics include all duplicate groups and affected IDs. Missing-price examples explain when a marketplace identity needs review.

Prices still update daily at 01:17 UTC. All identity/market downloads run in GitHub Actions. Phones still read the shared price file. No custom price table or private account access is involved. This package has not been deployed just by being prepared.

Validation: 44 Node tests and four Python parser tests. Regressions cover exact RC29 SKU/finish/price field, the ordinary Pikachu remaining separate, a wrong name, missing extracts, duplicate IDs, failed requests after invalidation, a newer incorrect phone cache, and live refreshes. Existing promo, ownership, counting and sorting tests remain included.
