# PokeRoulette v257 — matched application and workflow bundle

Upload PokeRoulette_v257_complete_setup.zip unchanged to the repository root. Replace root index.html with the separate v257 HTML (or extract the HTML-only ZIP). Replace .github/workflows/daily-prices.yml with IPHONE_WORKFLOW.yml, then commit. Keep the existing v254 ZIP until the v257 deployment succeeds. The complete setup ZIP contains the application, scripts, source references and updated tests. The HTML-only ZIP contains just index.html and must be extracted first.

This includes all v254 pricing fixes, v255 descending Dex value order and v256 stamped-only contest promo/label changes. App details show v2.57. Pricing model remains 254: there is no change to price-selection rules.

The v256 deployment failed before publishing because the old v254 test harness did not load the new ownership helper used by v256. The updated test harness and stamp-only ownership tests are included here. Validation: 67 Node tests plus six Python tests, full inline JavaScript/YAML syntax and setup ZIP integrity.

# PokeRoulette v254 — alternative printing prices

Upload PokeRoulette_v254_alternative_printing_prices_setup.zip unchanged to the repository root. Rename the separate PokeRoulette_v254_alternative_printing_prices.html to index.html, replacing the repository root index.html. Replace .github/workflows/daily-prices.yml with IPHONE_WORKFLOW.yml and commit. Keep v253 until the deployment succeeds.

v254 moves the price inside the final stamp label line, immediately after the wording. It extends validated main/Additionals relationships to Perfect Order, Chaos Rising, Phantasmal Flames, Mega Evolution, Ascended Heroes, Journey Together, Prismatic Evolutions, Black Bolt and White Flare as well as Pitch Black. These links require an explicitly declared printing SKU, exact printing attributes, matching card name and a matching nonzero metacard in the verified main expansion. Unrelated expansions remain rejected.

Four provider-omitted printings have exact identity supplements: Armarouge 012, Primarina 020 and Zarude 056 What's Your Favourite stamps, plus Marshadow 040 Cosmos. These are SKU identities, never manually entered prices. Runtime guards check the base and alternative expansion, metacard, card name and complete moves. Zarude Cosmos has a distinct SKU from its stamp. Missing verified printings are merged without replacing conflicting explicit live IDs.

The 30 October source/download audit found 789 additional printing quotes compared with the v253 audit preview (27,681 available printing quotes). This is an automated offline source audit, not the deployed snapshot or a claim that every variant has a price. The production run may differ. The base card preview/Dex price stays separate; Sets sums each selected printing's own available quote. N/A remains where an exact printing has no supported quote.

Validation: 64 Node tests and six Python tests, including real Cosmos, Non Holo and stamp SKUs, separate base prices, unrelated family/metacard/finish rejection, stamp markup, retained quotes, prior identity repairs, collection totals and audit output. Full application JavaScript and YAML syntax and ZIP integrity are checked. Device visual QA was unavailable.

# Previous catalogue audit details

The separate Price_Audit HTML is a report, not the app: do not rename it to index.html.

The generator refreshes two primary references: TCGdex cards-database and PokemonTCG/pokemon-tcg-data English cards. Downloaded source code is parsed as literal data, never executed. The first supplies source card identities and complete move/ability names; the second supplies independently numbered printed names and rarity. Archive hashes and source URLs are retained. If reference refresh fails, bundled references remain available.

Energy notation is normalised contextually: [L] is Lightning, [F] is Fighting and [M] is Metal for Energy names. Nidoran [F]/[M] remain gender markers. Greek letters and Delta Species notation are preserved as identity-bearing words; EX, GX, V and LV.X are not stripped. Documented spelling differences such as Impostor/Imposter Professor Oak and Prof./Professor Oak are equivalent. A printed-name alias including EX or LV.X requires an exact independent set/card-number reference.

Pitch Black expansion 6569 and Additionals 6640 have a constrained, documented relationship. An alternative must be explicitly declared in the source for the same card, have the expected normal finish, match its name, and share the metacard with a verified main-set printing. Arbitrary cross-expansion matches remain blocked. Voltaic Energy now resolves Holo, Reverse and Non Holo independently; Miraidon Non Holo also resolves.

Bilateral signature repair requires exactly one source card and exactly one marketplace product in one expansion with the same printed name and complete attack/ability signature. Source siblings lacking marketplace IDs still count against uniqueness. This avoids merging Pikachu RC29 with number 26 or different art/reprint cards sharing moves. Matching foreign printing families retain their separate identities. Corrections are identity links, never custom prices.

A set-level expansion ID is revised only when at least ten independently numbered cards with exact names and complete move signatures support one replacement, at least 90 percent of qualifying evidence agrees, and no qualifying evidence supports the old expansion. The audit identified Pokemon GO's stale expansion 4786 and replaced it with 5051, supported by 70 of 70 qualifying cards.

Shared normal/Holo root products require exactly two source card numbers, matching independent printed names, matching complete move signatures, opposite independent Holo rarity, and two positive market trend buckets. These use separate price fields. Other ambiguous product collisions remain excluded. Unlimited is recognised as the ordinary base printing ahead of shadowless or first-edition alternatives.

Every successful daily run now writes card-price-coverage.csv, printing-price-coverage.csv, set-price-coverage.csv, price-coverage-summary.json, marketplace-link-repairs.json, set-expansion-repairs.json, and an interactive price-coverage.html report into diagnostics. These are uploaded in price-diagnostics-v253. The report is not part of the phone's app download. Source inventories and independent-name references are also excluded from the published site.

The local audit covers all 21,282 existing physical price records, plus 155 additional app/reference cards. It includes 210 sets with card rows and identifies three further physical catalogue entries with no eligible standalone card records. Digital/Pocket and Jumbo-only inventory are outside the app's scope. An automated match is not an independent visual verification of every marketplace page. Unresolved names, artwork/printing ambiguity, absent product links, unsupported finishes and unavailable quotes remain separately reported.

Audit preview against the 29 October Cardmarket downloads: 19,953 existing cards have a base quote, including 642 explicitly retained earlier quotes; 1,329 remain unpriced/unresolved. There are 1,299 newly priced existing cards and eight previously priced records excluded by the new checks. This is an offline source/download audit, not a deployment or fresh API request for every card. The live run also checks provider responses and may differ. Additional reference-only cards are not assumed present in the app or collected by the user.

The report preserves native currencies and actual quote dates. It does not substitute From/listing prices for Trend. Card previews and Sets totals continue using per-printing quotes from v252; Dex continues using the base price. The daily schedule is 01:17 UTC, with the existing shared-prices-v241 cache prefix retained for recovery. Transient market-download failures preserve already audited v253 quotes without inventing a new source date.

Validation: 61 Node tests and six Python tests. These cover Energy/gender distinctions, Delta/Greek notation, suffix safety, Additionals family/metacard/type guards, actual Energy/Miraidon quotes, independent LV.X aliases, a real unrelated-Team-Aqua SKU repair, duplicate-art safeguards, unlinked siblings, ten-card set consensus, separate normal/Holo buckets, ordinary Unlimited selection, cache/failure handling, report filtering/pagination/CSV export, and reference parsing without execution. Full JavaScript syntax, workflow YAML, report reconciliation and ZIP integrity are checked. Visual browser rendering was unavailable; no device-level visual QA is claimed.
