/**
 * Maintains a small provider-verified catalogue of upcoming/recent expansions.
 * Never generates URLs from guessed identifiers, imports collector-site images,
 * or treats a partial reveal as a complete checklist.
 */
import {readFile, writeFile, mkdir} from 'node:fs/promises';

const OUT = 'data/new-sets-v1.json';
const PROVIDER = 'https://api.tcgdex.net/v2/en/sets';
const EARLY_WINDOW_DAYS = 50;
const FUTURE_WINDOW_DAYS = 125;
const MAX_RECENT_SETS = 12;
// Announced releases can be readable at /sets/{id} before the provider's /sets index refreshes.
// These are confirmed set IDs only; card IDs, image paths and prices are never inferred.
const ANNOUNCED_SET_DETAILS = Object.freeze([
  {id:'me06', name:'Delta Reign', releaseDate:'2026-11-06', serie:{name:'Mega Evolution'}}
]);
const TIMEOUT = 15000;
const allowedImage = url => typeof url === 'string' &&
  /^https:\/\/assets\.tcgdex\.net\//i.test(url);
const cleanText = value => typeof value === 'string' ? value.trim().slice(0,180) : '';
const cleanDate = value => /^\d{4}[-/]\d{2}[-/]\d{2}$/.test(String(value || ''))
  ? String(value).replaceAll('/', '-') : '';
const number = value => Number.isSafeInteger(Number(value)) && Number(value) >= 0 ? Number(value) : 0;

export function normaliseNewSet(set, detail) {
  if (!set || !set.id || !set.name) return null;
  const id = cleanText(set.id).toLowerCase();
  if (!/^[a-z0-9.-]{2,24}$/.test(id)) return null;
  const cards = [];
  const seen = new Set();
  for (const item of Array.isArray(detail?.cards) ? detail.cards : []) {
    const cardId = cleanText(item?.id);
    const name = cleanText(item?.name);
    const localId = cleanText(item?.localId || cardId.split('-').pop());
    const img = cleanText(item?.image);
    if (!cardId.startsWith(id + '-') || !name || !localId || seen.has(cardId)) continue;
    seen.add(cardId);
    // Only include provider-supplied image paths; do not create a guessed scan.
    cards.push({id:cardId, name, number:localId, image:allowedImage(img) ? img : null});
  }
  return {
    id, name:cleanText(set.name), series:cleanText(detail?.serie?.name || set.serie?.name || ''),
    releaseDate:cleanDate(detail?.releaseDate || set.releaseDate),
    total:number(detail?.cardCount?.total || set.cardCount?.total),
    printedTotal:number(detail?.cardCount?.official || set.cardCount?.official),
    logo:allowedImage(detail?.logo || set.logo) ? (detail?.logo || set.logo) : '',
    symbol:allowedImage(detail?.symbol || set.symbol) ? (detail?.symbol || set.symbol) : '',
    cards, source:'tcgdex', checklistComplete:false
  };
}
export function mergeNewSets(existing, incoming) {
  const entries = new Map((existing || []).filter(item => item?.id).map(item => [item.id, item]));
  for (const item of incoming || []) {
    const old = entries.get(item.id);
    if (!old) { entries.set(item.id,item); continue; }
    const cards = new Map((old.cards || []).map(card => [card.id,card]));
    for (const card of item.cards || []) {
      const prior = cards.get(card.id);
      cards.set(card.id, prior && !card.image && prior.image ? {...card, image:prior.image} : card);
    }
    entries.set(item.id, {...old, ...item,
      logo:item.logo || old.logo || '', symbol:item.symbol || old.symbol || '',
      releaseDate:item.releaseDate || old.releaseDate || '',
      cards:[...cards.values()]});
  }
  return [...entries.values()].sort((a,b) => String(b.releaseDate).localeCompare(String(a.releaseDate)));
}
async function fetchJson(url) {
  for(let attempt=0; attempt<3; attempt++) {
    try {
      const response=await fetch(url,{headers:{'Accept':'application/json'},signal:AbortSignal.timeout(TIMEOUT)});
      if(!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
      return await response.json();
    } catch(error) {
      if(attempt===2) throw error;
      await new Promise(resolve=>setTimeout(resolve,700*(attempt+1)));
    }
  }
}
export async function updateNewSets({fetchData=fetchJson, now=new Date(), previous={sets:[]}}={}) {
  const all=await fetchData(PROVIDER);
  if(!Array.isArray(all)) throw new Error('TCGdex catalogue not an array');
  const undatedRecent = new Set(all.filter(set => !cleanDate(set?.releaseDate) && /^(?:me0?[6-9]|me[1-9][0-9]|sv\d{2})/.test(String(set?.id || ''))).slice(-12).map(set => set.id));
  const recent=all.filter(set=>{
    if (!set?.id || !set?.name) return false;
    const date=cleanDate(set.releaseDate);
    if(!date) return set.id === 'me06' || undatedRecent.has(set.id);
    const days=(new Date(date+'T00:00:00Z').getTime()-now.getTime())/86400000;
    return days >= -EARLY_WINDOW_DAYS && days <= FUTURE_WINDOW_DAYS;
  }).sort((a,b)=>String(b.releaseDate||'').localeCompare(String(a.releaseDate||'')));
  const selected=recent.slice(0,MAX_RECENT_SETS);
  // Probe published details directly for confirmed upcoming sets omitted by the list API.
  // Keep the provider as the authority for the individual card checklist and imagery.
  for (const announced of ANNOUNCED_SET_DETAILS) {
    if (selected.some(set => String(set.id).toLowerCase()===announced.id)) continue;
    const days=(new Date(announced.releaseDate+'T00:00:00Z')-now)/86400000;
    if (days >= -EARLY_WINDOW_DAYS && days <= FUTURE_WINDOW_DAYS) selected.push(announced);
  }
  const incoming=[];
  for(const set of selected){
    try {
      const detail=await fetchData(`${PROVIDER}/${encodeURIComponent(set.id)}`);
      // A missing set-detail endpoint must not create a fictitious checklist.
      if (!detail || typeof detail !== 'object' || !detail.id || !detail.name) continue;
      const record=normaliseNewSet({...set,...detail},detail);
      if(record) incoming.push(record);
    } catch(error) {
      console.warn(`[NEW SETS] ${set.id}: ${error.message}; retaining previous data`);
    }
  }
  const sets=mergeNewSets(previous.sets, incoming).filter(set=>{
    const date=cleanDate(set.releaseDate);
    if(!date) return set.id==='me06';
    return (now.getTime()-new Date(date+'T00:00:00Z').getTime())/86400000 < 180;
  }).slice(0,25);
  return {schemaVersion:1,updatedAt:now.toISOString(),sets};
}
if(process.argv[1] && import.meta.url===new URL(`file://${process.argv[1]}`).href){
  let previous={sets:[]};
  try { previous=JSON.parse(await readFile(OUT,'utf8')); } catch{}
  const oldUrlIndex=process.argv.indexOf('--previous-url');
  if(oldUrlIndex!==-1 && process.argv[oldUrlIndex+1]) {
    try {
      const published=await fetchJson(process.argv[oldUrlIndex+1]);
      if(published?.schemaVersion===1 && Array.isArray(published.sets)) {
        previous={sets:mergeNewSets(previous.sets,published.sets)};
      }
    } catch(error) { console.warn(`[NEW SETS] Previous catalogue unavailable: ${error.message}`); }
  }
  try {
    const next=await updateNewSets({previous});
    await mkdir('data',{recursive:true});
    await writeFile(OUT,JSON.stringify(next));
    console.log(`[NEW SETS] ${next.sets.length} sets; ${next.sets.reduce((n,set)=>n+set.cards.length,0)} source-verified cards; ${next.sets.reduce((n,set)=>n+set.cards.filter(card=>card.image).length,0)} source artwork references`);
    for (const set of next.sets.filter(set=>set.id==='me06')) console.log(`[DELTA REIGN] ${set.cards.length}/${set.total||'?'} provider card records, ${set.cards.filter(card=>card.image).length} source images, logo=${Boolean(set.logo)}`);
  } catch(error){
    if(!previous.sets?.length) {
      // Fail open for application publishing. The browser still has live APIs.
      console.warn(`[NEW SETS] Provider unavailable; no published snapshot: ${error.message}`);
      await mkdir('data',{recursive:true});
      await writeFile(OUT,JSON.stringify({schemaVersion:1,updatedAt:null,sets:[]}));
    } else {
      console.warn(`[NEW SETS] Provider unavailable; retaining previous snapshot: ${error.message}`);
      await mkdir('data',{recursive:true});
      await writeFile(OUT,JSON.stringify(previous));
    }
  }
}
