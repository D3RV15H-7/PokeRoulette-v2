import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {indexCardmarket} from '../scripts/cardmarket-source.mjs';
import {resolveIdentities} from '../scripts/resolve-identities.mjs';
import {applyNumberedLinks} from '../scripts/numbered-links.mjs';
import {priceRecord} from '../scripts/update-prices.mjs';
const fixture=JSON.parse(await readFile(new URL('./numbered-sweep-regressions.json',import.meta.url),'utf8'));
const registry=JSON.parse(await readFile(new URL('../data/numbered-marketplace-links-v1.json',import.meta.url),'utf8'));
const now='2026-10-31T15:00:00Z';
function data(mutate){const d=indexCardmarket(fixture.prices,fixture.products,Date.parse(now));d.identities=structuredClone(fixture.identities);const m=structuredClone(fixture.metadata),n=structuredClone(fixture.names);mutate?.(d,m,n);resolveIdentities(d,m,n);return d;}
test('numbered references distinguish Expedition holo 1 from non-holo 33 rather than using one product twice',()=>{
 const d=data(),h=priceRecord(fixture.metadata.cards['ecard1-1'],null,now,d),n=priceRecord(fixture.metadata.cards['ecard1-33'],null,now,d);
 assert.equal(h.quote.productId,274876);assert.equal(h.quote.amount,190.94);assert.equal(h.baseFinish,'holo');
 assert.equal(n.quote.productId,274908);assert.equal(n.quote.amount,15.23);assert.equal(n.baseFinish,'normal');
 assert.equal(h.quote.fieldSuffix,'');assert.equal(n.quote.fieldSuffix,'');assert.ok(h.identityEvidence.url);
});
test('previously absent promo and shiny-vault links use the numbered product and current daily quote',()=>{
 const d=data();for(const [id,sku] of [['bwp-BW01',279925],['sma-SV49',381243],['xyp-XY01',281337],['smp-SM174',369353]]){
  const r=priceRecord(fixture.metadata.cards[id],null,now,d);assert.equal(r.quote.productId,sku,id);assert.equal(r.quote.amount,d.guide.get(sku).trend,id);assert.equal(r.quote.updated,fixture.prices.createdAt);assert.equal(r.identityStatus,'numbered');
 }
});
test('an owner-qualified Trainer name is a numbered alias, not a global name substitution',()=>{
 const d=data(),c=fixture.metadata.cards['me01-114'];assert.equal(priceRecord(c,null,now,d).quote.productId,851185);
 for(const change of [{name:'Professor\'s Research'},{localId:'115'},{set:{id:'different'}}])assert.equal(priceRecord({...c,...change},{quote:{amount:999,productId:851185}},now,d).quote,null);
});
test('changed catalogue name, expansion or source moves invalidate a numbered link and block saved values',()=>{
 for(const change of ['name','expansion','moves']){
  const d=data((d,m)=>{if(change==='moves')m.cards['ecard1-33'].attacks=[{name:'Different attack'}];else d.catalogue.set(274908,{...d.catalogue.get(274908),[change==='name'?'name':'idExpansion']:change==='name'?'Wrong card':999});});
  assert.equal(d.numberedLinks.has('ecard1-33'),false);assert.equal(priceRecord(fixture.metadata.cards['ecard1-33'],{quote:{amount:999,productId:274908}},now,d).quote,null);
 }
});
test('a changed live move list cannot borrow a registered card ID',()=>{
 const d=data(),c=structuredClone(fixture.metadata.cards['ecard1-33']);c.attacks=[{name:'Wrong move'}];assert.equal(priceRecord(c,null,now,d).quote,null);
});
test('two different numbers claiming one numbered product remain blocked',()=>{
 const d=data();assert.equal(d.numberedLinks.has('bw7-67'),false);assert.equal(d.numberedLinks.has('bw7-142'),false);
 for(const id of ['bw7-67','bw7-142'])assert.equal(priceRecord(fixture.metadata.cards[id],{quote:{amount:99}},now,d).quote,null);
});
test('a verified identity with only an asking price never becomes an estimated market value',()=>{
 const d=data();assert.ok(d.guide.get(895613).low>0);assert.equal(priceRecord(fixture.metadata.cards['mep-102'],null,now,d).quote,null);assert.equal(priceRecord(fixture.metadata.cards['mep-120'],null,now,d).quote,null);
});
test('retention requires the same verified product and preserves the original source date',()=>{
 const d=data();d.guide.delete(274908);const c=fixture.metadata.cards['ecard1-33'],quote={amount:14,currency:'EUR',productId:274908,source:'Cardmarket trend',updated:'2026-10-30'};
 const good=priceRecord(c,{quote},now,d);assert.equal(good.retained,true);assert.equal(good.quote.updated,'2026-10-30');
 assert.equal(priceRecord(c,{quote:{...quote,productId:274876}},now,d).quote,null);
});
test('a missing numbered-evidence declaration cannot bypass identity validation',()=>{
 const d=data(),r=structuredClone(registry);r.cards['ecard1-33'].numberedEvidenceVerified=false;applyNumberedLinks(d,fixture.metadata,fixture.names,r);assert.equal(d.numberedLinks.has('ecard1-33'),false);
});
test('unique Trainer names can supply missing links, while a second artwork blocks automatic creation',()=>{
 const source={id:'t-1',name:'Test Supporter',localId:'1',set:{id:'t'},category:'Trainer'},identities={sourceSha256:'x',cards:{'t-2':{name:'Anchor',setId:'t',number:'2',expansionId:77,thirdParty:{cardmarket:88},variants:[]}}};
 function make(duplicate=false){const d=indexCardmarket({version:1,createdAt:now,priceGuides:[{idProduct:90,idCategory:51,trend:3}]},{products:[{idProduct:90,idCategory:51,idExpansion:77,name:'Test Supporter'}]},Date.parse(now));d.identities=structuredClone(identities);const m={sourceSha256:'x',cards:{'t-1':source,...(duplicate?{'t-3':{...source,id:'t-3',localId:'3'}}:{})}};resolveIdentities(d,m,{cards:{'t-1':{name:'Test Supporter'}}});return d;}
 let d=make();assert.equal(priceRecord(source,null,now,d).quote.productId,90);d=make(true);assert.equal(d.identities.cards['t-1'],undefined);
});
test('a unique missing link preserves a reverse-only base finish instead of requiring a nonexistent normal card',()=>{
 const c={id:'t-1',name:'Reverse Mon',localId:'1',set:{id:'t'},category:'Pokemon',attacks:[{name:'Hit'}],variants_detailed:[{type:'reverse',thirdParty:{tcgplayer:45},variantId:'source'}]};
 const d=indexCardmarket({version:1,createdAt:now,priceGuides:[{idProduct:90,idCategory:51,trend:3,'trend-holo':99}]},{products:[{idProduct:90,idCategory:51,idExpansion:77,name:'Reverse Mon [Hit]'}]},Date.parse(now));d.identities={sourceSha256:'x',cards:{'t-2':{name:'Anchor',setId:'t',number:'2',expansionId:77,thirdParty:{cardmarket:88},variants:[]}}};
 resolveIdentities(d,{sourceSha256:'x',cards:{'t-1':c}},{cards:{'t-1':{name:'Reverse Mon'}}});const r=priceRecord(c,null,now,d);
 assert.equal(r.baseFinish,'reverse');assert.equal(r.quote.productId,90);assert.equal(r.quote.amount,3);assert.equal(r.printingQuotes[0].quote.amount,3);
});
