import {readFileSync} from 'node:fs';
import {normalizeMarketplaceName as normal} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
const bundled=JSON.parse(readFileSync(new URL('../data/numbered-marketplace-links-v1.json',import.meta.url),'utf8'));
const moves=c=>[...(c.abilities||[]),...(c.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort();
// These are numbered identity references, never stored price overrides.
// Both the numbered reference and current catalogue identity must still agree.
export function applyNumberedLinks(data,metadata,names,registry=bundled){
 data.numberedLinks=new Map();data.numberedLinkIssues=[];
 const candidates=new Map(),claims=new Map();
 for(const [id,row] of Object.entries(registry.cards||{})){
  const c=metadata?.cards?.[id],p=data.catalogue.get(Number(row.productId));
  const ref=c&&names?.cards?.[c.set.id+'-'+normalNumber(c.localId)];
  const reject=reason=>data.numberedLinkIssues.push({cardId:id,productId:row.productId,reason});
  if(!c||c.set.id!==row.setId||normalNumber(c.localId)!==normalNumber(row.number)||normal(c.name)!==normal(row.sourceName)){reject('source_identity_changed');continue;}
  if(row.independentName&&(!ref||normal(ref.name)!==normal(row.independentName))){reject('independent_identity_changed');continue;}
  if(JSON.stringify(moves(c))!==JSON.stringify(row.sourceMoves)){reject('source_moves_changed');continue;}
  if(!p||p.idExpansion!==row.expansionId||p.name!==row.catalogueName){reject('catalogue_identity_changed');continue;}
  // The reference must explicitly publish both this numbered card and its SKU.
  if(!row.evidenceUrl||!row.evidenceCardId||!row.numberedEvidenceVerified||!['normal','holo','reverse'].includes(row.finish)){reject('incomplete_numbered_evidence');continue;}
  candidates.set(id,row);const key=row.setId+':'+row.productId;
  if(!claims.has(key))claims.set(key,[]);claims.get(key).push(id);
 }
 for(const ids of claims.values()){
  if(new Set(ids.map(id=>normalNumber(candidates.get(id).number))).size>1){for(const id of ids)data.numberedLinkIssues.push({cardId:id,reason:'numbered_references_share_product'});continue;}
  for(const id of ids)data.numberedLinks.set(id,candidates.get(id));
 }
 const expansions=new Map();
 for(const row of data.numberedLinks.values()){
  if(!expansions.has(row.setId))expansions.set(row.setId,new Set());expansions.get(row.setId).add(row.expansionId);
 }
 data.numberedSetExpansions=new Map([...expansions].filter(([,s])=>s.size===1).map(([id,s])=>[id,[...s][0]]));
}
export function numberedProductMatches(card,product,data){
 const row=data?.numberedLinks?.get(card.id);
 return !!row&&card.set?.id===row.setId&&normalNumber(card.localId||card.number)===normalNumber(row.number)&&[row.sourceName,row.independentName].filter(Boolean).some(n=>normal(n)===normal(card.name))&&product?.idProduct===row.productId&&product.idExpansion===row.expansionId&&product.name===row.catalogueName;
}
