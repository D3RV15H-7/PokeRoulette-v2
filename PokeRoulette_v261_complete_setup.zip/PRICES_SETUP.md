# PokeRoulette v261 — numbered identity repairs and missing-price review

Use this release in place of v260. All v260 artwork references, centred loading spinners and preceding collection/UI fixes are included. App Details displays v2.61; the pricing engine is 261.

## Upload from an iPhone

1. Upload **PokeRoulette_v261_complete_setup.zip unchanged** to the repository root. Do not extract this setup ZIP into the repository.
2. Replace root **index.html** with **PokeRoulette_v261.html** (rename the downloaded HTML to index.html).
3. Replace **.github/workflows/daily-prices.yml** with the contents of **PokeRoulette_v261_workflow.yml**. Its filename in GitHub must remain daily-prices.yml.
4. Check the Daily PokeRoulette prices workflow. Keep the current working setup ZIP until the v261 workflow and Pages deployment succeed.

The review HTML, full audit HTML and CSV files are for local review. They do not need to be uploaded to run the app. Opening a report changes nothing in your account or app.

## Audit result — same 31 October price download, v260 baseline

- 21,282 snapshot cards recomputed; 155 additional reference-only rows remain separate.
- 742 of the original 1,223 missing base prices recovered.
- 481 original cases remain unpriced.
- 43 previously priced cards are blocked because the previous shared-product/bucket inference did not establish their exact printing.
- 20,758 base quotes available, 524 cards currently unpriced. These totals include retained quotes with their actual original source dates, not only fresh direct quotes.
- Remaining: 514 identity/link cases, six asking-price-only rows, four rows with empty supported sales-price fields.
- This is an offline source/download audit, not a live deployment or a visual inspection of every marketplace image. Live provider responses can differ.

## Changes

- Bundled numbered identity references: 609 candidate card links, 607 accepted in this audit; two conflicting cross-number claims remain blocked. The records identify products, not custom prices.
- Product/set/collector number/name, independent printed name, complete source moves and current catalogue identity are checked. Current catalogue changes or source identity changes block a reference. Explicit links include evidence URLs.
- Missing identity entries can be created from an exact expansion/name/complete-move signature only when both source card and catalogue product are unique. All source siblings count, including siblings without marketplace IDs. Trainer/Energy links require a unique independent name on both sides.
- Reverse-only cards preserve their sole declared finish when a unique missing product link is supplied.
- Differently numbered cards are no longer assigned separate normal/foil guide fields just because two positive buckets exist. Numbered product evidence is required.
- Newly linked base prices do not automatically price stamped, Cosmos, Reverse or other alternatives. Those printings remain independently checked and are counted only when selected under the existing collection rules.
- A previously verified quote can be retained during a price-data gap only for the same verified product; its original source date is preserved.
- The audit now reports a diagnosis and next action for each remaining card, distinguishes numbered references, and labels retained quotes before other matching categories.

## Evidence and price sources

TCGdex/cards-database and PokemonTCG/pokemon-tcg-data are the published source references. TCGGO public numbered-card pages provide explicit card-ID/product-ID references; the released registry retains their URLs. Runtime prices still come from the supported Cardmarket daily guide and the existing exact-printing provider fallback. No TCGGO price is imported. A website's lowest asking price is never substituted for a market trend or sales average.

No third-party lookup credentials or additional API keys are needed. Numbered links are bundled release data and validated each workflow run; they are not an unreviewed fuzzy search at runtime.

## Verification

83 Node tests and six Python tests pass. Checks cover actual Expedition numbered holo/non-holo products, promo and Shiny Vault links, exact Trainer aliases, duplicate numbered claims, changed source/catalogue identities, asking-price exclusions, same-product retention, unique-link ambiguity, reverse-only base finishes, and preceding pricing/collection/artwork behavior. Inline app JavaScript, report scripts, workflow YAML and the setup ZIP are checked. Device/browser visual testing was unavailable.
