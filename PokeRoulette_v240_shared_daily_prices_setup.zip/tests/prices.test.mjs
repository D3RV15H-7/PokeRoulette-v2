import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {selectQuote,normalNumber,baseFinish} from '../scripts/price-model.mjs';
import {buildSnapshot,priceRecord} from '../scripts/update-prices.mjs';
const card=(id='test-1',pricing={cardmarket:{trend:10,updated:'2026-10-27'}})=>({id,name:'Pikachu',localId:id.split('-').pop(),set:{id:'test',name:'Test'},variants:{normal:true},pricing});
const response=data=>new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
test('Cardmarket trend, then TCGplayer Market, then Cardmarket averages',()=>{
 assert.equal(selectQuote(card()).amount,10);
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9},tcgplayer:{normal:{marketPrice:8}}})).source,'TCGplayer market');
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9}})).source,'Cardmarket 30-day avg');
 assert.equal(selectQuote(card('test-1',{cardmarket:{low:1},tcgplayer:{normal:{lowPrice:1,midPrice:2}}})),null);
 assert.equal(normalNumber('GG003'),'gg3');
});
test('base finish and foil pricing use the same marketplace-product rules',()=>{
 const c=card('test-2',{cardmarket:{trend:5,'trend-holo':20}});c.variants={holo:true};
 assert.equal(baseFinish(c),'holo');assert.equal(selectQuote(c).amount,20);
 c.pricing.cardmarket.idProduct=12;assert.equal(selectQuote(c).amount,5);
});
test('missing pricing preserves the last valid quote and its real date',()=>{
 const old={quote:{amount:8,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-20'},checkedAt:'2026-10-21T00:00:00Z'};
 const record=priceRecord(card('test-1',{}),old,'2026-10-28T00:00:00Z');
 assert.equal(record.quote.amount,8);assert.equal(record.quote.updated,'2026-10-20');assert.equal(record.checkedAt,old.checkedAt);assert.equal(record.retained,true);
});
test('catalogue failures cannot publish an empty replacement',async()=>{
 await assert.rejects(buildSnapshot({fetchImpl:async()=>response([])}),/Invalid or empty/);
});
test('generator refreshes prices, retains failures, and checks N/A without inventing zero',async()=>{
 const previous={schemaVersion:1,sets:{},cards:{'test-2':{name:'Pikachu',number:'2',setId:'test',quote:{amount:4,currency:'EUR',source:'Cardmarket trend'},checkedAt:'2026-10-20T00:00:00Z'}}};
 const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'test',name:'Test'}]);
  if(url.endsWith('/cards'))return response([1,2,3].map(n=>({id:'test-'+n,name:'Pikachu'})));
  if(url.endsWith('/cards/test-1'))return response(card('test-1'));
  if(url.endsWith('/cards/test-3'))return response(card('test-3',{}));
  return new Response('',{status:404});
 };
 const data=await buildSnapshot({previous,fetchImpl,now:'2026-10-28T04:00:00Z'});
 assert.equal(data.cards['test-1'].quote.amount,10);assert.equal(data.cards['test-2'].quote.amount,4);assert.equal(data.cards['test-2'].retained,true);assert.equal(data.cards['test-3'].quote,null);assert.equal(data.summary.failed,1);assert.equal(data.status,'partial');
});
async function client(){
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const source=html.slice(html.indexOf('// v238: values'),html.indexOf('\nfunction calculateProfileStats(sets)'));
 const storage=new Map();let requests=0;
 const c={Map,Set,Intl,Date,Promise,URL,console,setTimeout,clearTimeout,USD_TO_GBP:.8,EUR_TO_GBP:.85,TCG_PRICING_VERSION:225,
  activeUid:'a',profileStatsRequestId:1,memCardCol:new Set(),memSetCardCol:new Set(),memSetCardVariants:new Set(),memoryTcgCache:new Map(),currentCardsList:[],
  window:{addEventListener(){}},document:{baseURI:'https://example.test/app/index.html',addEventListener(){},getElementById(){return null;}},
  localStorage:{get length(){return storage.size},key:i=>[...storage.keys()][i],getItem:key=>storage.get(key)||null,setItem:(k,v)=>storage.set(k,v)},
  AUDITED_ARTWORK_SET_ALIASES:{old:'test'},
  getCardFingerprint:card=>'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase(),
  getCardOwnershipKeys:card=>[card.id,'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase()],
  getNumericPrice:v=>Number.isFinite(parseFloat(v))&&parseFloat(v)>0?parseFloat(v):null,
  normalizePokemonCardName:s=>s.toLowerCase(),convertTcgQuote:q=>q.amount*(q.currency==='EUR'?.85:.8),
  calculateProfileStats:()=>({ownedCardKeys:new Set([...c.memSetCardCol,...[...c.memSetCardVariants].map(k=>k.slice(0,k.lastIndexOf('__')))])}),
  paintVisibleCardDetails(){},fetchJsonWithRetry:async url=>{assert.equal(url,'https://example.test/app/data/prices-v1.json');requests++;return c.fixture;}
 };
 c.isCardCollected=card=>c.getCardOwnershipKeys(card).some(k=>c.memCardCol.has(k));c.isSetCardCollected=card=>c.calculateProfileStats().ownedCardKeys.has(c.getCardFingerprint(card));
 vm.createContext(c);vm.runInContext(source,c);
 c.fixture={schemaVersion:1,generatedAt:'2026-10-28T04:00:00Z',status:'ready',sets:{test:{name:'Test',aliases:['test','old'],names:['Test']}},cards:{'test-001':{name:'Pikachu',number:'001',setId:'test',quote:{amount:10,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-27'},checkedAt:'2026-10-28T04:00:00Z'}}};
 return {c,requests:()=>requests};
}
test('one shared request prices unseen cards in separate Dex and Sets totals',async()=>{
 const {c,requests}=await client();c.memCardCol.add('old-1');c.memCardCol.add('fp_test_1');c.memSetCardVariants.add('fp_test_001__standard');c.memSetCardVariants.add('fp_test_001__reverseHolo');
 await Promise.all([c.runCollectionValueRefresh(),c.runCollectionValueRefresh()]);
 assert.equal(requests(),1);const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(c.fixture,stats),values=c.calculateProfileValues(cards,stats);
 assert.equal(cards.length,1);assert.equal(values.dex.pence,850);assert.equal(values.sets.pence,850);assert.equal(values.dex.missing.size,0);assert.equal(values.sets.missing.size,0);
 c.activeUid='b';c.memCardCol.clear();c.memSetCardVariants.clear();const empty=c.calculateProfileValues(c.sharedProfileValueCards(c.fixture,c.calculateProfileStats()),c.calculateProfileStats());assert.equal(empty.dex.pence,0);assert.equal(empty.sets.pence,0);
});
test('ambiguous aliases and wrong printing names are rejected',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Different Pikachu',setName:'Test',number:'1',priceGBP:'2'};
 assert.equal(c.sharedPriceRecordForCard(local,c.fixture),null);
 c.memCardCol.add('old-1');c.currentCardsList=[local];const cards=c.sharedProfileValueCards(c.fixture,c.calculateProfileStats());assert.equal(cards.length,1);assert.equal(cards[0].name,'Different Pikachu');assert.equal(cards[0].priceGBP,'2');
 const duplicate=structuredClone(c.fixture);duplicate.cards['test-1']={...duplicate.cards['test-001'],name:'Other'};
 assert.equal(c.sharedPriceLookup(duplicate).get('fp_test_1'),null);
});
test('bootstrap or broken shared file does not erase local estimates',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Pikachu',setName:'Test',number:'1',priceGBP:'2',_priceQuote:{amount:2,currency:'EUR',updated:'2026-10-27'}};
 const patch=c.sharedPricePatch(local,{quote:null,checkedAt:'2026-10-28T04:00:00Z'},'test-001');assert.equal(patch._priceQuote.amount,2);assert.equal(patch._sharedPriceRetained,true);
 assert.equal(c.validSharedPriceDocument({schemaVersion:1,cards:{},sets:{},generatedAt:null}),false);
});
test('a broken or older deployed price file cannot overwrite the last good snapshot',async()=>{
 const {c}=await client();const good=await c.loadSharedPrices();assert.equal(good.generatedAt,c.fixture.generatedAt);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({schemaVersion:1,cards:{},sets:{},generatedAt:null});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);assert.equal(c.sharedPriceFetchError,true);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({...c.fixture,generatedAt:'2026-10-20T00:00:00Z'});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);
});
