import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {selectQuote,baseFinish,clean,normalNumber} from './price-model.mjs';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const day=timestamp=>new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London'}).format(new Date(timestamp));
export async function readJson(path,fallback=null){try{return JSON.parse(await readFile(path,'utf8'));}catch{return fallback;}}
export async function atomicJson(path,data){await mkdir(dirname(path),{recursive:true});const temp=path+'.tmp';await writeFile(temp,JSON.stringify(data));await rename(temp,path);}
export function validSnapshot(s){return s?.schemaVersion===1&&s.cards&&typeof s.cards==='object'&&!Array.isArray(s.cards)&&s.sets&&typeof s.sets==='object';}
export async function fetchJson(url,{fetchImpl=fetch,retries=2,timeoutMs=15000}={}){
 let last;
 for(let attempt=0;attempt<=retries;attempt++){
  try{
   const response=await fetchImpl(url,{signal:AbortSignal.timeout(timeoutMs),headers:{Accept:'application/json','User-Agent':'PokeRoulette-daily-price-snapshot/1'}});
   if(!response.ok){const error=new Error('HTTP '+response.status);error.status=response.status;error.retryAfter=Math.min(60,Number(response.headers.get('retry-after'))||0);throw error;}
   return await response.json();
  }catch(error){last=error;if(attempt===retries||error.status===404)throw error;await sleep((error.retryAfter||attempt+1)*1000);}
 }
 throw last;
}
function setMetadata(sets,manifest){
 const result={};
 for(const set of sets){
  const aliases=Object.entries(manifest.setAliases||{}).filter(([,canonical])=>canonical===set.id).map(([id])=>id);
  const bundled=(manifest.sets||[]).filter(s=>s.id===set.id||aliases.includes(s.id)||clean(s.name)===clean(set.name));
  result[set.id]={name:set.name,aliases:[...new Set([set.id,...aliases,...bundled.map(s=>s.id)])],names:[...new Set([set.name,...bundled.map(s=>s.name)])]};
 }
 return result;
}
export function priceRecord(card,previous,now){
 const finish=baseFinish(card),quote=selectQuote(card,finish);
 const record={name:card.name,setId:card.set.id,number:String(card.localId||card.number||String(card.id).split('-').pop()),baseFinish:finish,quote,
  checkedAt:now,lastAttemptAt:now,retained:false};
 // A missing field is not proof a previously priced printing has no value.
 // Preserve its real quote and source date, but report the retention explicitly.
 if(!quote&&previous?.quote){record.quote=previous.quote;record.checkedAt=previous.checkedAt;record.retained=true;record.noFreshQuote=true;}
 return record;
}
export async function buildSnapshot({previous=null,manifest={},fetchImpl=fetch,baseUrl='https://api.tcgdex.net/v2/en',workers=4,maxMinutes=240,now=new Date().toISOString(),checkpoint=async()=>{}}={}){
 const start=Date.now(),deadline=start+maxMinutes*60000;
 const get=url=>fetchJson(url,{fetchImpl});
 const [sets,catalogue]=await Promise.all([get(baseUrl+'/sets'),get(baseUrl+'/cards')]);
 if(!Array.isArray(sets)||!sets.length||!Array.isArray(catalogue)||!catalogue.length)throw new Error('Invalid or empty provider catalogue; previous snapshot is untouched.');
 const briefs=catalogue.filter(c=>c?.id&&c.name&&!/^(?:[ab]\d|p-[ab]-)/i.test(c.id));
 const cards=validSnapshot(previous)?{...previous.cards}:{};
 const snapshot={schemaVersion:1,generatedAt:now,status:'building',provider:'TCGdex',sets:setMetadata(sets,manifest),cards,fx:previous?.fx||null,
  summary:{catalogueCards:briefs.length,requested:0,succeeded:0,failed:0,reused:0,priced:0,unpriced:0,retained:0,pending:0}};
 const summary=snapshot.summary;
 // Restore metadata when a set disappeared temporarily from a catalogue feed.
 for(const [id,set] of Object.entries(previous?.sets||{}))if(!snapshot.sets[id])snapshot.sets[id]=set;
 const pending=briefs.filter(brief=>{const old=cards[brief.id];if(old?.lastAttemptAt&&!old.error&&day(old.lastAttemptAt)===day(now)){summary.reused++;return false;}return true;});
 // First fetch new cards; an interrupted initial build can resume next run.
 pending.sort((a,b)=>Number(!!cards[a.id])-Number(!!cards[b.id])||String(cards[a.id]?.checkedAt||'').localeCompare(String(cards[b.id]?.checkedAt||'')));
 let next=0,completedSinceCheckpoint=0;
 async function worker(){
  while(next<pending.length&&Date.now()<deadline){
   const brief=pending[next++];summary.requested++;
   try{
    const card=await get(baseUrl+'/cards/'+encodeURIComponent(brief.id));
    if(card?.id!==brief.id||!card.set?.id||!card.name)throw new Error('Card identity mismatch');
    const previousRecord=cards[brief.id];
    if(previousRecord&&(previousRecord.setId!==card.set.id||clean(previousRecord.name)!==clean(card.name)||normalNumber(previousRecord.number)!==normalNumber(card.localId||card.number||card.id.split('-').pop())))throw new Error('Changed printing identity requires review');
    cards[brief.id]=priceRecord(card,previousRecord,now);
    // Separate stamped sets only match their own exact set and card identity.
    // Never price a promotional stamp from its unstamped parent printing.
    const record=cards[brief.id];
    for(const set of manifest.supplemental||[]){
      if(set.id!==card.set.id&&clean(set.name)!==clean(card.set.name))continue;
      const entry=set.cards.find(c=>normalNumber(c.number)===normalNumber(record.number)&&clean(c.name)===clean(card.name));
      if(entry)record.ownershipAliases=[entry.id,...(set.id==='ex5.5'?[]:['fp_standalone_'+entry.id])];
    }
    summary.succeeded++;
    if(!snapshot.sets[card.set.id])snapshot.sets[card.set.id]={name:card.set.name||card.set.id,aliases:[card.set.id],names:[card.set.name||card.set.id]};
   }catch(error){
    summary.failed++;
    if(cards[brief.id])cards[brief.id]={...cards[brief.id],lastAttemptAt:now,retained:!!cards[brief.id].quote,error:String(error.message).slice(0,160)};
    // No invented record for a failed first-time request.
   }
   completedSinceCheckpoint++;
   if(completedSinceCheckpoint>=500){completedSinceCheckpoint=0;await checkpoint(snapshot);}
   await sleep(150);
  }
 }
 await Promise.all(Array.from({length:Math.min(workers,pending.length)},worker));
 summary.pending=pending.length-summary.requested;
 for(const record of Object.values(cards)){if(record.quote)summary.priced++;else summary.unpriced++;if(record.retained)summary.retained++;}
 if(!Object.keys(cards).length||(!summary.succeeded&&!summary.reused))throw new Error('No successful price checks; previous published snapshot is untouched.');
 snapshot.status=summary.failed||summary.pending?'partial':'ready';
 try{
  const rows=await fetchJson('https://api.frankfurter.dev/v2/rates?base=GBP&quotes=USD,EUR',{fetchImpl,retries:0,timeoutMs:7000});
  const usd=rows.find(r=>r.quote==='USD'&&Number(r.rate)>0),eur=rows.find(r=>r.quote==='EUR'&&Number(r.rate)>0);
  if(usd&&eur)snapshot.fx={usd:1/Number(usd.rate),eur:1/Number(eur.rate),date:usd.date};
 }catch{/* Keep the previous rates and their real date. */}
 return snapshot;
}
export async function main(){
 const args=process.argv.slice(2);const option=(key,fallback)=>{const index=args.indexOf(key);return index<0?fallback:args[index+1];};
 const output=resolve(option('--output','data/prices-v1.json')),checkpointPath=resolve('.price-state/checkpoint.json');
 const manifest=await readJson(resolve('data/price-mapping.json'),{});
 let previous=await readJson(output);const checkpoint=await readJson(checkpointPath);
 if(validSnapshot(checkpoint)&&(Date.parse(checkpoint.generatedAt)>Date.parse(previous?.generatedAt||0)||Object.keys(checkpoint.cards).length>Object.keys(previous?.cards||{}).length))previous=checkpoint;
 const previousUrl=option('--previous-url','');
 if(previousUrl&&(!validSnapshot(previous)||!Object.keys(previous.cards).length)){
  try{const served=await fetchJson(previousUrl,{retries:0,timeoutMs:15000});if(validSnapshot(served))previous=served;}catch{}
 }
 const snapshot=await buildSnapshot({previous,manifest,workers:4,maxMinutes:240,checkpoint:async s=>atomicJson(checkpointPath,s)});
 await atomicJson(output,snapshot);await atomicJson(checkpointPath,snapshot);
 console.log(JSON.stringify({status:snapshot.status,...snapshot.summary}));
 if(process.env.GITHUB_STEP_SUMMARY)await writeFile(process.env.GITHUB_STEP_SUMMARY,'## Daily card prices\n\n'+Object.entries(snapshot.summary).map(([k,v])=>'- '+k+': '+v).join('\n')+'\n',{flag:'a'});
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main().catch(error=>{console.error(error.message);process.exitCode=1;});
