import {baseFinish,positive,normalNumber} from './price-model.mjs';
export const CARDMARKET_URLS={prices:'https://downloads.s3.cardmarket.com/productCatalog/priceGuide/price_guide_6.json',products:'https://downloads.s3.cardmarket.com/productCatalog/productList/products_singles_6.json'};
const normal=s=>String(s||'').replace(/\[F\]/g,' female ').replace(/\[M\]/g,' male ').replace(/\s+Lv\.?\s*\d+\b/gi,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/♀/g,'female').replace(/♂/g,'male').toLowerCase().replace(/[^a-z0-9]/g,'');
const productName=p=>normal(p.name.replace(/\s*\[[^\]]+\]\s*$/,''));
const signature=(name,attacks)=>normal(name)+'|'+attacks.map(normal).sort().join('|');
export function indexCardmarket(prices,products,now=Date.now()){
 if(prices?.version!==1||!Array.isArray(prices.priceGuides)||!Array.isArray(products?.products)||!Number.isFinite(Date.parse(prices.createdAt))||Date.parse(prices.createdAt)>now+86400000||now-Date.parse(prices.createdAt)>7*86400000)throw new Error('Invalid or stale Cardmarket download');
 const catalogue=new Map(products.products.filter(p=>p.idCategory===51&&Number.isInteger(p.idProduct)&&p.name).map(p=>[p.idProduct,p]));
 const guide=new Map(prices.priceGuides.filter(p=>p.idCategory===51&&Number.isInteger(p.idProduct)).map(p=>[p.idProduct,p]));
 if(!catalogue.size||!guide.size)throw new Error('Empty Cardmarket download');
 // Verified product identities, not custom prices. Validate the release before
 // matching names and complete attack signatures within that release only.
 const anchors=[[907607,'Exeggcute'],[907608,'Alolan Exeggutor'],[907609,'Volbeat']];
 const releaseValid=anchors.every(([id,name])=>catalogue.get(id)?.idExpansion===6601&&productName(catalogue.get(id))===normal(name));
 const release=new Map();
 if(releaseValid)for(const p of catalogue.values()){
  if(p.idExpansion!==6601)continue;
  const match=/^(.+?)\s*\[([^\]]+)\]\s*$/.exec(p.name);if(!match)continue;
  const key=signature(match[1],match[2].split('|').map(s=>s.trim()));
  release.set(key,release.has(key)?null:p.idProduct);
 }
 return {catalogue,guide,release,releaseValid,updated:prices.createdAt};
}
export function hydrateCardmarketIdentity(card,data){
 const entry=data?.identities?.cards?.[card.id];
 if(!entry)return card;
 if(entry.setId!==card.set?.id||normal(entry.name)!==normal(card.name)||normalNumber(entry.number)!==normalNumber(card.localId||card.number||''))return {...card,_identityMapRejected:true};
 const validProduct=id=>{const p=data.catalogue.get(Number(id));return p&&p.idExpansion===entry.expansionId&&productName(p)===normal(entry.name);};
 const variants=(entry.variants||[]).filter(v=>['normal','holo','reverse'].includes(v.type)&&(!v.size||v.size==='standard')&&!v.staff&&!v.stamp?.some(s=>/staff/i.test(String(s)))&&(!v.languages?.length||v.languages.includes('en'))&&validProduct(v.thirdParty?.cardmarket));
 const existing=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v.variantId!=='generated'&&v.thirdParty?.cardmarket);
 // Valid existing detailed identities remain authoritative. Only fill the
 // omitted/generated detail layer, after checking exact set, number and SKU.
 if(existing.length)return card;
 if(variants.length){
  return {...card,variants:{...card.variants,normal:variants.some(v=>v.type==='normal'),holo:variants.some(v=>v.type==='holo'),reverse:variants.some(v=>v.type==='reverse')},variants_detailed:variants.map((v,i)=>({...v,variantId:'published-source-'+i})),_identitySourceApplied:true};
 }
 if(entry.thirdParty?.cardmarket&&validProduct(entry.thirdParty.cardmarket)&&!card.pricing?.cardmarket?.idProduct&&!card.thirdParty?.cardmarket)return {...card,thirdParty:{...card.thirdParty,...entry.thirdParty},_identitySourceApplied:true};
 return {...card,_identityMapRejected:true};
}
export function directCardmarketQuote(card,data){
 if(!data||card._identityMapRejected)return null;
 const finish=baseFinish(card);
 const details=(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v.variantId!=='generated'&&v.type===finish&&(!v.size||v.size==='standard')&&(!v.languages?.length||v.languages.some(l=>/^en(?:-|$)/i.test(l)))&&!v.staff);
 const plain=details.filter(v=>!v.subtype&&!v.stamp?.length);
 const selected=plain.length?plain:details;
 const ids=[...new Set(selected.map(v=>Number(v.thirdParty?.cardmarket)).filter(Boolean))];
 let id=ids.length===1?ids[0]:null,suffix='';
 if(ids.length>1)return null;
 if(!id&&finish!=='reverse'){
  id=Number(card.pricing?.cardmarket?.idProduct||card.thirdParty?.cardmarket)||null;
  if(id&&finish==='holo'&&card.variants?.normal)suffix='-holo';
 }
 if(!id&&card.set?.id==='30th'&&normal(card.set.name)==='30thcelebration'&&finish==='normal'){
  const moves=[...(card.abilities||[]),...(card.attacks||[])].map(a=>a.name);
  const anchor={'001':[907607,'Exeggcute'],'002':[907608,'Alolan Exeggutor'],'003':[907609,'Volbeat']}[String(card.localId||card.number||'').padStart(3,'0')];
  const known=anchor&&data.releaseValid&&normal(anchor[1])===normal(card.name)?data.catalogue.get(anchor[0]):null;
  const parsed=known&&/^(.+?)\s*\[([^\]]+)\]\s*$/.exec(known.name);
  id=parsed&&signature(parsed[1],parsed[2].split('|').map(s=>s.trim()))===signature(card.name,moves)?anchor[0]:card._cardmarketNameUnique===true?data.release.get(signature(card.name,moves))||null:null;
 }
 const product=data.catalogue.get(id),row=data.guide.get(id);
 if(!product||!row||productName(product)!==normal(card.name))return null;
 const candidates=[['trend',0,'Cardmarket trend'],['avg30',2,'Cardmarket 30-day avg'],['avg7',3,'Cardmarket 7-day avg'],['avg',4,'Cardmarket average'],['avg1',5,'Cardmarket 1-day avg']];
 for(const [field,priority,source] of candidates){const amount=positive(row[field+suffix]);if(amount!==null)return {amount,currency:'EUR',source,updated:data.updated,priority,via:'Cardmarket daily extract',productId:id,fieldSuffix:suffix};}
 return null;
}
export function preferDirectQuote(existing,direct){
 if(!direct)return existing;
 if(existing&&existing.priority<direct.priority)return existing;
 // A download from an earlier source day must not replace a newer same-source quote.
 if(existing&&existing.priority===direct.priority&&String(existing.updated||'').slice(0,10)>String(direct.updated||'').slice(0,10))return existing;
 return direct;
}
