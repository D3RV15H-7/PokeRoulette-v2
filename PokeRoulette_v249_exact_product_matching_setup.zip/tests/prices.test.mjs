import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {selectQuote,normalNumber,baseFinish} from '../scripts/price-model.mjs';
import {buildSnapshot,priceRecord} from '../scripts/update-prices.mjs';
const card=(id='test-1',pricing={cardmarket:{trend:10,updated:'2026-10-27'}})=>({id,name:'Pikachu',localId:id.split('-').pop(),set:{id:'test',name:'Test'},variants:{normal:true},pricing});
const response=data=>new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});
test('Cardmarket trend, then TCGplayer Market, then Cardmarket averages',()=>{
 assert.equal(selectQuote(card()).amount,10);
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9},tcgplayer:{normal:{marketPrice:8}}})).source,'TCGplayer market');
 assert.equal(selectQuote(card('test-1',{cardmarket:{avg30:9}})).source,'Cardmarket 30-day avg');
 assert.equal(selectQuote(card('test-1',{cardmarket:{low:1},tcgplayer:{normal:{lowPrice:1,midPrice:2}}})),null);
 assert.equal(normalNumber('GG003'),'gg3');
});
test('base finish and foil pricing use the same marketplace-product rules',()=>{
 const c=card('test-2',{cardmarket:{trend:5,'trend-holo':20}});c.variants={holo:true};
 assert.equal(baseFinish(c),'holo');assert.equal(selectQuote(c).amount,20);
 c.pricing.cardmarket.idProduct=12;assert.equal(selectQuote(c).amount,5);
});
test('missing pricing preserves the last valid quote and its real date',()=>{
 const old={quote:{amount:8,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-20'},checkedAt:'2026-10-21T00:00:00Z'};
 const record=priceRecord(card('test-1',{}),old,'2026-10-28T00:00:00Z');
 assert.equal(record.quote.amount,8);assert.equal(record.quote.updated,'2026-10-20');assert.equal(record.checkedAt,old.checkedAt);assert.equal(record.retained,true);
});
test('catalogue failures cannot publish an empty replacement',async()=>{
 await assert.rejects(buildSnapshot({fetchImpl:async()=>response([])}),/Invalid or empty/);
});
test('generator refreshes prices, retains failures, and checks N/A without inventing zero',async()=>{
 const previous={schemaVersion:1,sets:{},cards:{'test-2':{name:'Pikachu',number:'2',setId:'test',quote:{amount:4,currency:'EUR',source:'Cardmarket trend'},checkedAt:'2026-10-20T00:00:00Z'}}};
 const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'test',name:'Test'}]);
  if(url.endsWith('/cards'))return response([1,2,3].map(n=>({id:'test-'+n,name:'Pikachu'})));
  if(url.endsWith('/cards/test-1'))return response(card('test-1'));
  if(url.endsWith('/cards/test-3'))return response(card('test-3',{}));
  return new Response('',{status:404});
 };
 const data=await buildSnapshot({previous,fetchImpl,now:'2026-10-28T04:00:00Z'});
 assert.equal(data.cards['test-1'].quote.amount,10);assert.equal(data.cards['test-2'].quote.amount,4);assert.equal(data.cards['test-2'].retained,true);assert.equal(data.cards['test-3'].quote,null);assert.equal(data.summary.failed,1);assert.equal(data.status,'partial');
 assert.equal(data.diagnostics.failedRequests[0].cardId,'test-2');assert.equal(data.diagnostics.failedRequests[0].httpStatus,404);assert.equal(data.diagnostics.failedRequests[0].attempts,1);assert.match(data.diagnostics.failedRequests[0].message,/HTTP 404/);assert.equal(data.diagnostics.unpriced[0].cardId,'test-3');
});
async function client(){
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const source=html.slice(html.indexOf('// v238: values'),html.indexOf('\nfunction calculateProfileStats(sets)'));
 const storage=new Map();let requests=0;
 const c={Map,Set,Intl,Date,Promise,URL,console,setTimeout,clearTimeout,USD_TO_GBP:.8,EUR_TO_GBP:.85,TCG_PRICING_VERSION:225,
  activeUid:'a',profileStatsRequestId:1,memCardCol:new Set(),memSetCardCol:new Set(),memSetCardVariants:new Set(),memoryTcgCache:new Map(),currentCardsList:[],
  window:{addEventListener(){}},document:{baseURI:'https://example.test/app/index.html',addEventListener(){},getElementById(){return null;}},
  localStorage:{get length(){return storage.size},key:i=>[...storage.keys()][i],getItem:key=>storage.get(key)||null,setItem:(k,v)=>storage.set(k,v)},
  AUDITED_ARTWORK_SET_ALIASES:{old:'test'},
  promoOwnershipSetNames:()=>({svp:['SV Promos','SVP Black Star Promos']}),
  getCardFingerprint:card=>'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase(),
  getCardOwnershipKeys:card=>[card.id,'fp_'+card.setName.toLowerCase().replace(/[^a-z0-9]/g,'')+'_'+String(card.number).toLowerCase()],
  getNumericPrice:v=>Number.isFinite(parseFloat(v))&&parseFloat(v)>0?parseFloat(v):null,
  normalizePokemonCardName:s=>s.toLowerCase(),convertTcgQuote:q=>q.amount*(q.currency==='EUR'?.85:.8),
  calculateProfileStats:()=>({ownedCardKeys:new Set([...c.memSetCardCol,...[...c.memSetCardVariants].map(k=>k.slice(0,k.lastIndexOf('__')))])}),
  paintVisibleCardDetails(){},fetchJsonWithRetry:async url=>{assert.equal(url,'https://example.test/app/data/prices-v1.json');requests++;return c.fixture;}
 };
 c.isCardCollected=card=>c.getCardOwnershipKeys(card).some(k=>c.memCardCol.has(k));c.isSetCardCollected=card=>c.calculateProfileStats().ownedCardKeys.has(c.getCardFingerprint(card));
 vm.createContext(c);vm.runInContext(source,c);
 c.fixture={schemaVersion:1,generatedAt:'2026-10-28T04:00:00Z',status:'ready',sets:{test:{name:'Test',aliases:['test','old'],names:['Test']}},cards:{'test-001':{name:'Pikachu',number:'001',setId:'test',quote:{amount:10,currency:'EUR',source:'Cardmarket trend',updated:'2026-10-27'},checkedAt:'2026-10-28T04:00:00Z'}}};
 return {c,requests:()=>requests};
}
test('one shared request prices unseen cards in separate Dex and Sets totals',async()=>{
 const {c,requests}=await client();c.memCardCol.add('old-1');c.memCardCol.add('fp_test_1');c.memSetCardVariants.add('fp_test_001__standard');c.memSetCardVariants.add('fp_test_001__reverseHolo');
 await Promise.all([c.runCollectionValueRefresh(),c.runCollectionValueRefresh()]);
 assert.equal(requests(),1);const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(c.fixture,stats),values=c.calculateProfileValues(cards,stats);
 assert.equal(cards.length,1);assert.equal(values.dex.pence,850);assert.equal(values.sets.pence,850);assert.equal(values.dex.missing.size,0);assert.equal(values.sets.missing.size,0);
 c.activeUid='b';c.memCardCol.clear();c.memSetCardVariants.clear();const empty=c.calculateProfileValues(c.sharedProfileValueCards(c.fixture,c.calculateProfileStats()),c.calculateProfileStats());assert.equal(empty.dex.pence,0);assert.equal(empty.sets.pence,0);
});
test('ambiguous aliases and wrong printing names are rejected',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Different Pikachu',setName:'Test',number:'1',priceGBP:'2'};
 assert.equal(c.sharedPriceRecordForCard(local,c.fixture),null);
 c.memCardCol.add('old-1');c.currentCardsList=[local];const cards=c.sharedProfileValueCards(c.fixture,c.calculateProfileStats());assert.equal(cards.length,1);assert.equal(cards[0].name,'Different Pikachu');assert.equal(cards[0].priceGBP,'2');
 const duplicate=structuredClone(c.fixture);duplicate.cards['test-1']={...duplicate.cards['test-001'],name:'Other'};
 assert.equal(c.sharedPriceLookup(duplicate).get('fp_test_1'),null);
});
test('bootstrap or broken shared file does not erase local estimates',async()=>{
 const {c}=await client();const local={id:'old-1',name:'Pikachu',setName:'Test',number:'1',priceGBP:'2',_priceQuote:{amount:2,currency:'EUR',updated:'2026-10-27'}};
 const patch=c.sharedPricePatch(local,{quote:null,checkedAt:'2026-10-28T04:00:00Z'},'test-001');assert.equal(patch._priceQuote.amount,2);assert.equal(patch._sharedPriceRetained,true);
 assert.equal(c.validSharedPriceDocument({schemaVersion:1,cards:{},sets:{},generatedAt:null}),false);
});
test('a broken or older deployed price file cannot overwrite the last good snapshot',async()=>{
 const {c}=await client();const good=await c.loadSharedPrices();assert.equal(good.generatedAt,c.fixture.generatedAt);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({schemaVersion:1,cards:{},sets:{},generatedAt:null});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);assert.equal(c.sharedPriceFetchError,true);
 c.sharedPriceFetchedAt=0;c.sharedPriceAttemptAt=0;c.fetchJsonWithRetry=async()=>({...c.fixture,generatedAt:'2026-10-20T00:00:00Z'});
 assert.equal((await c.loadSharedPrices()).generatedAt,good.generatedAt);
});

const regressions=JSON.parse(await readFile(new URL('./finish-regressions.json',import.meta.url),'utf8'));
test('all eight audited finish regressions recover their exact marketplace quote',()=>{
 assert.equal(Object.keys(regressions).length,8);
 for(const [id,card] of Object.entries(regressions)){
  const quote=selectQuote(card);assert.ok(quote,id+' must be priced');assert.equal(quote.source,'TCGplayer market');
  const source=Object.values(card.pricing.tcgplayer).find(v=>v&&typeof v==='object'&&v.marketPrice===quote.amount);
  assert.ok(source,id+' must use a market quote from the same source card');
 }
});
test('no normal-to-reverse price substitution when both printings exist',()=>{
 const c=structuredClone(regressions['np-3']);c.variants.normal=true;c.variants_detailed.push({type:'normal',variantId:'actual-normal',pricing:null});
 assert.equal(baseFinish(c),'normal');assert.equal(selectQuote(c),null);
});
test('a mismatched nested product is not borrowed for the selected base finish',()=>{
 const c=structuredClone(regressions['np-35']);const normal=c.variants_detailed.find(v=>v.type==='normal');normal.thirdParty.tcgplayer='different-product';
 assert.equal(selectQuote(c),null);
});
test('an ordinary holo is preferred over a stamped championship normal reprint',()=>{
 assert.equal(baseFinish(regressions['ex16-101']),'holo');assert.equal(baseFinish(regressions['ex8-105']),'holo');
});
test('model upgrade rechecks cached N/A while reusing same-day valid quotes',async()=>{
 const now='2026-10-28T04:00:00Z',previous={schemaVersion:1,sets:{},cards:{
  'test-1':{name:'Pikachu',number:'1',setId:'test',quote:null,checkedAt:now,lastAttemptAt:now},
  'test-2':{name:'Pikachu',number:'2',setId:'test',quote:{amount:5,currency:'EUR'},checkedAt:now,lastAttemptAt:now}
 }};
 const calls=[];const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'test',name:'Test'}]);
  if(url.endsWith('/cards'))return response([1,2].map(n=>({id:'test-'+n,name:'Pikachu'})));
  if(url.includes('/cards/')){calls.push(url);return response(card(url.split('/').pop()));}
  return new Response('',{status:404});
 };
 const data=await buildSnapshot({previous,fetchImpl,now});assert.equal(calls.length,1);assert.match(calls[0],/test-1$/);assert.equal(data.cards['test-1'].quote.amount,10);assert.equal(data.summary.reused,1);
});

test('physical-card coverage includes unmatched cards and deduplicates saved aliases',async()=>{
 const {c}=await client();
 c.memCardCol=new Set(['old-1','fp_test_1','not-in-feed']);
 const a={id:'old-1',name:'Pikachu',setName:'Test',number:'1',priceGBP:'2',_priceCheckedAt:1};
 const b={...a,id:'test-001',_valueOwnershipKeys:['old-1','fp_test_1'],priceGBP:'3',_priceCheckedAt:2};
 const value=c.calculateProfileValues([a,b],{ownedCardKeys:new Set()}).dex;
 assert.equal(value.total,2);assert.equal(value.priced,1);assert.equal(value.unpriced,1);assert.equal(value.pence,300);
 assert.equal(value.unpricedCards[0].reason,'unmatched_card');
});
test('twenty individual cards remain twenty regardless of the unique-Pokemon counter',async()=>{
 const {c}=await client();c.memCol=new Set(Array.from({length:19},(_,i)=>i+1));
 const cards=Array.from({length:20},(_,i)=>({id:'t-'+i,name:'Pikachu',setName:'Test',number:String(i),priceGBP:'1'}));
 c.memCardCol=new Set(cards.map(card=>card.id));const total=c.calculateProfileValues(cards,{ownedCardKeys:new Set()}).dex;
 assert.equal(total.total,20);assert.equal(total.priced,20);assert.equal(total.pence,2000);
});
test('missing-price examples distinguish absent quotes from unmatched collection entries',async()=>{
 const {c}=await client();c.fixture.cards['test-001'].quote=null;c.fixture.cards['test-001'].noPriceReason='source_pricing_empty';
 c.memCardCol.add('old-1');c.memCardCol.add('unknown-printing');
 const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(c.fixture,stats),value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,2);assert.equal(value.priced,0);assert.equal(value.unpriced,2);
 assert.equal(value.unpricedCards.filter(c=>c.reason==='source_pricing_empty').length,1);
 assert.equal(value.unpricedCards.filter(c=>c.reason==='unmatched_card').length,1);
});
test('actual collection fingerprints match three Classic Collection reprints',async()=>{
 const {c}=await client();const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.resolveSetName=s=>s?.name||'';c.normalizeCardNumber=n=>String(n).replace(/^0+/,'');
 vm.runInContext(html.slice(html.indexOf('const CLASSIC_COLLECTION_CARDS ='),html.indexOf('// v150: exact')),c);
 for(const name of ['getClassicCollectionIdentity','get30thClassicCollectionKey','getCardFingerprint','getPromoOwnershipKeys','promoOwnershipSetNames','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const data={schemaVersion:1,generatedAt:'2026-10-28T04:00:00Z',sets:{cel25cc:{name:'Celebrations Classic Collection',aliases:['cel25cc','cel25c'],names:['Celebrations Classic Collection']}},cards:{}};
 for(const [number,name] of [['CC001','Blastoise'],['CC002','Charizard'],['CC003','Venusaur']]){
  const id='cel25cc-'+number;data.cards[id]={name,number,setId:'cel25cc',quote:{amount:10,currency:'EUR'}};
  c.memSetCardVariants.add('fp_celebrationsclassiccollection_'+name.toLowerCase()+'__holo');
 }
 const stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(data,stats),value=c.calculateProfileValues(cards,stats).sets;
 assert.equal(value.total,3);assert.equal(value.priced,3);assert.equal(value.pence,2550);assert.equal(value.missing.size,0);
 // A different named reprint with the same printed number must remain distinct.
 data.sets['30th-c']={name:'30th Classic Collection',aliases:['30th-c'],names:['30th Classic Collection']};
 data.cards['30th-c-001']={name:'Charizard',number:'001',setId:'30th-c',quote:null};c.sharedPriceIndex=null;
 assert.equal(c.sharedPriceLookup(data).get('fp_30thcelebrationclassiccollection_charizard'),'30th-c-001');
});

test('Dex total and coverage use only its nineteen checked cards, excluding Sets-only and cached cards',async()=>{
 const {c}=await client();
 const cards=Array.from({length:22},(_,i)=>({id:'t-'+i,name:'Pikachu',setName:'Test',number:String(i),priceGBP:i<19?'1':'100'}));
 c.memCardCol=new Set(cards.slice(0,19).flatMap(card=>c.getCardOwnershipKeys(card)));
 const stats={ownedCardKeys:new Set(cards.slice(19,21).map(c.getCardFingerprint))};
 const totals=c.calculateProfileValues(cards,stats);
 assert.equal(totals.dex.total,19);assert.equal(totals.dex.priced,19);assert.equal(totals.dex.pence,1900);
 assert.equal(totals.dex.selectedCards.length,19);assert.equal(totals.sets.total,2);assert.equal(totals.sets.pence,20000);
 c.memCardCol.clear();assert.equal(c.calculateProfileValues(cards,stats).dex.pence,0);
});
test('SV Promos aliases resolve the screenshot warnings once and unchecking removes every saved reference',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.getSupplementalPromoCard=()=>null;c.get30thClassicCollectionKey=()=>'';c.getClassicCollectionIdentity=()=>null;
 for(const name of ['getPromoOwnershipKeys','promoOwnershipSetNames','getCardOwnershipKeys']){
  const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 }
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8'));
 const data={schemaVersion:1,generatedAt:'2026-10-28T19:00:00Z',sets:{svp:{name:'SVP Black Star Promos',aliases:['svp'],names:['SVP Black Star Promos']}},cards:{}};
 for(const id of ['svp-074','svp-075'])data.cards[id]=priceRecord(fixture[id],null,data.generatedAt);
 c.memCardCol=new Set(['svp-74','fp_svpromos_74','svp-75','fp_svpromos_75']);
 let stats=c.calculateProfileStats(),cards=c.sharedProfileValueCards(data,stats),value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,2);assert.equal(value.priced,2);assert.equal(value.missing.size,0);
 assert.equal(new Set(value.selectedCards.map(c=>c.name)).size,2);
 const visible={id:'svp-075',name:'Mimikyu',setName:'SVP Black Star Promos',number:'075'};
 assert.equal(c.isCardCollected(visible),true);
 for(const key of c.getCardOwnershipKeys(visible))c.memCardCol.delete(key);
 assert.equal(c.isCardCollected(visible),false);
 stats=c.calculateProfileStats();cards=c.sharedProfileValueCards(data,stats);value=c.calculateProfileValues(cards,stats).dex;
 assert.equal(value.total,1);assert.equal(value.priced,1);assert.equal(value.selectedCards[0].name,'Charizard ex');
});
test('30th Celebration cards remain N/A when the actual response has no marketplace quotes',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8'));
 for(const id of ['30th-001','30th-002','30th-003']){
  const record=priceRecord(fixture[id],null,'2026-10-28T19:00:00Z');
  assert.equal(record.quote,null);assert.equal(record.noPriceReason,'source_pricing_empty');
 }
});

const {indexCardmarket,directCardmarketQuote,preferDirectQuote}=await import('../scripts/cardmarket-source.mjs');
const extractFixture=()=>{
 const names=['Exeggcute [Hypnosis]','Alolan Exeggutor [Scale Up | Mega Drain]','Volbeat [Luring Glow | Bug Buzz]'];
 const products={products:names.map((name,i)=>({idProduct:907607+i,idCategory:51,idExpansion:6601,name}))};
 const prices={version:1,createdAt:'2026-10-28T02:45:21+0100',priceGuides:names.map((_,i)=>({idProduct:907607+i,idCategory:51,trend:[.05,.06,.05][i]}))};
 return {products,prices};
};
test('three real 30th Celebration responses recover direct Cardmarket prices and the extract date',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{products,prices}=extractFixture(),data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 for(const [i,id] of ['30th-001','30th-002','30th-003'].entries()){
  const record=priceRecord(fixture[id],null,'2026-10-28T20:00:00Z',data);
  assert.equal(record.quote.amount,[.05,.06,.05][i]);assert.equal(record.quote.productId,907607+i);assert.equal(record.quote.via,'Cardmarket daily extract');assert.equal(record.quote.updated,prices.createdAt);
 }
});
test('direct release matching rejects ambiguity, wrong attacks and a different release',async()=>{
 const fixture=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{products,prices}=extractFixture();
 products.products.push({...products.products[2],idProduct:999});
 const data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 assert.equal(directCardmarketQuote({...fixture['30th-003'],id:'30th-004',localId:'004',_cardmarketNameUnique:true},data),null);
 assert.equal(directCardmarketQuote({...fixture['30th-002'],attacks:[{name:'Wrong move'}]},data),null);
 assert.equal(directCardmarketQuote({...fixture['30th-003'],set:{id:'30th-c',name:'30th Classic Collection'}},data),null);
});
test('direct downloads retain the source order and do not replace newer source days',()=>{
 const market={amount:8,currency:'USD',source:'TCGplayer market',priority:1,updated:'2026-10-28'};
 assert.equal(preferDirectQuote(market,{amount:6,priority:2}),market);
 assert.equal(preferDirectQuote(market,{amount:6,priority:0}).amount,6);
 const latest={amount:9,priority:0,updated:'2026-10-29'};assert.equal(preferDirectQuote(latest,{amount:6,priority:0,updated:'2026-10-28'}),latest);
 const {prices,products}=extractFixture();assert.throws(()=>indexCardmarket({...prices,version:99},products),/Invalid/);assert.throws(()=>indexCardmarket(prices,products,Date.parse('2026-12-01')),/stale/);
});
test('explicit products require the exact card name and preserve the holo field distinction',()=>{
 const {prices,products}=extractFixture();products.products.push({idProduct:123,idCategory:51,idExpansion:123,name:'Pikachu [Tackle]'});prices.priceGuides.push({idProduct:123,idCategory:51,trend:2,'trend-holo':20});
 const data=indexCardmarket(prices,products,Date.parse('2026-10-28T20:00:00Z'));
 const c={name:'Pikachu',variants:{normal:true,holo:true},pricing:{cardmarket:{idProduct:123}},variants_detailed:[{type:'holo',variantId:'h'}]};
 assert.equal(directCardmarketQuote(c,data).amount,20);
 assert.equal(directCardmarketQuote({...c,name:'Charizard'},data),null);
});
test('a newly available direct extract rechecks same-day cached N/A entries',async()=>{
 const fixtures=JSON.parse(await readFile(new URL('./profile-regressions.json',import.meta.url),'utf8')),{prices,products}=extractFixture(),now='2026-10-28T20:00:00Z',directData=indexCardmarket(prices,products,Date.parse(now));
 const previous={schemaVersion:1,sets:{},cards:{'30th-001':{name:'Exeggcute',number:'001',setId:'30th',quote:null,pricingModelVersion:245,lastAttemptAt:now,cardmarketExtractChecked:null}}};
 const fetchImpl=async url=>{
  if(url.endsWith('/sets'))return response([{id:'30th',name:'30th Celebration'}]);
  if(url.endsWith('/cards'))return response([{id:'30th-001',name:'Exeggcute'}]);
  if(url.endsWith('/cards/30th-001'))return response(fixtures['30th-001']);
  return response([]);
 };
 const result=await buildSnapshot({previous,directData,fetchImpl,now});
 assert.equal(result.summary.requested,1);assert.equal(result.summary.priced,1);assert.equal(result.cards['30th-001'].quote.amount,.05);assert.equal(result.cards['30th-001'].cardmarketExtractChecked,prices.createdAt);
});

test('collected cards sort before higher-art, rarer and more valuable uncollected cards',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 const start=html.indexOf('function sortCardsList(cards)');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 c.getPokemonCardArtPriority=card=>card.art;
 const owned={id:'svp-75',name:'Mimikyu',setName:'SV Promos',number:'75',art:2,rarityScore:1,priceGBP:'9.43'};
 const special={id:'me2pt5-238',name:"Team Rocket’s Mimikyu",setName:'Ascended Heroes',number:'238',art:4,rarityScore:99,priceGBP:'11.46'};
 const costly={id:'sm8-226',name:'Mimikyu-GX',setName:'Lost Thunder',number:'226',art:2,rarityScore:98,priceGBP:'145.93'};
 c.memCardCol.add('svp-75');const cards=[special,costly,owned];c.sortCardsList(cards);
 assert.equal(cards[0].id,'svp-75');assert.equal(cards[1].id,special.id);
 c.memCardCol.add(costly.id);c.sortCardsList(cards);assert.deepEqual(cards.slice(0,2).map(c=>c.id).sort(),[owned.id,costly.id].sort());
 c.memCardCol.delete(owned.id);c.sortCardsList(cards);assert.equal(cards[0].id,costly.id);assert.equal(cards[1].id,special.id);
});

test('screenshot regression: twenty saved entries with Tropius outside Owned Dex value nineteen cards',async()=>{
 const {c}=await client();
 const names=['Ambipom','Centiskorch V','Charizard ex','Comfey','Dachsbun ex','Dhelmise','Drapion','Larvitar','Lunatone','Mega Audino ex','Mimikyu','Musharna','Nymble','Oricorio ex','Pinsir','Reuniclus','Skarmory','Sliggoo','Toxtricity','Tropius'];
 const ids=[424,851,6,764,927,781,452,246,337,531,778,518,919,741,127,579,227,705,849,357];
 c.dir=names.map((name,i)=>({id:ids[i],name:name.replace(/^Mega /,'').replace(/ (ex|V)$/,''),cleanName:name.replace(/^Mega /,'').replace(/ (ex|V)$/,'')}));c.memCol=new Set(ids.slice(0,19));
 const cards=names.map((name,i)=>({id:'s-'+i,name,setName:'Test',number:String(i),priceGBP:i===19?'.02':'1'}));
 c.memCardCol=new Set(cards.flatMap(card=>c.getCardOwnershipKeys(card)));
 const stats={ownedCardKeys:new Set([c.getCardFingerprint(cards[19])])},result=c.calculateProfileValues(cards,stats);
 assert.equal(result.dex.total,19);assert.equal(result.dex.priced,19);assert.equal(result.dex.pence,1900);assert.equal(result.dex.selectedCards.some(c=>c.name==='Tropius'),false);
 assert.equal(result.sets.total,1);assert.equal(result.sets.pence,2);assert.equal(c.memCardCol.has('s-19'),true,'legacy saved references are not destructively deleted');
 const html=await readFile(new URL('../index.html',import.meta.url),'utf8'),start=html.indexOf('function isCardCollected(card)');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);
 assert.equal(c.isCardCollected(cards[19]),false);assert.equal(c.isCardCollected(cards[0]),true);
 // A deliberate tick reactivates Tropius through the same normal handler.
 c.initAudio=()=>{};c.playTick=()=>{};c.requireCollectionSignIn=()=>true;c.curId=null;c.activeDexModalPoke=null;c.curPoke=null;c.currentCardsList=[cards[19]];c.saveLocalState=()=>{};c.sortCardsList=()=>{};c.writeFullCollectionToCloud=()=>{};
 const toggle=html.indexOf('function toggleCardCollection(');vm.runInContext(html.slice(toggle,html.indexOf('\n}',toggle)+2),c);
 c.toggleCardCollection(cards[19].id,357);assert.equal(c.memCol.has(357),true);assert.equal(c.isCardCollected(cards[19]),true);assert.equal(c.calculateProfileValues(cards,stats).dex.total,20);
 c.toggleCardCollection(cards[19].id,357);assert.equal(c.memCol.has(357),false);assert.equal(c.calculateProfileValues(cards,stats).dex.total,19);assert.equal(result.sets.pence,2);
});
test('removing a visible card preserves its Pokemon when another checked card is cached outside the current list',async()=>{
 const {c}=await client(),html=await readFile(new URL('../index.html',import.meta.url),'utf8');
 c.memCol=new Set([227]);c.dir=[{id:227,name:'Skarmory'}];
 const a={id:'s-1',name:'Skarmory',setName:'Test',number:'1',priceGBP:'1'},b={...a,id:'s-2',number:'2'};
 c.memCardCol=new Set([...c.getCardOwnershipKeys(a),...c.getCardOwnershipKeys(b)]);c.currentCardsList=[a];c.memoryTcgCache.set('other',{data:[b]});
 c.initAudio=()=>{};c.playTick=()=>{};c.requireCollectionSignIn=()=>true;c.curId=null;c.activeDexModalPoke=null;c.curPoke=null;c.saveLocalState=()=>{};c.sortCardsList=()=>{};c.writeFullCollectionToCloud=()=>{};
 for(const name of ['isCardCollected','toggleCardCollection']){const start=html.indexOf('function '+name+'(');vm.runInContext(html.slice(start,html.indexOf('\n}',start)+2),c);}
 c.toggleCardCollection(a.id,227);assert.equal(c.memCol.has(227),true);assert.equal(c.isCardCollected(a),false);assert.equal(c.isCardCollected(b),true);
});

test('missing-price summary shows the total and limits each section to three examples',async()=>{
 const {c}=await client();const node=()=>({children:[],textContent:'',appendChild(x){this.children.push(x)},replaceChildren(){this.children=[]}});
 const nodes={profileUnpricedDetails:node(),profileUnpricedSummary:node(),profileUnpricedExamples:node()};
 c.document.getElementById=id=>nodes[id]||null;c.document.createElement=()=>node();
 const card=i=>({name:'Card '+i,setName:'Test',number:String(i),reason:'source_pricing_empty'});
 c.paintProfileUnpricedExamples({dex:{unpriced:2,unpricedCards:[card(1),card(2)]},sets:{unpriced:5,unpricedCards:[1,2,3,4,5].map(card)}});
 assert.equal(nodes.profileUnpricedSummary.textContent,'Cards without prices (7)');
 assert.equal(nodes.profileUnpricedExamples.children[1].children.length,2);
 assert.equal(nodes.profileUnpricedExamples.children[3].children.length,3);
 assert.match(nodes.profileUnpricedExamples.children[3].children[0].textContent,/exact card printing/);
});

const exactFixture=JSON.parse(await readFile(new URL('./exact-identity-regressions.json',import.meta.url),'utf8'));
const {hydrateCardmarketIdentity}=await import('../scripts/cardmarket-source.mjs');
function exactData(){const d=indexCardmarket(exactFixture.prices,exactFixture.products,Date.parse('2026-10-28T23:00:00Z'));d.identities=structuredClone(exactFixture.identities);return d;}
test('published source IDs resolve the three reported failures without description or price guesses',()=>{
 const data=exactData();
 for(const [id,amount,sku] of [['30th-010',.06,907736],['30th-011',.13,907617],['30th-015',.42,907621]]){
  const r=priceRecord(exactFixture.cards[id],null,'2026-10-28T23:00:00Z',data);
  assert.equal(r.quote.amount,amount);assert.equal(r.quote.productId,sku);assert.equal(r.identitySourceApplied,true);
 }
});
test('Moltres and Fuecoco illustration printings use separate exact product IDs',()=>{
 const data=exactData();
 for(const [id,expected,sku] of [['30th-130',4.89,907738],['30th-147',13.61,907754]]){
  const e=data.identities.cards[id],c={id,name:e.name,localId:e.number,set:{id:e.setId},variants:{normal:true},variants_detailed:[{type:'normal',variantId:'generated'}]};
  const record=priceRecord(c,null,'2026-10-28T23:00:00Z',data);
  assert.equal(record.quote.amount,expected);assert.equal(record.quote.productId,sku);
 }
});
test('identity hydration rejects mismatched number, name and expansion',()=>{
 const data=exactData(),c=exactFixture.cards['30th-011'];
 assert.equal(hydrateCardmarketIdentity({...c,localId:'130'},data)._identityMapRejected,true);
 assert.equal(hydrateCardmarketIdentity({...c,name:'Articuno'},data)._identityMapRejected,true);
 data.identities.cards[c.id].expansionId=999;
 assert.equal(hydrateCardmarketIdentity(c,data)._identityMapRejected,true);
 assert.equal(priceRecord(c,null,'2026-10-28T23:00:00Z',data).quote,null);
});
test('existing explicit detailed IDs are not silently replaced by a different published mapping',()=>{
 const data=exactData(),c=structuredClone(exactFixture.cards['30th-011']);
 c.variants_detailed=[{variantId:'live',type:'normal',thirdParty:{cardmarket:907738}}];
 assert.equal(hydrateCardmarketIdentity(c,data),c);
});
test('an identity-map revision invalidates a same-day cached unpriced entry',async()=>{
 const data=exactData(),now='2026-10-28T23:00:00Z',previous={schemaVersion:1,sets:{},cards:{'30th-011':{name:'Moltres',number:'011',setId:'30th',quote:null,pricingModelVersion:249,lastAttemptAt:now,cardmarketExtractChecked:data.updated,identityMapVersion:'old-map'}}};
 const fetchImpl=async url=>url.endsWith('/sets')?response([{id:'30th',name:'30th Celebration'}]):url.endsWith('/cards')?response([{id:'30th-011',name:'Moltres'}]):url.endsWith('/cards/30th-011')?response(exactFixture.cards['30th-011']):response([]);
 const snapshot=await buildSnapshot({previous,directData:data,fetchImpl,now});
 assert.equal(snapshot.summary.requested,1);assert.equal(snapshot.cards['30th-011'].quote.productId,907617);
});
