# PokeRoulette v249 — exact product matching

Upload PokeRoulette_v249_exact_product_matching_setup.zip alongside existing repository files. Replace .github/workflows/daily-prices.yml with IPHONE_WORKFLOW.yml and commit to main. The commit starts the new run automatically. Keep the existing index.html and app assets.

The workflow refreshes a reference of card identities and marketplace product IDs from TCGdex’s published cards-database, then downloads Cardmarket’s daily product catalogue and price guide. The source is parsed as literal data, never executed. If its download fails, the bundled reference remains available. This is an automatic identity reference, not a table of custom prices.

The bundled reference covers 19,256 card identities. Each link is checked against the exact source card ID, set, provider card number, English name, finish and catalogue expansion. Missing/generated API identity fields are filled from that reference. Existing explicit detailed API IDs remain authoritative. Conflicting or unverified links remain N/A.

The previous snapshot audit recovered 143 of its 727 unpriced entries: 103 in the main 30th Celebration set, 28 in its Classic Collection, 11 SV promos and one Jungle card. These are audit results using the 28 October downloads; live results are confirmed after deployment. All 158 main-set entries in that baseline then had a price. The remaining 584 lacked a validated link under these rules.

Quotes retain their true source dates. Source order remains Cardmarket Trend, TCGplayer Market, then Cardmarket averages. Failures preserve prior valid quotes. Phones still load just the generated shared price file; source/reference downloads run only in GitHub Actions. Identity reference files are excluded from the published site.

The new pricing-model version invalidates old cached matches on the first run. The shared-prices-v241 cache prefix is deliberately retained for recovery. Daily scheduling remains 01:17 UTC. Diagnostics are uploaded as price-diagnostics-v249 and distinguish unverified product links from missing market quotes.

Validation: 35 Node tests, four static-source parser tests, and an audit against the prior published snapshot plus official source/download data. No live deployment is made by preparing this ZIP.
