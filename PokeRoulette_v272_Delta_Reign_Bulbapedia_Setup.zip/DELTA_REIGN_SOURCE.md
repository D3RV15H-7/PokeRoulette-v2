# Delta Reign checklist provenance (PokéRoulette v2.72)

Set: Pokémon TCG Mega Evolution — Delta Reign (`me06`), released 2026-11-06.

141 card identities and printed numbers compiled using:
Bulbapedia contributors, "Delta Reign (TCG)".
https://bulbapedia.bulbagarden.net/wiki/Delta_Reign_(TCG)
Revision inspected: oldid=4663217 (2026-11-06).

Bulbapedia's editorial content generally uses CC BY-NC-SA 2.5:
https://creativecommons.org/licenses/by-nc-sa/2.5/

The attributed identity-only checklist is contained in
`data/bulbapedia-delta-reign.json` and embedded in `index.html` for immediate
availability without a network round trip. The catalogue is for noncommercial
informational use, with attribution displayed in the app and source links.

No Bulbapedia or other third-party card images/logos were imported. Verified
TCGdex artwork (and existing Cardmarket/TCGplayer prices) may enrich records
without being inferred from a card name or made-up URL.

This is a reviewed snapshot, NOT an automatically synchronised Bulbapedia API
feed. The existing GitHub Actions updater continues to refresh provider-linked
artwork and card details. A general ongoing wiki feed would require a separate
supported integration and compliance review.
