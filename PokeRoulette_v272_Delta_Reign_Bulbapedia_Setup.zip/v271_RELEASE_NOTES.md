# PokéRoulette v2.71 — Delta Reign source discovery reliability

- Checks TCGdex's known Delta Reign (`me06`) detail endpoint directly when it is absent from the general set index.
- Imports only TCGdex-supplied IDs, card names, artwork references, logo and published counts. No guessed image URLs or copied artwork from third-party collection apps.
- Preserves the previous published artwork catalogue across temporary provider failures.
- Reports the actual provider card, image and logo coverage in GitHub Actions logs.
- Includes the latest v2.70 UI and the Sample Set (e-Reader Promos) recategorisation.
- Info tab version v2.71.

Important: No complete Delta Reign card art is bundled. PokéCardex does not offer a public API; having a 141-card checklist on that site does not mean 141 English images are available through a licensed source. Cardmarket and TCGplayer price matching remains unchanged.
