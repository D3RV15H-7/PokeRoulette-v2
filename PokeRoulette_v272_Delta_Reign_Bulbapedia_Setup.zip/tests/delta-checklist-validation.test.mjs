import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const source = JSON.parse(readFileSync(new URL('../data/bulbapedia-delta-reign.json', import.meta.url),'utf8'));
test('Delta Reign 141 identities ordered and accounted for',()=>{
  assert.equal(source.cards.length,141);
  for(let i=0;i<source.cards.length;i++){
    assert.equal(source.cards[i].number,String(i+1).padStart(3,'0'));
    assert.equal(source.cards[i].id,`me06-${String(i+1).padStart(3,'0')}`);
    assert.ok(source.cards[i].name);
    assert.equal(source.cards[i].image,null);
  }
  assert.equal(source.cards[83].name,'Mega Rayquaza ex');
  assert.equal(source.cards[137].name,'Mega Rayquaza ex');
  assert.equal(source.cards[140].name,'Mega Rayquaza ex');
  assert.match(source.sourceUrl,/bulbapedia\.bulbagarden\.net/);
  assert.match(source.license,/BY-NC-SA/);
});
