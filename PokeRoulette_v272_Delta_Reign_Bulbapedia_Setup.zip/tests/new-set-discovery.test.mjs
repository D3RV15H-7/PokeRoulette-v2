import test from 'node:test';
import assert from 'node:assert/strict';
import {normaliseNewSet, mergeNewSets, updateNewSets} from '../scripts/update-new-sets.mjs';

const intro = {id:'me06',name:'Delta Reign',releaseDate:'2026-11-06',serie:{name:'Mega Evolution'}};
test('Only source-provided artwork URLs are retained, not guessed',()=>{
  const result=normaliseNewSet(intro,{cards:[
    {id:'me06-084',name:'Mega Rayquaza ex',localId:'084',image:'https://assets.tcgdex.net/en/me/me06/084'},
    {id:'me06-085',name:'Other',localId:'085',image:'https://untrusted.example/085'},
    {id:'other-6',name:'Wrong',localId:'006',image:'https://assets.tcgdex.net/en/me/me06/006'}]});
  assert.equal(result.cards.length,2);
  assert.equal(result.cards[0].image,'https://assets.tcgdex.net/en/me/me06/084');
  assert.equal(result.cards[1].image,null);
});
test('Published artwork survives partial subsequent provider responses',()=>{
  const old=normaliseNewSet(intro,{cards:[{id:'me06-084',name:'Mega Rayquaza ex',image:'https://assets.tcgdex.net/en/me/me06/084'}]});
  const now=normaliseNewSet(intro,{cards:[{id:'me06-084',name:'Mega Rayquaza ex'}]});
  const merged=mergeNewSets([old],[now]);
  assert.equal(merged[0].cards[0].image,old.cards[0].image);
});
test('Verified live artwork enriches the complete attributed checklist',async()=>{
  const result=await updateNewSets({now:new Date('2026-11-04T00:00:00Z'),fetchData:async url=>{
    if(url.endsWith('/sets')) return [intro];
    if(url.endsWith('/me06')) return {...intro,cardCount:{total:141},cards:[{id:'me06-084',name:'Mega Rayquaza ex',localId:'084',image:'https://assets.tcgdex.net/en/me/me06/084'}]};
    throw new Error('Unexpected URL');
  }});
  assert.equal(result.sets[0].id,'me06');
  assert.equal(result.sets[0].cards.length,141);
  assert.equal(result.sets[0].cards.find(card=>card.number==='084')?.image,'https://assets.tcgdex.net/en/me/me06/084');
  assert.equal(result.sets[0].total,141);
});

test('Confirmed release detail is checked even if absent from API set index',async()=>{
  const called=[];
  const result=await updateNewSets({now:new Date('2026-11-05T00:00:00Z'),fetchData:async url=>{
    called.push(url);
    if(url.endsWith('/sets')) return [];
    if(url.endsWith('/me06')) return {id:'me06',name:'Delta Reign',releaseDate:'2026-11-06',cardCount:{total:141,official:103},
      logo:'https://assets.tcgdex.net/en/me/me06/logo',cards:[{id:'me06-084',localId:'084',name:'Mega Rayquaza ex',image:'https://assets.tcgdex.net/en/me/me06/084'}]};
    throw Error('Unexpected URL');
  }});
  assert.ok(called.some(url=>url.endsWith('/me06')));
  assert.equal(result.sets[0].total,141);
  assert.equal(result.sets[0].cards.find(card=>card.number==='084')?.name,'Mega Rayquaza ex');
  assert.ok(result.sets[0].logo);
});
test('Bulbapedia checklist remains available when TCGdex is absent upstream',async()=>{
  const result=await updateNewSets({now:new Date('2026-11-05T00:00:00Z'),fetchData:async url=>{
    if(url.endsWith('/sets')) return [];
    throw Error('HTTP 404');
  }});
  assert.equal(result.sets.length,1);
  assert.equal(result.sets[0].cards.length,141);
  assert.equal(result.sets[0].cards[0].name,'Heracross');
  assert.equal(result.sets[0].cards[0].image,null);
});
