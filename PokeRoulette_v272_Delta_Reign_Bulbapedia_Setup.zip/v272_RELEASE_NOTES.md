# PokéRoulette v2.72 — Delta Reign checklist

- Adds 141 independently numbered Delta Reign cards as a verified checklist fallback, including 38 secret rares.
- Uses Bulbapedia attribution and CC BY-NC-SA source notice; does not import protected images from the wiki.
- Retains TCGdex as preferred provider for verified image links and Cardmarket/TCGplayer for existing prices.
- Opens Delta Reign immediately from bundled checklist even if upstream card API is unavailable.
- Retains existing `me06` set and card IDs to preserve collection records.
- Daily workflow packages the 141 identity snapshot when upstream provider has no set details.
- Info build label updated to v2.72.
