# PokéRoulette v2.68 — automatic new-set and artwork discovery

## Included
- The working v2.66 interface and card-animation code, plus the Delta Reign upcoming-set listing.
- `scripts/update-new-sets.mjs`: scheduled TCGdex new-set discovery, exact provider-supplied card IDs/names/numbers and image URLs. No scraping of community web pages and no guessed artwork URLs.
- `data/new-sets-v1.json`: published snapshot; refreshed by the GitHub Actions workflow. Initially empty until GitHub executes the updater.
- `index.html`: reads the published snapshot and uses it when the older Pokémon TCG API has not supplied the full set yet. Live cards take precedence over preview records. If the live catalogue contains only some cards, the preview catalogue supplements missing numbers.
- Continues using Cardmarket Trend first, TCGplayer fallback, and N/A where no verified price exists.
- The published set catalogue is checked approximately every six hours while the Sets screen is used.
- Info version set to v2.68.

## Deployment (all three files must agree)
1. Upload `PokeRoulette_v268_new_set_artwork_setup.zip` to the root of your GitHub repo; keep the previous v266 ZIP as rollback.
2. Upload the included `index.html` as the root `index.html` (this is necessary because the workflow copies root HTML over the ZIP version).
3. Replace `.github/workflows/daily-prices.yml` with `daily-prices-v268.yml`, including the new ZIP filename and refresh step.
4. Commit to `main` and start a NEW workflow run. Avoid rerunning jobs from a run that already uploaded a `github-pages` artifact.
5. After deployment, inspect `https://pokeroulette.co.uk/data/new-sets-v1.json` and Refresh Sets in the app.

## Provider limitations and rights
- TCGdex may publish card details after the official announcement or even after release. No card scans are fabricated if the provider has not released an image path.
- The Pokémon Company's press assets are editorial/noncommercial restricted. This package does not download or republish them, and does not automatically copy collector-site artwork.
- Card images remain Pokémon intellectual property; TCGdex's MIT metadata license is not an independent license to Pokémon's artwork.
- Scrydex requires a separate paid account and API credentials, so this package does not add it automatically.
- Pre-release fallback records use the default base slot while exact variants are unavailable. They are preview records and are replaced by richer live metadata as it becomes available.
