# PokéRoulette v265 — exact-printing price recovery and gap diagnostics

## Changes
- Adds an exact-printing TCGplayer quote fallback when the provider supplies pricing on a raw variant and the published, validated printing identifies the *same* Cardmarket SKU and TCGplayer product ID. All finish, foil, subtype, size and stamp keys must agree. No borrowing from a differently numbered or differently finished card.
- Splits variant gap diagnostics into `card_identity_blocked`, `printing_identity_not_verified`, `ambiguous_printing_product`, and `verified_printing_quote_unavailable`.
- Produces `unpriced-base-review.csv` and `unpriced-printing-review.csv` alongside the existing coverage outputs; summary includes `printingGapReasons`.
- Increments the pricing model to 265 so the next daily run does a fresh evaluation.
- Adds regression tests for exact-price recovery and for rejecting mismatching product IDs/foil finishes.

## Verification
104 Node.js tests and 7 Python tests passed locally. No live marketplace prices were downloaded in this environment. The 429 unpriced base cards from the v264 diagnostics are NOT claimed fixed, and variant coverage improvement must be measured from the next GitHub workflow run. The existing app HTML and game functions were not changed.

## Installation
Upload this ZIP to the GitHub repository. Update `.github/workflows/daily-prices.yml` to refer to `PokeRoulette_v265_exact_printing_recovery.zip` instead of v264, and update its diagnostics artifact name to `price-diagnostics-v265`. Commit and run the workflow. Keep v264 as a rollback copy.
