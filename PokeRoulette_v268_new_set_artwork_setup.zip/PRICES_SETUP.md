# PokeRoulette v263 — systematic mismatch handling

Use v263 instead of v262. This release includes the two Camerupt corrections and all previous application changes, plus reusable checks applied to the full remaining-card worklist.

## What changed

1. A unique, published plain base printing can recover from a conflicting live API response when the set, number, independent printed name, complete gameplay moves, HP and available TCGplayer identity agree. The published base product must not also be claimed by a different source card number. Conflicting alternatives remain unpriced. Known numbered-reference failures cannot bypass review through this fallback.
2. Explicitly typed or independently numbered Ancient Traits are separated from attacks/Abilities when comparing Cardmarket move suffixes. Ordinary abilities and every attack remain checked. This logic applies across sets, not only to Camerupt or Primal Clash.
3. The reusable numbered-listing importer validates canonical set/number/name, direct listing URL/collector suffix, current product/expansion identity, gameplay signature, edition and duplicate product claims. It imports identity records, never the external review's price figures.
4. All 27 previously unpriced Primal Clash cards have direct numbered-listing references validated against the current catalogue. The mappings remain permanent while their prices update from the daily guide. The numbered review publisher reports extracting product IDs from the exact Cardmarket listing pages; provenance and identity-only regression data are included.

Both the published-base and Ancient Trait rules run automatically during each price update. They do not guess an unknown product ID from a price or a similar name. A future numbered correction can be added through the same importer/registry without a new card-specific price rule.

## Measured results

The successful v261 deployment had 540 unpriced base cards. The v263 focused recheck covered that entire worklist:

- 530 current API card responses were captured and passed through the v263 price engine with the 31 October daily Cardmarket download.
- Ten MEP cards return 404 from the live card API; their published source and guide records were checked separately. Six have asking prices but no supported sales quote; four have empty supported sales-price fields. They remain unpriced.
- 69 base prices recovered: 27 Primal Clash, 19 Jungle, 15 Fossil, five Roaring Skies, one Neo Discovery, one Supreme Victors and one Obsidian Flames.
- Method breakdown: 37 published-base fallbacks; 27 numbered product corrections (including both Camerupt cards); five further gameplay-signature repairs.
- 471 remain unpriced: 461 identity/link cases and ten sales-data cases.

These are captured-response recheck results, not a deployed v263 snapshot or a fresh fetch of every already-priced card. Provider updates can change live results. No previous-price counter is presented as proof that all cards/variants have been checked visually. The accompanying Matching Review contains all 540 outcomes, live/source candidate IDs and other source cards sharing candidate products.

A recovered base price does not automatically establish a price for a stamped, Cosmos, Reverse or other alternative. Existing selection and value-tally rules remain in place; unsupported alternatives do not borrow the recovered base price.

## Upload

1. Upload PokeRoulette_v263_complete_setup.zip unchanged to the repository root.
2. Replace root index.html with PokeRoulette_v263.html, renaming it to index.html.
3. Replace .github/workflows/daily-prices.yml with the contents of PokeRoulette_v263_workflow.yml. Its GitHub filename remains daily-prices.yml.
4. Wait for the Daily PokeRoulette prices workflow and Pages deployment to succeed, then refresh the app. App Details should display v2.63.

Keep the currently working setup ZIP until v263 deploys successfully. The Matching Review and CSV files are for review and do not need to be uploaded to run the app.

## Validation

99 Node tests and seven Python tests pass (106 total). Tests include captured live Fossil/Unown/Ancient Trait cases, exact numbered products, source/live name-number-HP-move-TCGplayer guards, cross-number product collisions, catalogue/reference changes, stale API price rejection, asking-price exclusion, CSV evidence import, collection totals, previous variant handling and artwork loading. Release syntax, versions, workflow targets and ZIP integrity are verified. No live v263 deployment or device visual test is claimed.
