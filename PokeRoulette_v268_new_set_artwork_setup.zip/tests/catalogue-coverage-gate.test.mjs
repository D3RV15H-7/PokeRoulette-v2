import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {readFile} from 'node:fs/promises';
test('daily refresh emits complete catalogue coverage diagnostics',async()=>{
 const update=await readFile('scripts/update-prices.mjs','utf8');
 const report=await readFile('scripts/coverage-report.mjs','utf8');
 assert.match(update,/catalogue-coverage-gate/);
 assert.match(update,/writeCoverageReport\(snapshot,directData/);
 assert.match(report,/diagnosisCounts/);
 assert.match(report,/printing-price-coverage\.csv/);
});
