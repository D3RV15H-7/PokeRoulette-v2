import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {indexCardmarket} from '../scripts/cardmarket-source.mjs';
import {resolveIdentities} from '../scripts/resolve-identities.mjs';
import {priceRecord} from '../scripts/update-prices.mjs';
const f=JSON.parse(await readFile(new URL('./camerupt-numbered-regression.json',import.meta.url),'utf8'));
const now='2026-10-31T17:00:00Z';
function data(){const d=indexCardmarket(f.prices,f.products,Date.parse(now));d.identities=structuredClone(f.identities);resolveIdentities(d,f.metadata,f.names);return d;}
test('regular Camerupt 29 and Full Art 146 use separate numbered products and current base-product trends',()=>{
 const d=data(),a=priceRecord(f.cards['xy5-29'],null,now,d),b=priceRecord(f.cards['xy5-146'],null,now,d);
 assert.equal(a.baseFinish,'holo');assert.equal(b.baseFinish,'holo');
 assert.equal(a.quote.productId,273560);assert.equal(a.quote.amount,3.97);
 assert.equal(b.quote.productId,273677);assert.equal(b.quote.amount,29.93);
 assert.equal(a.quote.fieldSuffix,'');assert.equal(b.quote.fieldSuffix,'');
 for(const r of [a,b]){assert.equal(r.quote.updated,f.prices.createdAt);assert.equal(r.printingQuotes.length,1);assert.equal(r.printingQuotes[0].printing.type,'holo');assert.deepEqual(r.printingQuotes[0].quote,r.quote);}
});
test('a stale Full Art response carrying the regular product and its price cannot override the correction',()=>{
 const d=data(),card={...f.cards['xy5-146'],pricing:{cardmarket:{idProduct:273560,trend:3.97,updated:'2099-01-01'}},variants_detailed:[{type:'holo',variantId:'live',thirdParty:{cardmarket:273560}}]};
 const r=priceRecord(card,{quote:{amount:3.97,currency:'EUR',productId:273560,updated:'2099-01-01'}},now,d);
 assert.equal(r.quote.productId,273677);assert.equal(r.quote.amount,29.93);assert.equal(r.quote.updated,f.prices.createdAt);
});
test('Camerupt corrections reject wrong names, sets, collector numbers and catalogue identities',()=>{
 for(const change of [{name:'Numel'},{set:{id:'xy4'}},{localId:'145'}])assert.equal(priceRecord({...f.cards['xy5-146'],...change},{quote:{amount:99}},now,data()).quote,null);
 for(const change of [{idExpansion:999},{name:'Numel [Tumbling Attack | Explosive Jet]'}]){
  const d=data();d.catalogue.set(273677,{...d.catalogue.get(273677),...change});assert.equal(priceRecord(f.cards['xy5-146'],{quote:{amount:99}},now,d).quote,null);
 }
});
test('Camerupt prices follow changed daily guide values rather than stored manual valuations',()=>{
 const d=data();d.guide.set(273677,{...d.guide.get(273677),trend:34.56});assert.equal(priceRecord(f.cards['xy5-146'],null,now,d).quote.amount,34.56);
 d.guide.delete(273677);assert.equal(priceRecord(f.cards['xy5-146'],{quote:{amount:3.97,productId:273560}},now,d).quote,null);
});
