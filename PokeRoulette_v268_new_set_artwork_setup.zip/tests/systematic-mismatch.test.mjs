import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {indexCardmarket} from '../scripts/cardmarket-source.mjs';
import {resolveIdentities} from '../scripts/resolve-identities.mjs';
import {sourceBasePolicy} from '../scripts/source-base-links.mjs';
import {priceRecord} from '../scripts/update-prices.mjs';
import {gameplayMoves} from '../scripts/gameplay-signature.mjs';
import {importNumberedReview,parseCsv} from '../scripts/import-numbered-review.mjs';
const f=JSON.parse(await readFile(new URL('./systematic-mismatch-regression.json',import.meta.url),'utf8'));
const csv=await readFile(new URL('./numbered-review-import.csv',import.meta.url),'utf8');
const now='2026-10-31T18:00:00Z';
function data(mutate){const d=indexCardmarket(f.prices,f.products,Date.parse(now));d.identities=structuredClone(f.identities);const m=structuredClone(f.metadata),n=structuredClone(f.names);mutate?.(d,m,n);resolveIdentities(d,m,n);return d;}
test('real live Fossil non-holo response is corrected from the published unique base instead of the holo product',()=>{
 const d=data(),c=f.live['base3-16'];assert.equal(c.variants_detailed[0].thirdParty.cardmarket,273862);
 const r=priceRecord(c,null,now,d);assert.equal(r.identityStatus,'verified_base');assert.equal(r.baseFinish,'normal');assert.equal(r.quote.productId,273877);assert.equal(r.quote.amount,11.19);assert.equal(r.quote.fieldSuffix,'');
 assert.equal(r.printingQuotes.find(p=>p.printing.type==='normal'&&!p.printing.foil&&!p.printing.stamp.length&&!p.printing.subtype).quote.productId,273877);
 assert.ok(r.printingQuotes.filter(p=>p.printing.foil).every(p=>p.quote===null),'unsupported galaxy printing must not borrow the base quote');
});
test('real live Unown A response uses its separately numbered non-holo source product',()=>{
 const d=data(),r=priceRecord(f.live['neo2-33'],null,now,d);assert.equal(r.quote.productId,274544);assert.equal(r.quote.amount,9.83);assert.equal(r.baseFinish,'normal');
});
test('published-base fallback rejects a changed number, name, HP, move or cross-provider product identity',()=>{
 const d=data(),raw=f.live['base3-16'];
 for(const change of [{localId:'17'},{name:'Kabutops'},{hp:999},{attacks:[{name:'Wrong attack'}]},{variants_detailed:[{type:'normal',thirdParty:{cardmarket:273862,tcgplayer:999}}],pricing:{}}])assert.equal(sourceBasePolicy({...raw,...change},d),null);
});
test('a second differently numbered source base/root claimant prevents automatic fallback',()=>{
 const d=data((d,m,n)=>{d.identities.cards['base3-999']={name:'Aerodactyl',setId:'base3',number:'999',expansionId:1526,thirdParty:{cardmarket:273877},variants:[]};m.cards['base3-999']={...m.cards['base3-16'],id:'base3-999',localId:'999'};n.cards['base3-999']={name:'Aerodactyl',foilOnly:false};});
 assert.equal(d.sourceBaseLinks.has('base3-16'),false);assert.equal(priceRecord(f.live['base3-16'],null,now,d).quote,null);
});
test('catalogue/numbered-reference failures cannot be bypassed by a base fallback',()=>{
 for(const change of [{idExpansion:999},{name:'Wrong card [Prehistoric Power | Wing Attack]'}]){const d=data(d=>d.catalogue.set(273877,{...d.catalogue.get(273877),...change}));assert.equal(sourceBasePolicy(f.live['base3-16'],d),null);}
 const d=data();d.numberedLinkIssues.push({cardId:'base3-16',reason:'catalogue_identity_changed'});assert.equal(sourceBasePolicy(f.live['base3-16'],d),null);
});
test('Ancient Traits are excluded only as identified rules while ordinary abilities and every attack remain checked',()=>{
 const c={abilities:[{name:'Ω Barrier',type:'Ancient Trait'},{name:'Intimidating Roar',type:'Ability'}],attacks:[{name:'Ω Barrier'},{name:'Flame'}]};
 assert.deepEqual(gameplayMoves(c),['barrier','flame','intimidatingroar']);
 const untyped={abilities:[{name:'Ω Barrier'}],attacks:[{name:'Flame'}]};assert.deepEqual(gameplayMoves(untyped),['barrier','flame']);assert.deepEqual(gameplayMoves(untyped,{ancientTraitName:'Ω Barrier'}),['flame']);
});
test('real Ancient Trait card passes its exact numbered product without dropping an attack',()=>{
 const d=data(),r=priceRecord(f.live['xy5-24'],null,now,d);assert.equal(r.quote.productId,273555);assert.equal(r.quote.amount,d.guide.get(273555).trend);
 const bad={...f.live['xy5-24'],attacks:[{name:'Wrong attack'}]};assert.equal(priceRecord(bad,null,now,d).quote,null);
});
function imported(text=csv){return importNumberedReview({csv:text,metadata:f.metadata,names:f.names,products:f.products,registry:{schemaVersion:1,cards:{'xy5-29':{setId:'xy5',number:'29',productId:273560}}},allowedIds:new Set(['xy5-24','xy5-146']),setId:'xy5',expansionId:1585,setSlug:'Primal-Clash',collectorPrefix:'PRC',mappingEvidenceUrl:'https://github.com/northproxy/pokemon-card-wishlist/blob/main/data/fixtures/primal-clash/mapping-review.csv'});}
test('reusable numbered-listing importer checks the direct listing number and copies no price fields',()=>{
 const r=imported();assert.equal(r.accepted.length,2);assert.equal(r.rejected.length,0);assert.equal(r.registry.cards['xy5-146'].productId,273677);assert.equal(r.registry.cards['xy5-146'].finish,'holo');assert.equal(r.registry.cards['xy5-24'].productId,273555);assert.equal('avg30' in r.registry.cards['xy5-146'],false);
});
test('numbered imports reject a wrong collector URL, product or non-direct evidence method',()=>{
 for(const text of [csv.replace('Camerupt-EX-PRC146','Camerupt-EX-PRC29'),csv.replaceAll('273677','273560'),csv.replaceAll('collector_number_and_direct_listing_product_id','name_only')])assert.ok(imported(text).rejected.length);
});
test('CSV import handles quoted commas, escaped quotes and real line breaks as data',()=>{
 assert.deepEqual(parseCsv('a,b\r\n"one,two","say ""hello""\nworld"\r\n'),[{a:'one,two',b:'say "hello"\nworld'}]);
 assert.throws(()=>parseCsv('a\n"bad'),/Unclosed/);
});
test('an archive mismatch disables all source-base fallback candidates',()=>{
 const d=indexCardmarket(f.prices,f.products,Date.parse(now));d.identities=structuredClone(f.identities);resolveIdentities(d,{...f.metadata,sourceSha256:'different-source'},f.names);assert.equal(d.sourceBaseLinks.size,0);assert.equal(sourceBasePolicy(f.live['base3-16'],d),null);
});
