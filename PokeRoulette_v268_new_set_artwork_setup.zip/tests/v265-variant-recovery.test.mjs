import test from 'node:test';
import assert from 'node:assert/strict';
import {printingPrices} from '../scripts/printing-prices.mjs';
const id=(type,product,tcg='t123')=>({type,thirdParty:{cardmarket:product,tcgplayer:tcg},size:'standard'});
const data={identities:{cards:{'test-1':{variants:[]}}},catalogue:new Map(),guide:new Map(),updated:'2026-11-01T00:00:00Z'};
const card={id:'test-1',set:{id:'test'},name:'Test'};
test('variant audit explains absent verified marketplace identity separately from missing quote',()=>{
 const x=printingPrices({...card,variants_detailed:[{type:'normal',size:'standard'}]}, {variants_detailed:[]},data);
 assert.equal(x[0].reason,'printing_identity_not_verified');
});
test('never treat distinct printing ID as a same-printing marketplace quote',()=>{
 const verified=id('holo',10);
 const provider={...id('holo',11),pricing:{tcgplayer:{normal:{productId:'t123',marketPrice:20}}}};
 const x=printingPrices({...card,variants_detailed:[verified]},{variants_detailed:[provider]},data);
 assert.equal(x[0].quote,null);
});
test('different foil or stamp cannot become an exact provider match',()=>{
 const verified={...id('holo',10),foil:'cosmos'};
 const raw={...id('holo',10),foil:'galaxy',pricing:{tcgplayer:{normal:{productId:'t123',marketPrice:20}}}};
 const x=printingPrices({...card,variants_detailed:[verified]},{variants_detailed:[raw]},data);
 assert.equal(x.find(v=>v.printing.foil==='cosmos').quote,null);
});

test('exact validated printing inherits its matching provider price',()=>{
 const verified=id('holo',10);
 const provider={...id('holo',10),pricing:{tcgplayer:{holofoil:{productId:'t123',marketPrice:12.5}}}};
 const result=printingPrices({...card,variants_detailed:[verified]},{variants_detailed:[provider]},data);
 assert.equal(result[0].quote.amount,12.5);
 assert.equal(result[0].quote.source,'TCGplayer market');
});
