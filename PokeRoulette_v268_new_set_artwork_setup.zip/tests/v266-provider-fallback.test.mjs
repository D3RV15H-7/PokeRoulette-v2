import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchJson,retainedSnapshot,isTransientProviderError} from '../scripts/update-prices.mjs';
const previous={schemaVersion:1,generatedAt:'2026-11-01T20:00:00Z',status:'ready',cards:{'sv1-1':{name:'Sample',quote:{amount:12.5,via:'Cardmarket daily extract'}}},sets:{sv1:{name:'Test'}},summary:{priced:1}};
test('503 and 429 are transient but 404 is not',()=>{
 assert.equal(isTransientProviderError({status:503}),true);
 assert.equal(isTransientProviderError({status:429}),true);
 assert.equal(isTransientProviderError({status:404}),false);
});
test('provider fallback preserves exact verified quote without inventing one',()=>{
 const result=retainedSnapshot(previous,'2026-11-02T16:00:00Z',{status:503,message:'HTTP 503',attempts:5});
 assert.equal(result.status,'stale-provider');
 assert.deepEqual(result.cards,previous.cards);
 assert.equal(result.summary.priceRefreshSkipped,true);
 assert.equal(result.lastSuccessfulPriceSnapshotAt,previous.generatedAt);
});
test('provider fallback rejects empty starter catalogue',()=>{
 assert.throws(()=>retainedSnapshot({schemaVersion:1,cards:{},sets:{}},'2026-11-02T16:00:00Z',{status:503}),/no verified previous/);
});
test('retry completes if transient 503 becomes 200',async()=>{
 let calls=0;
 const result=await fetchJson('https://example.test/sets',{retries:2,fetchImpl:async()=>{
  calls++;
  return calls===1?{ok:false,status:503,headers:{get:()=>null}}:{ok:true,json:async()=>({ok:true})};
 }});
 assert.equal(calls,2);
 assert.deepEqual(result,{ok:true});
});
