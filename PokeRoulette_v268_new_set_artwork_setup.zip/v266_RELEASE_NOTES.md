# PokéRoulette v266 — resilient pricing and variant ordering

- Retry transient provider failures (408, 425, 429, 500, 502, 503, 504, timeouts/network errors) with exponential backoff.
- If the TCGdex catalogue or another mandatory fetch fails after retries, publish the last verified nonempty price snapshot unchanged instead of blocking an otherwise tested HTML deployment.
- Fail safely if there is no previously verified price snapshot; never publish an empty starter price file as a recovery.
- Report a provider failure clearly in `diagnostics/price-report.json`, `diagnostics/catalogue-coverage-gate.json`, Actions step summary and public snapshot `status: stale-provider`.
- Preserve the last successful price snapshot timestamp across repeat outages.
- Includes latest local variant ordering HTML (base, reverse, Cosmos Holo, Cosmos Reverse, other finishes and stamped cards).

The GitHub Pages workflow is distributed separately as `daily-prices-v266.yml` and must be copied to `.github/workflows/daily-prices.yml` in the repository. This setup ZIP is not deployed by itself until the workflow points at its name.

Tested: 108 Node tests and 7 Python tests. Live network deployment not tested.
