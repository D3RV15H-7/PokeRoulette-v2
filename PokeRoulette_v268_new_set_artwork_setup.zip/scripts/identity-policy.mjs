import {normalizeMarketplaceName,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
import {sourceBasePolicy} from './source-base-links.mjs';
import {gameplayMoves} from './gameplay-signature.mjs';
const cache=new WeakMap();
// Identity correction only: prices always come from the current extract.
// Product page: https://www.cardmarket.com/en/Pokemon/Products/Singles/Generations/Pikachu-V2-GENRC29
// Independent product-number corroboration: https://recollectibles.de/products/pikachu-gen-rc29-ultra-rare-englisch
export const CORRECTIONS={
 // Separate numbered Cardmarket listings: PRC29 and PRC146. The upstream
 // source currently assigns 273560 to both; neither guide bucket identifies
 // the Full Art. Evidence: tests/camerupt-numbered-evidence.json.
 'xy5-29':{name:'Camerupt EX',setId:'xy5',number:'29',productId:273560,expansionId:1585,finish:'holo'},
 'xy5-146':{name:'Camerupt EX',setId:'xy5',number:'146',productId:273677,expansionId:1585,finish:'holo'},
 'sm10-198':{name:'Marshadow & Machamp GX',setId:'sm10',number:'198',productId:372480,expansionId:2437,finish:'holo'},
 'smp-SM81':{name:'Pikachu',setId:'smp',number:'SM81',productId:311416,expansionId:1757,finish:'holo'},
 'xyp-XY124':{name:'Pikachu EX',setId:'xyp',number:'XY124',productId:293003,expansionId:1612,finish:'holo'},
 'smp-SM242':{name:'Eevee GX',setId:'smp',number:'SM242',productId:449233,expansionId:1757,finish:'holo'},
 'smp-SM247':{name:'Reshiram & Charizard GX',setId:'smp',number:'SM247',productId:576719,expansionId:1757,finish:'holo'},
 'smp-SM248':{name:'Pikachu & Zekrom GX',setId:'smp',number:'SM248',productId:576720,expansionId:1757,finish:'holo'},
 'g1-RC29':{name:'Pikachu',setId:'g1',number:'RC29',productId:288538,expansionId:1693,finish:'holo'}};
const clean=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
export function auditIdentities(data){
 if(!data)return {policies:new Map(),conflicts:[]};
 if(cache.has(data))return cache.get(data);
 const groups=new Map(),policies=new Map();
 for(const [id,e] of Object.entries(data.identities?.cards||{})){
  if(data.numberedLinks?.has(id)){
   const row=data.numberedLinks.get(id),key=row.setId+':'+row.productId;
   policies.set(id,{kind:'numbered',...row});
   if(!groups.has(key))groups.set(key,[]);groups.get(key).push({id,name:e.name,number:e.number,setId:e.setId,productId:row.productId});continue;
  }
  const finishPair=data.approvedFinishPairs?.get(id);
  if(finishPair){policies.set(id,{kind:'finish_pair',...finishPair});continue;}
  const correction=CORRECTIONS[id];
  if(correction){policies.set(id,{kind:'corrected',...correction});continue;}
  const ids=new Set([e.thirdParty?.cardmarket,...(e.variants||[]).map(v=>v.thirdParty?.cardmarket)].filter(Boolean));
  for(const sku of ids){const key=e.setId+':'+sku;if(!groups.has(key))groups.set(key,[]);groups.get(key).push({id,name:e.name,number:e.number,setId:e.setId,productId:sku});}
 }
 const conflicts=[];
 for(const [key,entries] of groups){
  if(new Set(entries.map(e=>normalNumber(e.number))).size<2)continue;
  const numbered=entries.filter(e=>data.numberedLinks?.get(e.id)?.productId===e.productId);
  if(numbered.length===1){for(const e of entries)if(e.id!==numbered[0].id)policies.set(e.id,{kind:'conflict',productId:e.productId});continue;}
  // A wrong-name claimant must not quarantine the one independently named
  // card whose complete moves agree. Identical artworks remain ambiguous.
  const eligible=entries.filter(e=>{
   const source=data.sourceMetadata?.cards?.[e.id],entry=data.identities.cards[e.id],p=data.catalogue.get(Number(e.productId));
   const ref=data.independentNames?.cards?.[e.setId+'-'+normalNumber(e.number)];
   const parsed=p&&/\[([^\]]+)\]\s*$/.exec(p.name);
   const moves=source&&gameplayMoves(source,ref);
   return ref&&source?.category==='Pokemon'&&moves?.length&&p?.idExpansion===entry.expansionId&&marketplaceProductName(p)===normalizeMarketplaceName(ref.name)&&parsed&&JSON.stringify(parsed[1].split('|').map(normalizeMarketplaceName).sort())===JSON.stringify(moves);
  });
  if(eligible.length===1){
   for(const e of entries)if(e.id!==eligible[0].id)policies.set(e.id,{kind:'conflict',productId:e.productId});
   continue;
  }
  conflicts.push({key,entries,reason:'Different source card numbers share a marketplace product; finish/printing requires independent review.'});
  for(const e of entries)policies.set(e.id,{kind:'conflict',productId:e.productId});
 }
 // A known bad link is blocked even when a source refresh omits its entry.
 for(const [id,c] of Object.entries(CORRECTIONS))policies.set(id,{kind:'corrected',...c});
 for(const [id,row] of data.numberedLinks||[])if(!CORRECTIONS[id])policies.set(id,{kind:'numbered',...row});
 for(const issue of data.numberedLinkIssues||[])if(!CORRECTIONS[issue.cardId]&&!data.numberedLinks?.has(issue.cardId))policies.set(issue.cardId,{kind:'conflict',reason:issue.reason});
 const result={policies,conflicts};cache.set(data,result);return result;
}
export function identityPolicy(card,data){
 let p=auditIdentities(data).policies.get(card.id)||(CORRECTIONS[card.id]?{kind:'corrected',...CORRECTIONS[card.id]}:null);
 if(p?.kind==='conflict')p=sourceBasePolicy(card,data)||p;
 if(!p)return null;
 if(p.kind==='numbered'){
  const sameName=[p.sourceName,p.independentName].filter(Boolean).some(n=>normalizeMarketplaceName(n)===normalizeMarketplaceName(card.name));
  const moves=Array.isArray(card.attacks)||Array.isArray(card.abilities)?[...(card.abilities||[]),...(card.attacks||[])].map(x=>normalizeMarketplaceName(x.name)).filter(Boolean).sort():null;
  if(card.set?.id!==p.setId||normalNumber(card.localId||card.number)!==normalNumber(p.number)||!sameName||(moves&&JSON.stringify(moves)!==JSON.stringify(p.sourceMoves)))return {...p,kind:'conflict'};
 }
 if(p.kind==='corrected'){
  const product=data?.catalogue.get(p.productId);
  if(card.set?.id!==p.setId||normalNumber(card.localId||card.number)!==normalNumber(p.number)||clean(card.name)!==clean(p.name)||product?.idExpansion!==p.expansionId||clean(product.name.replace(/\s*\[[^\]]+\]\s*$/,''))!==clean(p.name))return {...p,kind:'conflict'};
 }
 return p;
}
export function correctedCard(card,p){
 return {...card,pricing:{},thirdParty:{cardmarket:p.productId},variants:{normal:p.finish==='normal',holo:p.finish==='holo',reverse:p.finish==='reverse'},variants_detailed:[{...(p.basePrinting||{}),type:p.finish,size:'standard',variantId:'independently-corrected',thirdParty:{cardmarket:p.productId}}]};
}
