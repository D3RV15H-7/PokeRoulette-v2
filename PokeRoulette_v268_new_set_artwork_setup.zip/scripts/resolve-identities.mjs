import {applyPrintingSupplements} from './printing-supplements.mjs';
import {normalizeMarketplaceName as normal,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
import {applyNumberedLinks} from './numbered-links.mjs';
import {buildSourceBaseLinks} from './source-base-links.mjs';
import {CORRECTIONS} from './identity-policy.mjs';
import {gameplayMoves} from './gameplay-signature.mjs';
const signature=(name,ms)=>normal(name)+'|'+ms.join('|');
export function resolveIdentities(data,metadata,names){
 if(!data?.identities?.cards||!metadata?.cards)return;
 data.independentNames=names;data.sourceMetadata=metadata;
 const moves=c=>gameplayMoves(c,names?.cards?.[c.set.id+'-'+normalNumber(c.localId)]);
 if(data.identities.sourceSha256&&metadata.sourceSha256&&data.identities.sourceSha256!==metadata.sourceSha256){
  data.referenceWarning='Source identity and metadata archives differ; automatic identity repairs were skipped.';
  data.mappingRepairs=[];data.expansionRepairs=[];data.approvedFinishPairs=new Map();
  data.numberedLinks=new Map();data.numberedSetExpansions=new Map();
  data.sourceBaseLinks=new Map();
  return;
 }

 applyPrintingSupplements(data);
 applyNumberedLinks(data,metadata,names);
 const expected=c=>names?.cards?.[c.set.id+'-'+normalNumber(c.localId)]?.name||c.name;
 // A set-level ID can itself be stale. Require agreement from at least
 // ten independently numbered Pokémon and their complete move signatures.
 const votes=new Map();data.expansionRepairs=[];
 for(const [id,e] of Object.entries(data.identities.cards)){
  const c=metadata.cards[id],ref=names?.cards?.[e.setId+'-'+normalNumber(e.number)];if(!c||!ref||c.category!=='Pokemon'||!moves(c).length)continue;
  const expansions=new Set();
  for(const sku of new Set([e.thirdParty?.cardmarket,...e.variants.map(v=>v.thirdParty?.cardmarket)].filter(Boolean))){
   const p=data.catalogue.get(Number(sku)),m=p&&/\s*\[([^\]]+)\]\s*$/.exec(p.name);
   if(m&&marketplaceProductName(p)===normal(ref.name)&&JSON.stringify(m[1].split('|').map(normal).sort())===JSON.stringify(moves(c)))expansions.add(p.idExpansion);
  }
  if(expansions.size!==1)continue;if(!votes.has(e.setId))votes.set(e.setId,new Map());const vote=votes.get(e.setId),exp=[...expansions][0];vote.set(exp,(vote.get(exp)||0)+1);
 }
 const source=structuredClone(data.identities);
 for(const [setId,counts] of votes){const ranked=[...counts].sort((a,b)=>b[1]-a[1]),[winner,count]=ranked[0],total=ranked.reduce((n,r)=>n+r[1],0),old=Object.values(source.cards).find(e=>e.setId===setId)?.expansionId;
  if(winner===old||count<10||count/total<.9||(counts.get(old)||0)>0)continue;
  for(const e of Object.values(source.cards))if(e.setId===setId)e.expansionId=winner;
  data.expansionRepairs.push({setId,previousExpansionId:old,expansionId:winner,agreeingCards:count,checkedCards:total,basis:'independent_printed_name_and_complete_signature_consensus'});
 }
 data.identities=source;
 const sourceGroups=new Map(),productGroups=new Map(),productKeys=new Map();
 const expansionBySet=new Map([...data.numberedSetExpansions,...Object.values(data.identities.cards).map(e=>[e.setId,e.expansionId])]);
 for(const [id,c] of Object.entries(metadata.cards)){
  const e=data.identities.cards[id]||{expansionId:expansionBySet.get(c.set.id)},ms=moves(c);
  const ref=names?.cards?.[c.set.id+'-'+normalNumber(c.localId)];
  if(!e.expansionId||!(c.category==='Pokemon'&&ms.length||['Trainer','Energy'].includes(c.category)))continue;
  const k=e.expansionId+'|'+signature(expected(c),ms);
  if(!sourceGroups.has(k))sourceGroups.set(k,[]);sourceGroups.get(k).push(id);
 }
 for(const p of data.catalogue.values()){
  const match=/\s*\[([^\]]+)\]\s*$/.exec(p.name);
  const hasMoves=match&&marketplaceProductName(p)===normal(p.name.slice(0,match.index));
  const k=p.idExpansion+'|'+(hasMoves?signature(p.name.slice(0,match.index),match[1].split('|').map(x=>normal(x)).sort()):signature(p.name,[]));
  productKeys.set(p.idProduct,k);
  if(!productGroups.has(k))productGroups.set(k,[]);productGroups.get(k).push(p.idProduct);
 }
 const repaired=structuredClone(data.identities);data.mappingRepairs=[];
 for(const [k,ids] of sourceGroups){
  const candidates=productGroups.get(k)||[];
  if(ids.length!==1||candidates.length!==1)continue;
  const id=ids[0],original=data.identities.cards[id],target=candidates[0];
  let e=repaired.cards[id];
  if(data.numberedLinks.has(id))continue;
  const c=metadata.cards[id];
  if(c.category!=='Pokemon'&&!names?.cards?.[c.set.id+'-'+normalNumber(c.localId)])continue;
  if(!e){
   const c=metadata.cards[id],ref=names?.cards?.[c.set.id+'-'+normalNumber(c.localId)];
   if(!ref||normal(ref.name)!==normal(expected(c)))continue;
   e=repaired.cards[id]={name:c.name,setId:c.set.id,number:c.localId,expansionId:expansionBySet.get(c.set.id),thirdParty:{cardmarket:target},variants:[]};
   const details=(c.variants_detailed||[]).filter(v=>['normal','holo','reverse'].includes(v.type)&&(!v.size||v.size==='standard')&&!v.staff&&!v.stamp?.length&&!v.foil&&(!v.subtype||v.subtype==='unlimited'));
   // A reverse-only promotional card has no separate normal bucket to borrow.
   // Preserve its declared sole finish when linking the unique exact product.
   if(details.length===1&&details[0].type==='reverse')e.variants=[{type:'reverse',size:'standard',thirdParty:{...details[0].thirdParty,cardmarket:target}}];
   data.mappingRepairs.push({cardId:id,productId:target,previousIds:[],basis:'new_link_unique_independent_name_and_complete_moves_on_both_sides',createsIdentity:true});
   continue;
  }
  // These are exact, unique full signatures on BOTH sides in one expansion.
  // No fuzzy-name or nearest-price selection is permitted.
  let changed=false;
  const root=original.thirdParty?.cardmarket;
  const sameForeign=id=>{const p=data.catalogue.get(Number(id)),actual=productKeys.get(Number(id));return p&&p.idExpansion!==e.expansionId&&actual?.slice(actual.indexOf('|')+1)===k.slice(k.indexOf('|')+1);};
  if(root&&Number(root)!==target&&!sameForeign(root)){e.thirdParty={...e.thirdParty,cardmarket:target};changed=true;}
  e.variants=(e.variants||[]).map(v=>{
   const p=data.catalogue.get(Number(v.thirdParty?.cardmarket));
   if(sameForeign(v.thirdParty?.cardmarket))return v; // Matching separate printing families retain their own identity.
   if(Number(v.thirdParty.cardmarket)===target)return v;
   changed=true;return {...v,thirdParty:{...v.thirdParty,cardmarket:target}};
  });
  if(changed)data.mappingRepairs.push({cardId:id,productId:target,previousIds:[root,...original.variants.map(v=>v.thirdParty?.cardmarket)].filter(Boolean),basis:'unique_name_and_complete_moves_in_same_expansion_on_both_sides'});
 }
 repaired.sourceSha256+='|names:'+(names?.sourceSha256||'none')+'|resolver:263';
 data.identities=repaired;data.approvedFinishPairs=new Map();
 // Two guide buckets do not prove that differently numbered cards share a
 // product. A numbered reference is required instead of inferring this pair.
 buildSourceBaseLinks(data,metadata,names,CORRECTIONS);
}
