import {normalizeMarketplaceName as normal,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
import {gameplayMoves} from './gameplay-signature.mjs';
const moves=c=>[...(c.abilities||[]),...(c.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort();
const plain=v=>['normal','holo'].includes(v.type)&&(!v.size||v.size==='standard')&&!v.staff&&!v.foil&&!v.stamp?.length&&(!v.subtype||v.subtype==='unlimited')&&(!v.languages?.length||v.languages.includes('en'));
export function buildSourceBaseLinks(data,metadata,names,corrections={}){
 data.sourceBaseLinks=new Map();const proposed=new Map(),claims=new Map();
 for(const [id,e] of Object.entries(data.identities?.cards||{})){
  const c=metadata?.cards?.[id];if(!c)continue;
  const known=corrections[id]||data.numberedLinks?.get(id);
  const variants=(e.variants||[]).filter(plain);
  const products=[...new Set(variants.map(v=>Number(v.thirdParty?.cardmarket)).filter(Boolean))];
  const types=[...new Set(variants.map(v=>v.type))];
  const pid=known?.productId||(products.length===1&&types.length===1?products[0]:null);
  const claimIds=known?[known.productId]:[pid,e.thirdParty?.cardmarket].filter(Boolean);
  for(const claim of new Set(claimIds)){const key=e.setId+':'+claim;if(!claims.has(key))claims.set(key,new Set());claims.get(key).add(normalNumber(e.number));}
  if(!pid)continue;
  if(known)continue; // Explicit numbered corrections have their own guards.
  const ref=names?.cards?.[e.setId+'-'+normalNumber(e.number)],p=data.catalogue.get(pid),ms=moves(c);
  if(!ref||!p||p.idExpansion!==e.expansionId||marketplaceProductName(p)!==normal(ref.name))continue;
  if(![c.name,ref.name].some(n=>normal(n)===normal(e.name)))continue;
  const parsed=/\s*\[([^\]]+)\]\s*$/.exec(p.name);
  const gameplay=gameplayMoves(c,ref);
  if(c.category==='Pokemon'&&(!gameplay.length||!parsed||JSON.stringify(parsed[1].split('|').map(normal).sort())!==JSON.stringify(gameplay)))continue;
  if(!['Pokemon','Trainer','Energy'].includes(c.category))continue;
  proposed.set(id,{setId:e.setId,number:e.number,name:e.name,independentName:ref.name,productId:pid,expansionId:e.expansionId,finish:types[0],sourceMoves:ms,tcgplayerIds:[...new Set(variants.map(v=>Number(v.thirdParty?.tcgplayer)).filter(Boolean))],hp:c.hp||null,evidenceUrl:ref.sourceUrl||data.identities.sourceUrl,basis:'uncontested_published_plain_base_with_independent_numbered_name_and_complete_moves'});
 }
 for(const [id,row] of proposed)if(claims.get(row.setId+':'+row.productId)?.size===1)data.sourceBaseLinks.set(id,row);
}
export function sourceBasePolicy(card,data){
 if(data?.numberedLinkIssues?.some(r=>r.cardId===card.id))return null;
 const row=data?.sourceBaseLinks?.get(card.id);if(!row)return null;
 if(card.set?.id!==row.setId||normalNumber(card.localId||card.number)!==normalNumber(row.number)||![row.name,row.independentName].some(n=>normal(n)===normal(card.name)))return null;
 if((Array.isArray(card.attacks)||Array.isArray(card.abilities))&&JSON.stringify(moves(card))!==JSON.stringify(row.sourceMoves))return null;
 if(row.hp&&card.hp&&Number(row.hp)!==Number(card.hp))return null;
 const liveTcg=new Set([card.thirdParty?.tcgplayer,...(card.variants_detailed||card.variantsDetailed||[]).filter(v=>v.type===row.finish&&(!v.size||v.size==='standard')&&!v.staff).map(v=>v.thirdParty?.tcgplayer),...Object.values(card.pricing?.tcgplayer||{}).filter(v=>v&&typeof v==='object').map(v=>v.productId)].map(Number).filter(Boolean));
 if(row.tcgplayerIds.length&&liveTcg.size&&!row.tcgplayerIds.some(id=>liveTcg.has(id)))return null;
 const p=data.catalogue.get(row.productId);if(!p||p.idExpansion!==row.expansionId||marketplaceProductName(p)!==normal(row.independentName))return null;
 return {kind:'verified_base',...row};
}
