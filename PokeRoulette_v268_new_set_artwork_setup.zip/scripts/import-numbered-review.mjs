import {normalizeMarketplaceName as normal,marketplaceProductName} from './marketplace-identity.mjs';
import {normalNumber} from './price-model.mjs';
import {gameplayMoves} from './gameplay-signature.mjs';
export function parseCsv(text){
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
  else if(c===','&&!quoted){row.push(cell);cell='';}
  else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(Boolean))rows.push(row);row=[];cell='';}
  else cell+=c;
 }
 if(quoted)throw new Error('Unclosed CSV quote');
 if(cell||row.length){row.push(cell);rows.push(row);}
 const header=(rows.shift()||[]).map(s=>s.replace(/^\uFEFF/,''));return rows.map(r=>Object.fromEntries(header.map((k,i)=>[k,r[i]||''])));
}
// Import identity evidence only. Source CSV prices are never copied.
export function importNumberedReview({csv,metadata,names,products,registry,allowedIds,setId,expansionId,setSlug,collectorPrefix,mappingEvidenceUrl}){
 const out=structuredClone(registry),accepted=[],rejected=[],catalogue=new Map(products.products.filter(p=>p.idCategory===51).map(p=>[p.idProduct,p]));
 for(const r of parseCsv(csv)){
  const id=r.canonical_card_id;if(!allowedIds.has(id))continue;
  const c=metadata.cards[id],ref=c&&names.cards[setId+'-'+normalNumber(c.localId)],pid=Number(r.cardmarket_product_id),p=catalogue.get(pid);
  const fail=reason=>rejected.push({cardId:id,productId:pid||null,reason});
  if(r.mapping_method!=='collector_number_and_direct_listing_product_id'||r.mapping_status!=='candidate'||r.edition_code){fail('not_a_direct_standard_numbered_listing');continue;}
  if(!c||c.set.id!==setId||!ref||normalNumber(r.collector_number)!==normalNumber(c.localId)||normal(r.canonical_name)!==normal(ref.name)){fail('source_number_or_independent_name_disagrees');continue;}
  let url;try{url=new URL(r.listing_url);}catch{fail('invalid_listing_url');continue;}
  if(url.hostname!=='www.cardmarket.com'||!url.pathname.startsWith('/en/Pokemon/Products/Singles/'+setSlug+'/')||!url.pathname.endsWith('-'+collectorPrefix+r.collector_number)){fail('listing_does_not_identify_this_set_and_number');continue;}
  if(!p||p.idExpansion!==expansionId||p.name!==r.cardmarket_product_name||marketplaceProductName(p)!==normal(ref.name)){fail('current_catalogue_disagrees');continue;}
  const ms=[...(c.abilities||[]),...(c.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort(),parsed=/\s*\[([^\]]+)\]\s*$/.exec(p.name);
  const gameplay=gameplayMoves(c,ref);
  if(c.category==='Pokemon'&&(!gameplay.length||!parsed||JSON.stringify(parsed[1].split('|').map(normal).sort())!==JSON.stringify(gameplay))){fail('complete_moves_disagree');continue;}
  const plain=(c.variants_detailed||[]).filter(v=>['normal','holo'].includes(v.type)&&!v.foil&&!v.stamp?.length&&(!v.subtype||v.subtype==='unlimited')&&(!v.size||v.size==='standard'));
  const types=[...new Set(plain.map(v=>v.type))];
  const finish=types.length===1?types[0]:ref.foilOnly||/holo|ultra rare|secret rare|shiny rare|illustration rare/i.test(c.rarity||'')?'holo':'normal';
  out.cards[id]={setId,number:c.localId,sourceName:c.name,independentName:ref.name,sourceMoves:ms,productId:pid,expansionId,catalogueName:p.name,finish,basePrinting:{},evidenceUrl:r.listing_url,evidenceCardId:id,evidencePrintedName:ref.name,numberedEvidenceVerified:true,mappingEvidenceUrl,mappingMethod:r.mapping_method,checkedAt:'2026-10-31',basis:'numbered_listing_direct_product_id_corroboration_and_current_catalogue_validation'};
  accepted.push({cardId:id,productId:pid,finish});
 }
 const claims=new Map();
 for(const [id,row] of Object.entries(out.cards)){
  const key=row.setId+':'+row.productId;if(!claims.has(key))claims.set(key,[]);claims.get(key).push({id,number:normalNumber(row.number)});
 }
 const conflicting=new Set();
 for(const entries of claims.values())if(new Set(entries.map(x=>x.number)).size>1)for(const e of entries)if(accepted.some(a=>a.cardId===e.id))conflicting.add(e.id);
 for(const id of conflicting){const productId=out.cards[id].productId;if(registry.cards[id])out.cards[id]=registry.cards[id];else delete out.cards[id];rejected.push({cardId:id,productId,reason:'numbered_product_already_claimed_by_a_different_number'});}
 out.version=263;return {registry:out,accepted:accepted.filter(r=>!conflicting.has(r.cardId)),rejected};
}
