import {directCardmarketQuote,preferDirectQuote} from './cardmarket-source.mjs';
const token=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
export function printingIdentity(v){
 const subtype=token(v.subtype),foil=token(v.foil),cosmos=s=>/^(?:cosmos|cosmo)(?:-?holo(?:foil)?)?$/.test(s);
 return {type:v.type,foil:cosmos(foil)||(!foil&&cosmos(subtype))?'cosmos':foil,subtype:subtype==='unlimited'||cosmos(subtype)?'':subtype,size:token(v.size||'standard'),stamp:[...new Set((Array.isArray(v.stamp)?v.stamp:[]).map(token).map(s=>/^(?:whats|what-s)-your-favou?rite(?:-stamp)?$/.test(s)?'whats-your-favourite':s).filter(Boolean))].sort()};
}
const key=v=>JSON.stringify(printingIdentity(v));
export function printingPrices(card,raw,data,blocked=false){
 const valid=card.variants_detailed||card.variantsDetailed||[];
 const source=data?.identities?.cards?.[card.id]?.variants||[];
 const original=raw.variants_detailed||raw.variantsDetailed||[];
 const groups=new Map();
 for(const v of [...valid,...source,...original]){
  if(!v||v.variantId==='generated'||!['normal','holo','reverse'].includes(v.type)||v.staff||v.stamp?.some(s=>/staff/i.test(s))||(v.size&&v.size!=='standard')||(v.languages?.length&&!v.languages.some(l=>/^en(?:-|$)/i.test(l))))continue;
  const k=key(v);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(v);
 }
 return [...groups.values()].map(rows=>{
  const printing=printingIdentity(rows[0]);
  const good=rows.filter(v=>valid.some(g=>key(g)===key(v)&&g.thirdParty?.cardmarket&&Number(g.thirdParty.cardmarket)===Number(v.thirdParty?.cardmarket)));
  // A provider can put its market quote on the raw printing while the verified
  // identity is on the hydrated printing (or vice versa). Join only the SAME
  // exact finish, foil, subtype, stamp and marketplace product identifiers.
  const exactProvider=good.flatMap(v=>original.filter(r=>key(r)===key(v)&&
   Number(r.thirdParty?.cardmarket)>0&&Number(r.thirdParty.cardmarket)===Number(v.thirdParty?.cardmarket)&&
   String(r.thirdParty?.tcgplayer||'')===String(v.thirdParty?.tcgplayer||'')&&r.pricing?.tcgplayer));
  const ids=new Set(good.map(v=>v.thirdParty?.cardmarket));
  let quote=null;
  if(!blocked&&ids.size===1){
   const distinctProviderQuotes=new Set(exactProvider.flatMap(v=>Object.values(v.pricing?.tcgplayer||{})).filter(q=>q&&typeof q==='object'&&Number(q.marketPrice)>0).map(q=>String(q.productId)+'|'+Number(q.marketPrice)));
   const v=good.find(v=>v.pricing?.tcgplayer)||(distinctProviderQuotes.size===1?exactProvider[0]:null)||good.find(v=>v.pricing)||good[0];
   const direct=directCardmarketQuote({...card,variants_detailed:[v],_pricingAllVariants:valid},data,v.type);
   const tcg=v.pricing?.tcgplayer||{};
   const markets=Object.values(tcg).filter(x=>x&&typeof x==='object'&&String(x.productId||'')===String(v.thirdParty?.tcgplayer||'')&&Number(x.marketPrice)>0);
   const market=markets.length===1?{amount:Number(markets[0].marketPrice),currency:'USD',source:'TCGplayer market',priority:1,updated:tcg.updated||null,productId:markets[0].productId}:null;
   quote=preferDirectQuote(market,direct);
  }
  const reason=quote?null:blocked?'card_identity_blocked':!good.length?'printing_identity_not_verified':ids.size>1?'ambiguous_printing_product':'verified_printing_quote_unavailable';
  return {printing,quote,reason};
 });
}
