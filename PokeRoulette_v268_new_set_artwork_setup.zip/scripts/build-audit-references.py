"""Build English card metadata and an independent printed-name reference from primary repositories."""
import datetime,hashlib,importlib.util,io,json,pathlib,re,sys,tarfile,urllib.request
root=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('source_parser',root/'scripts/build-product-map.py');parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
def normal_number(s):return re.sub(r'^([a-z]*)0+(?=\d)',r'\1',re.sub('[^a-z0-9]','',str(s).lower()))
def atomic(path,data):
 p=root/path;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')));tmp.replace(p)
def build(source_blob,names_blob,aliases):
 t=tarfile.open(fileobj=io.BytesIO(source_blob));texts={}
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if m.isfile() and len(p.parts)>2 and p.parts[1]=='data' and p.suffix=='.ts' and m.size<250000:texts[pathlib.PurePosixPath(*p.parts[1:])]=t.extractfile(m).read().decode()
 sets={}
 for p,text in texts.items():
  s=parser.literal(text,'Set')
  if isinstance(s,dict) and isinstance(s.get('id'),str):sets[p.with_suffix('')]=s
 cards={}
 for p,text in texts.items():
  parent=sets.get(p.parent)
  if not parent:continue
  c=parser.literal(text,'Card')
  if not isinstance(c,dict) or not isinstance(c.get('name'),dict) or not c['name'].get('en'):continue
  out={k:c[k] for k in ['thirdParty','variants','hp','rarity','category','stage'] if c.get(k) is not None}
  out.update(id=parent['id']+'-'+p.stem,name=c['name']['en'],localId=p.stem,set={'id':parent['id'],'name':(parent.get('name') or {}).get('en') or parent['id']})
  for k in ['abilities','attacks']:out[k]=[{'name':x['name']['en'],**({'type':x['type']} if isinstance(x.get('type'),str) else {})} for x in c.get(k,[]) if isinstance(x,dict) and isinstance(x.get('name'),dict) and x['name'].get('en')]
  if isinstance(out.get('variants'),list):out['variants_detailed']=[dict(v,variantId='published-full-'+str(i)) for i,v in enumerate(out['variants']) if isinstance(v,dict)];out['variants']={}
  cards[out['id']]=out
 names={};conflicts=[]
 t=tarfile.open(fileobj=io.BytesIO(names_blob))
 for m in t.getmembers():
  if not(m.isfile() and '/cards/en/' in m.name and m.name.endswith('.json') and m.size<10000000):continue
  set_id=pathlib.PurePosixPath(m.name).stem;canonical=aliases.get(set_id,set_id)
  for c in json.load(t.extractfile(m)):
   key=canonical+'-'+normal_number(c['number']);row={'name':c['name'],'number':c['number'],'sourceId':c['id'],'sourceSetId':set_id,'foilOnly':bool(re.search(r'\bHolo\b',c.get('rarity',''),re.I)),'sourceUrl':'https://github.com/PokemonTCG/pokemon-tcg-data/blob/master/cards/en/'+set_id+'.json'}
   if isinstance(c.get('ancientTrait'),dict) and isinstance(c['ancientTrait'].get('name'),str):row['ancientTraitName']=c['ancientTrait']['name']
   if key in names and names[key] and names[key]['name']!=row['name']:names[key]=None;conflicts.append(key)
   elif key not in names:names[key]=row
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return ({'schemaVersion':1,'generatedAt':now,'sourceSha256':hashlib.sha256(source_blob).hexdigest(),'cards':cards},{'schemaVersion':1,'generatedAt':now,'source':'PokemonTCG/pokemon-tcg-data English cards','sourceSha256':hashlib.sha256(names_blob).hexdigest(),'cards':names,'conflicts':conflicts})
def main():
 if len(sys.argv)>2:source_blob=pathlib.Path(sys.argv[1]).read_bytes();names_blob=pathlib.Path(sys.argv[2]).read_bytes()
 else:
  cached=root/'.price-state/source-archive.tar.gz'
  source_blob=cached.read_bytes() if cached.exists() else urllib.request.urlopen('https://codeload.github.com/tcgdex/cards-database/tar.gz/refs/heads/master',timeout=60).read(100000001)
  names_blob=urllib.request.urlopen('https://codeload.github.com/PokemonTCG/pokemon-tcg-data/tar.gz/refs/heads/master',timeout=60).read(100000001)
 if max(len(source_blob),len(names_blob))>100000000:raise ValueError('Reference archive exceeds limit')
 aliases=json.loads((root/'data/price-mapping.json').read_text()).get('setAliases',{})
 metadata,names=build(source_blob,names_blob,aliases)
 if len(metadata['cards'])<20000 or len(names['cards'])<10000:raise ValueError('Incomplete references')
 atomic('data/source-card-metadata-v1.json',metadata);atomic('data/independent-card-names-v1.json',names)
 print(json.dumps({'englishSourceCards':len(metadata['cards']),'independentNames':len(names['cards']),'ambiguousNames':len(names['conflicts'])}))
if __name__=='__main__':
 try:main()
 except Exception as e:
  if not all((root/'data'/p).exists() for p in ['source-card-metadata-v1.json','independent-card-names-v1.json']):raise
  print('Reference update unavailable; keeping bundled references:',str(e))
