import {normalizeMarketplaceName as normal} from './marketplace-identity.mjs';
// Ancient Traits are separate printed rules, not attacks or Abilities in
// Cardmarket's move suffix. Exclude only explicitly typed or independently
// numbered Ancient Traits; never drop an ordinary ability or attack by name.
export function gameplayMoves(card,reference){
 const trait=normal(reference?.ancientTraitName);
 const abilities=(card.abilities||[]).filter(a=>!/^ancient[ -]?trait$/i.test(a.type||'')&&!(trait&&normal(a.name)===trait));
 return [...abilities,...(card.attacks||[])].map(x=>normal(x.name)).filter(Boolean).sort();
}
