# PokeRoulette v245 — direct Cardmarket extracts

Upload PokeRoulette_v245_direct_cardmarket_setup.zip to the repository root, then replace .github/workflows/daily-prices.yml with IPHONE_WORKFLOW.yml.

The daily job downloads Cardmarket’s official Pokémon product catalogue and price guide. Exact marketplace IDs are preferred. The verified 30th Celebration release can also match a unique card name and complete attack/ability signature within its own expansion. Ambiguous entries remain N/A.

Source order remains Cardmarket Trend, TCGplayer Market, then Cardmarket averages. Existing TCGdex quotes remain available when an exact direct match is unavailable. Failed or stale extracts preserve the normal provider fallback and the last valid quotes. The extract’s createdAt is the direct quote date.

The first upgrade rechecks the catalogue to resolve direct product matches. Later same-day runs reuse the saved prices when the extract is unchanged. The usual daily full update remains scheduled for 01:17 UTC. Downloads and matching run in GitHub Actions; phones receive only the generated snapshot.

Keep the existing index.html and app assets. This workflow preserves them and the shared-prices-v241 cache prefix. It does not change collection selections or account storage. Diagnostics are available as the price-diagnostics-v245 workflow artifact.
